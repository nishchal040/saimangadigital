<?php
/**
 * Sai Manga Digital - Database Schema Creation & Rich Data Seeder
 */

class SeedData {
    public static function install(PDO $pdo, string $driver = 'sqlite'): void {
        // 1. Create Tables
        self::createTables($pdo, $driver);

        // 2. Check if already seeded
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM admins");
        if ($stmt && (int)$stmt->fetchColumn() > 0) {
            return;
        }

        // 3. Seed Initial Data
        self::seedAdmins($pdo);
        self::seedSettings($pdo);
        self::seedCategories($pdo);
        self::seedProducts($pdo);
        self::seedSampleOrders($pdo);
        self::seedSampleQuotes($pdo);
    }

    private static function createTables(PDO $pdo, string $driver): void {
        $autoId = ($driver === 'sqlite') ? 'INTEGER PRIMARY KEY AUTOINCREMENT' : 'INT AUTO_INCREMENT PRIMARY KEY';
        $textType = 'TEXT';
        $timeDefault = ($driver === 'sqlite') ? "DATETIME DEFAULT CURRENT_TIMESTAMP" : "DATETIME DEFAULT CURRENT_TIMESTAMP";

        // Admins table
        $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
            id $autoId,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(100) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            full_name VARCHAR(100) NOT NULL,
            role VARCHAR(20) DEFAULT 'admin',
            last_login $textType NULL,
            created_at $timeDefault
        );");

        // Settings table
        $pdo->exec("CREATE TABLE IF NOT EXISTS settings (
            key_name VARCHAR(50) PRIMARY KEY,
            value $textType NOT NULL,
            group_name VARCHAR(50) DEFAULT 'general',
            updated_at $timeDefault
        );");

        // Categories table
        $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
            id $autoId,
            name VARCHAR(100) NOT NULL,
            slug VARCHAR(100) NOT NULL UNIQUE,
            description $textType NULL,
            image $textType NULL,
            icon VARCHAR(50) NULL,
            display_order INT DEFAULT 0,
            is_active INT DEFAULT 1,
            created_at $timeDefault
        );");

        // Products table
        $pdo->exec("CREATE TABLE IF NOT EXISTS products (
            id $autoId,
            category_id INT NOT NULL,
            name VARCHAR(150) NOT NULL,
            slug VARCHAR(150) NOT NULL UNIQUE,
            short_desc VARCHAR(255) NULL,
            description $textType NULL,
            base_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            discount_price DECIMAL(10,2) NULL,
            pricing_type VARCHAR(20) DEFAULT 'fixed', /* 'fixed' or 'per_sqft' */
            unit VARCHAR(30) DEFAULT 'piece', /* 'piece', 'sqft', 'pack', 'set' */
            min_quantity INT DEFAULT 1,
            min_sqft DECIMAL(8,2) DEFAULT 1.00,
            default_width DECIMAL(8,2) DEFAULT 1.00,
            default_height DECIMAL(8,2) DEFAULT 1.00,
            sku VARCHAR(50) NULL,
            image $textType NOT NULL,
            gallery $textType NULL, /* JSON array */
            material_options $textType NULL, /* JSON array with price modifiers */
            finish_options $textType NULL, /* JSON array */
            is_featured INT DEFAULT 0,
            is_active INT DEFAULT 1,
            rating DECIMAL(3,1) DEFAULT 4.9,
            review_count INT DEFAULT 24,
            created_at $timeDefault,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
        );");

        // Orders table
        $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
            id $autoId,
            order_number VARCHAR(30) NOT NULL UNIQUE,
            customer_name VARCHAR(100) NOT NULL,
            customer_email VARCHAR(100) NOT NULL,
            customer_phone VARCHAR(20) NOT NULL,
            delivery_type VARCHAR(20) DEFAULT 'delivery', /* 'delivery' or 'pickup' */
            address $textType NULL,
            city VARCHAR(100) NULL,
            state VARCHAR(100) DEFAULT 'Telangana',
            pincode VARCHAR(20) NULL,
            notes $textType NULL,
            artwork_file $textType NULL,
            subtotal DECIMAL(10,2) NOT NULL,
            tax_amount DECIMAL(10,2) DEFAULT 0.00,
            shipping_fee DECIMAL(10,2) DEFAULT 0.00,
            discount_amount DECIMAL(10,2) DEFAULT 0.00,
            total_amount DECIMAL(10,2) NOT NULL,
            payment_method VARCHAR(30) DEFAULT 'upi', /* 'upi', 'cod', 'pickup' */
            payment_status VARCHAR(20) DEFAULT 'pending', /* 'pending', 'paid', 'failed' */
            order_status VARCHAR(30) DEFAULT 'pending', /* 'pending', 'in_design', 'printing', 'ready', 'dispatched', 'delivered', 'cancelled' */
            tracking_number VARCHAR(100) NULL,
            created_at $timeDefault,
            updated_at $timeDefault
        );");

        // Order Items table
        $pdo->exec("CREATE TABLE IF NOT EXISTS order_items (
            id $autoId,
            order_id INT NOT NULL,
            product_id INT NULL,
            product_name VARCHAR(150) NOT NULL,
            product_image $textType NULL,
            pricing_type VARCHAR(20) DEFAULT 'fixed',
            unit_price DECIMAL(10,2) NOT NULL,
            quantity INT NOT NULL DEFAULT 1,
            width DECIMAL(8,2) NULL,
            height DECIMAL(8,2) NULL,
            total_sqft DECIMAL(8,2) NULL,
            material_selected VARCHAR(100) NULL,
            finish_selected VARCHAR(100) NULL,
            item_total DECIMAL(10,2) NOT NULL,
            custom_notes $textType NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
        );");

        // Custom Quotes & Inquiries table
        $pdo->exec("CREATE TABLE IF NOT EXISTS quotes (
            id $autoId,
            quote_number VARCHAR(30) NOT NULL UNIQUE,
            customer_name VARCHAR(100) NOT NULL,
            customer_phone VARCHAR(20) NOT NULL,
            customer_email VARCHAR(100) NOT NULL,
            company_name VARCHAR(100) NULL,
            service_needed VARCHAR(100) NOT NULL,
            dimensions VARCHAR(100) NULL,
            quantity INT DEFAULT 1,
            message $textType NOT NULL,
            artwork_file $textType NULL,
            status VARCHAR(20) DEFAULT 'new', /* 'new', 'in_review', 'quoted', 'closed' */
            created_at $timeDefault
        );");
    }

    private static function seedAdmins(PDO $pdo): void {
        $stmt = $pdo->prepare("INSERT INTO admins (username, email, password_hash, full_name, role) VALUES (?, ?, ?, ?, ?)");
        $passwordHash = password_hash('admin123', PASSWORD_BCRYPT);
        $stmt->execute(['admin', 'admin@saimangadigital.com', $passwordHash, 'Sai Manga Admin', 'superadmin']);
    }

    private static function seedSettings(PDO $pdo): void {
        $settings = [
            'site_name' => 'Sai Manga Digital',
            'site_tagline' => 'Signage, Digital Printing & Display Solutions Since 1994',
            'proprietor' => 'Marri Prasad Naidu',
            'phone' => '+91 8047663573',
            'mobile' => '+91 98490 12345',
            'whatsapp' => '918047663573',
            'email' => 'sales@saimangadigital.com',
            'address' => 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, Beside Manyavar Showroom, S.D. Road, Secunderabad, Telangana - 500003',
            'landmark' => 'Beside Manyavar Showroom, Opposite Minerva Complex',
            'google_maps_url' => 'https://maps.app.goo.gl/cNSaRii6R44K9t4c8',
            'business_hours' => 'Monday - Saturday: 9:30 AM to 9:00 PM (Sunday Closed)',
            'google_rating' => '4.8',
            'google_reviews_count' => '68',
            'instagram' => 'https://www.instagram.com/saimangadigital',
            'currency_symbol' => '₹',
            'currency_code' => 'INR',
            'tax_rate_percent' => '18',
            'free_shipping_threshold' => '2999',
            'shipping_flat_fee' => '150',
            'upi_id' => 'saimanga@upi',
            'upi_name' => 'Sai Manga Digital Solutions',
            'announcement_bar' => '🎉 Mega Festival Offer: Flat 15% OFF on 3D LED Acrylic Sign Boards & Standees! Order Online or Call +91 8047663573'
        ];

        $stmt = $pdo->prepare("INSERT INTO settings (key_name, value, group_name) VALUES (?, ?, 'general')");
        foreach ($settings as $key => $val) {
            $stmt->execute([$key, $val]);
        }
    }

    private static function seedCategories(PDO $pdo): void {
        $categories = [
            [
                'name' => 'Sign Boards & 3D Letters',
                'slug' => 'sign-boards-3d-letters',
                'description' => 'Architectural exterior & interior signage, acrylic 3D LED letters, neon signs, glow signs and premium brass/metal nameplates.',
                'image' => 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
                'icon' => 'fas fa-store-alt',
                'display_order' => 1
            ],
            [
                'name' => 'Roll-up Standees & Displays',
                'slug' => 'rollup-standees-displays',
                'description' => 'Portable luxury roll-up pull standees, promotional spider pop-up backdrop walls, and tabletop trade show displays.',
                'image' => 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80',
                'icon' => 'fas fa-bullhorn',
                'display_order' => 2
            ],
            [
                'name' => 'Flex & Large Format Printing',
                'slug' => 'flex-large-format-printing',
                'description' => 'Eco-solvent heavy star flex, frontlit & backlit banners, self-adhesive vinyl, canvas art prints and one-way vision glass films.',
                'image' => 'https://images.unsplash.com/photo-1562577309-4932fdd64cd1?auto=format&fit=crop&w=800&q=80',
                'icon' => 'fas fa-print',
                'display_order' => 3
            ],
            [
                'name' => 'LED Displays & Lightboxes',
                'slug' => 'led-displays-lightboxes',
                'description' => 'Programmable running single/multi-color LED boards, ultra-slim magnetic fabric lightboxes, and crystal acrylic frames.',
                'image' => 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=800&q=80',
                'icon' => 'fas fa-lightbulb',
                'display_order' => 4
            ],
            [
                'name' => 'Corporate Stationery & Cards',
                'slug' => 'corporate-stationery-cards',
                'description' => 'Luxury velvet soft-touch business cards, custom printed employee ID cards, lanyards, letterheads, brochures and certificates.',
                'image' => 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80',
                'icon' => 'fas fa-id-card',
                'display_order' => 5
            ],
            [
                'name' => 'Event, Canopy & Promo Kiosks',
                'slug' => 'event-canopy-promo-kiosks',
                'description' => 'Heavy-duty advertising canopy tents, pop-up promotional tables, teardrop feather flags, and promotional demo counters.',
                'image' => 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80',
                'icon' => 'fas fa-campground',
                'display_order' => 6
            ]
        ];

        $stmt = $pdo->prepare("INSERT INTO categories (name, slug, description, image, icon, display_order) VALUES (?, ?, ?, ?, ?, ?)");
        foreach ($categories as $cat) {
            $stmt->execute([$cat['name'], $cat['slug'], $cat['description'], $cat['image'], $cat['icon'], $cat['display_order']]);
        }
    }

    private static function seedProducts(PDO $pdo): void {
        $products = [
            // Sign Boards & 3D Letters
            [
                'category_id' => 1,
                'name' => '3D Acrylic LED Front-Lit Channel Letter Board',
                'slug' => '3d-acrylic-led-frontlit-channel-letter-board',
                'short_desc' => 'High-impact waterproof 3D cast acrylic letters with ultra-bright Korean LED modules and ACP base.',
                'description' => '<p>Transform your store or corporate facade with our premium <strong>3D Acrylic LED Front-Lit Letter Board</strong>. Engineered for long-term outdoor durability and unmatched visual brilliance.</p>
                <ul>
                    <li><strong>Face:</strong> 3mm / 5mm High-grade imported Cast Acrylic Sheet (fade-proof colors).</li>
                    <li><strong>Sides/Return:</strong> Metal aluminium / acrylic return for solid depth (2 to 4 inches).</li>
                    <li><strong>Illumination:</strong> High lumen IP67 Waterproof Samsung/Korean LED modules with 3-year warranty power supply.</li>
                    <li><strong>Backing:</strong> 3mm heavy-duty Aluminium Composite Panel (ACP) with rust-free iron framework.</li>
                    <li><strong>Ideal for:</strong> Retail showrooms, hospitals, clinics, IT companies, restaurants, and shopping complexes.</li>
                </ul>',
                'base_price' => 180.00, // per sqft
                'discount_price' => 150.00,
                'pricing_type' => 'per_sqft',
                'unit' => 'sqft',
                'min_quantity' => 1,
                'min_sqft' => 10.00,
                'default_width' => 6.00,
                'default_height' => 3.00,
                'sku' => 'SMD-SIGN-3DLED',
                'image' => 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
                    'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Standard Cast Acrylic (3mm)', 'price_mod' => 0],
                    ['name' => 'Heavy Duty Cast Acrylic (5mm)', 'price_mod' => 35],
                    ['name' => 'Titanium Gold / Rose Gold Edge Trim', 'price_mod' => 60]
                ]),
                'finish_options' => json_encode([
                    'Front-Lit Glow',
                    'Backlit / Halo Glow',
                    'Dual Glow (Front & Halo)',
                    'Non-Lit 3D Raised'
                ]),
                'is_featured' => 1,
                'rating' => 4.9,
                'review_count' => 58
            ],
            [
                'category_id' => 1,
                'name' => 'Custom Neon LED Flex Sign (Glow Art & Typography)',
                'slug' => 'custom-neon-led-flex-sign',
                'short_desc' => 'Modern energy-saving neon flex on transparent 5mm laser-cut acrylic backboard. Vibrant & Instagrammable.',
                'description' => '<p>Make your brand unforgettable with custom made <strong>Vibrant Neon LED Flex Signs</strong>. Perfect for cafes, boutiques, podcasts, home decor, wedding photobooths and interior branding.</p>
                <ul>
                    <li>12V low-voltage, cool to the touch and shatter-resistant silicone neon tubing.</li>
                    <li>Transparent crystal clear 5mm acrylic base with pre-drilled holes for effortless hanging or mounting.</li>
                    <li>Includes 12V Indian standard power adapter, mounting studs, and optional RF dimmer remote control.</li>
                    <li>Over 10 glowing colors available: Warm White, Ice Blue, Pink, Purple, Electric Red, Emerald Green, Golden Yellow.</li>
                </ul>',
                'base_price' => 3499.00,
                'discount_price' => 2899.00,
                'pricing_type' => 'fixed',
                'unit' => 'piece',
                'min_quantity' => 1,
                'min_sqft' => 2.00,
                'default_width' => 2.00,
                'default_height' => 1.00,
                'sku' => 'SMD-NEON-CUSTOM',
                'image' => 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=800&q=80',
                    'https://images.unsplash.com/photo-1513151233558-d860c5398176?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Standard Direct Wall Mount', 'price_mod' => 0],
                    ['name' => 'With Wireless Dimmer Remote & Strobe Modes', 'price_mod' => 450],
                    ['name' => 'Multi-Color RGB with App Control', 'price_mod' => 950]
                ]),
                'finish_options' => json_encode([
                    'Cut-to-Letter Base',
                    'Solid Rectangular Base',
                    'Cut-to-Shape Contour'
                ]),
                'is_featured' => 1,
                'rating' => 5.0,
                'review_count' => 74
            ],
            [
                'category_id' => 1,
                'name' => 'Premium Brass / Stainless Steel Etched Name Plate',
                'slug' => 'premium-brass-stainless-steel-etched-name-plate',
                'short_desc' => 'Chemical acid etched brass or SS304 plate with automotive lacquer finish and wooden or acrylic base.',
                'description' => '<p>Dignified and timeless identification signage for doctors, advocates, corporate executives, villa gates, and luxury homes.</p>
                <ul>
                    <li>Substrate: SS304 Stainless Steel or High-Purity Solid Brass (1.5mm to 3mm).</li>
                    <li>Precision chemical etching with permanent enamel color filling.</li>
                    <li>Weatherproof multi-coat clear lacquer coating that prevents tarnishing and oxidation for years.</li>
                    <li>Comes with stainless steel decorative mirror-polished stud bolts.</li>
                </ul>',
                'base_price' => 1850.00,
                'discount_price' => 1599.00,
                'pricing_type' => 'fixed',
                'unit' => 'piece',
                'min_quantity' => 1,
                'min_sqft' => 1.00,
                'default_width' => 1.50,
                'default_height' => 1.00,
                'sku' => 'SMD-PLATE-BRASS',
                'image' => 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'SS304 Brushed Silver Finish (1.5mm)', 'price_mod' => 0],
                    ['name' => 'SS304 Mirror Gold Finish (1.5mm)', 'price_mod' => 350],
                    ['name' => 'Pure Solid Brass Golden Etched (2mm)', 'price_mod' => 750]
                ]),
                'finish_options' => json_encode([
                    'Direct Screw Studs',
                    'Teak Wood Beveled Base Mount',
                    'Black Acrylic Floating Base'
                ]),
                'is_featured' => 0,
                'rating' => 4.8,
                'review_count' => 31
            ],

            // Roll-up Standees & Displays
            [
                'category_id' => 2,
                'name' => 'Luxury Aluminium Base Roll-Up Pull Standee (6x3 ft)',
                'slug' => 'luxury-aluminium-base-rollup-standee-6x3',
                'short_desc' => 'Heavy aluminum retractable cartridge standee with anti-curl non-tearable matte greyback banner print.',
                'description' => '<p>Our #1 best-selling trade show and event display tool! Sets up in 30 seconds with no tools required.</p>
                <ul>
                    <li><strong>Display Size:</strong> 6 Feet Height x 3 Feet Width (Standard). Also available in 6x2.5 ft and 6x4 ft.</li>
                    <li><strong>Banner Media:</strong> Non-tearable greyback anti-curl film printed on high-resolution 1440 DPI Japanese inkjet machinery.</li>
                    <li><strong>Mechanism:</strong> Heavy-duty silver anodized aluminum cassette with internal high-tension spring.</li>
                    <li>Includes padded black oxford carrying bag with zipper and shoulder strap.</li>
                </ul>',
                'base_price' => 1450.00,
                'discount_price' => 1250.00,
                'pricing_type' => 'fixed',
                'unit' => 'piece',
                'min_quantity' => 1,
                'min_sqft' => 18.00,
                'default_width' => 3.00,
                'default_height' => 6.00,
                'sku' => 'SMD-STAND-LUX63',
                'image' => 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Standard Heavy Aluminum Standee (Greyback Vinyl)', 'price_mod' => 0],
                    ['name' => 'Deluxe Broad Base Teardrop Standee (Chrome Endcaps)', 'price_mod' => 450],
                    ['name' => 'Double-Sided Aluminum Roll-Up Standee', 'price_mod' => 850]
                ]),
                'finish_options' => json_encode([
                    'Anti-Glare Velvet Matte Finish',
                    'Gloss Laminated Vibrant Finish'
                ]),
                'is_featured' => 1,
                'rating' => 4.9,
                'review_count' => 112
            ],
            [
                'category_id' => 2,
                'name' => 'Pop-Up Spider Backdrop Media Wall (8x8 ft / 8x10 ft)',
                'slug' => 'popup-spider-backdrop-media-wall',
                'short_desc' => 'Collapsible magnetic aluminum accordion frame with seamless high-res backdrop branding for press & conferences.',
                'description' => '<p>Create an impressive photo backdrop, interview wall or exhibition booth backdrop in 10 minutes flat.</p>
                <ul>
                    <li>Heavy grade aluminum scissor lattice frame that unfolds effortlessly.</li>
                    <li>Seamless multi-panel high-definition matte print with magnetic alignment strips.</li>
                    <li>Comes with wheeled heavy-duty hard flight trolley case for easy transport by air or road.</li>
                    <li>Optional LED halogen top spotlights for theatrical illumination.</li>
                </ul>',
                'base_price' => 16500.00,
                'discount_price' => 14200.00,
                'pricing_type' => 'fixed',
                'unit' => 'piece',
                'min_quantity' => 1,
                'min_sqft' => 64.00,
                'default_width' => 8.00,
                'default_height' => 8.00,
                'sku' => 'SMD-SPIDER-88',
                'image' => 'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1505373877841-8d25f7d46678?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Curved 8x8 ft Spider Wall (3x3 Grid)', 'price_mod' => 0],
                    ['name' => 'Straight 8x10 ft Spider Wall (4x3 Grid)', 'price_mod' => 2800],
                    ['name' => 'Fabric Tension Seamless Dye-Sublimation Wall', 'price_mod' => 4200]
                ]),
                'finish_options' => json_encode([
                    'Includes Wheeled Flight Case',
                    'Includes Flight Case + 2x LED Spotlights'
                ]),
                'is_featured' => 0,
                'rating' => 4.9,
                'review_count' => 22
            ],

            // Flex & Large Format Printing
            [
                'category_id' => 3,
                'name' => 'Star Heavy Frontlit Flex Banner Printing (Custom Sq.Ft)',
                'slug' => 'star-heavy-frontlit-flex-banner-printing',
                'short_desc' => 'Commercial grade 340gsm / 440gsm heavy star flex banner with brass grommets/eyelets and border hem.',
                'description' => '<p>The most trusted high-speed advertising medium in Telangana. Produced on our high-output solvent and eco-solvent printing plants in Secunderabad.</p>
                <ul>
                    <li>340gsm / 440gsm Star Heavy PVC flex material with weather and UV resistance.</li>
                    <li>Vibrant true-color reproduction with UV inks that resist fading under direct sun.</li>
                    <li>Finishing includes high-frequency thermal edge folding and metal eyelets at every 2 feet for secure tying.</li>
                    <li>Same day printing & dispatch available for urgent requirements.</li>
                </ul>',
                'base_price' => 14.00, // per sqft
                'discount_price' => 11.50,
                'pricing_type' => 'per_sqft',
                'unit' => 'sqft',
                'min_quantity' => 1,
                'min_sqft' => 12.00,
                'default_width' => 6.00,
                'default_height' => 3.00,
                'sku' => 'SMD-FLEX-STAR340',
                'image' => 'https://images.unsplash.com/photo-1562577309-4932fdd64cd1?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1562577309-4932fdd64cd1?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Normal 280gsm Economy Flex', 'price_mod' => -2],
                    ['name' => 'Heavy Star Frontlit 340gsm (Recommended)', 'price_mod' => 0],
                    ['name' => 'Korean Star Flex 440gsm High Gloss', 'price_mod' => 6],
                    ['name' => 'Blackout Flex (100% Opaque for dual sided or direct sunlight)', 'price_mod' => 9]
                ]),
                'finish_options' => json_encode([
                    'Hemmed Borders with Brass Eyelets',
                    'Pocket Folds for Pipe Insertion',
                    'Raw Cut Flush'
                ]),
                'is_featured' => 1,
                'rating' => 4.9,
                'review_count' => 189
            ],
            [
                'category_id' => 3,
                'name' => 'Eco-Solvent Self-Adhesive Vinyl with Matte/Gloss Lamination',
                'slug' => 'eco-solvent-self-adhesive-vinyl-printing',
                'short_desc' => 'High-resolution photo vinyl stickers for glass partitions, sunboard mounting, wall graphics & vehicle decals.',
                'description' => '<p>Ultra-sharp 1440 DPI photographic vinyl printing with cold protective lamination layer to resist scratches, water, and cleaning chemicals.</p>
                <ul>
                    <li>Removable / permanent pressure-sensitive acrylic adhesive backing.</li>
                    <li>Crystal clear detail, perfect for menu boards, directional signage, product branding and wall graphics.</li>
                    <li>Choice between Anti-Glare Velvet Matte or Brilliant High Gloss Lamination.</li>
                    <li>Can be applied directly on glass, acrylic, sunboard (foam board), or smooth walls.</li>
                </ul>',
                'base_price' => 45.00, // per sqft
                'discount_price' => 38.00,
                'pricing_type' => 'per_sqft',
                'unit' => 'sqft',
                'min_quantity' => 1,
                'min_sqft' => 6.00,
                'default_width' => 4.00,
                'default_height' => 2.00,
                'sku' => 'SMD-VINYL-ECO',
                'image' => 'https://images.unsplash.com/photo-1572945173323-95f269a21b36?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1572945173323-95f269a21b36?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Direct Adhesive Vinyl Print + Lamination', 'price_mod' => 0],
                    ['name' => 'Mounted on 3mm Sunboard (Foam Sheet)', 'price_mod' => 30],
                    ['name' => 'Mounted on 5mm Heavy Sunboard (Foam Sheet)', 'price_mod' => 50],
                    ['name' => 'One-Way Vision Perforated Film (Glass Window)', 'price_mod' => 20]
                ]),
                'finish_options' => json_encode([
                    'Soft Matte Lamination',
                    'Ultra Gloss Lamination',
                    'Sparkle Lamination'
                ]),
                'is_featured' => 1,
                'rating' => 4.9,
                'review_count' => 64
            ],

            // LED Displays & Lightboxes
            [
                'category_id' => 4,
                'name' => 'Programmable Running LED Message Display Board (P10 Outdoor)',
                'slug' => 'programmable-running-led-message-display-board',
                'short_desc' => 'High-brightness moving message board with Wi-Fi / USB programming via Mobile App & PC software.',
                'description' => '<p>Capture instant street attention with dynamic text, animated borders, real-time clock, date, and promotional announcements.</p>
                <ul>
                    <li>Module Type: P10 Outdoor High Contrast DIP/SMD LEDs with weatherproof silicone encapsulation.</li>
                    <li>Control: Update messages anytime wirelessly using your Android / iPhone App via Wi-Fi or USB flash drive.</li>
                    <li>Housing: Heavy aluminium extrusion frame with waterproof back door and built-in heat dissipation vents.</li>
                    <li>Supports Telugu, Hindi, English, Urdu, and all regional fonts and numerical displays.</li>
                </ul>',
                'base_price' => 7800.00,
                'discount_price' => 6499.00,
                'pricing_type' => 'fixed',
                'unit' => 'piece',
                'min_quantity' => 1,
                'min_sqft' => 3.00,
                'default_width' => 3.20,
                'default_height' => 0.80,
                'sku' => 'SMD-LED-RUN3X1',
                'image' => 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Single Color Red (High Brightness)', 'price_mod' => 0],
                    ['name' => 'Single Color Amber / Warm Gold', 'price_mod' => 450],
                    ['name' => 'Single Color Pure White', 'price_mod' => 600],
                    ['name' => 'Full Color RGB (Images, Video & Text)', 'price_mod' => 4500]
                ]),
                'finish_options' => json_encode([
                    'Wi-Fi + USB Mobile App Control',
                    'Wi-Fi + USB + LAN Cloud Control'
                ]),
                'is_featured' => 1,
                'rating' => 4.8,
                'review_count' => 42
            ],
            [
                'category_id' => 4,
                'name' => 'Ultra-Slim Magnetic Fabric Lightbox (Tension Fabric SEG)',
                'slug' => 'ultra-slim-magnetic-fabric-lightbox',
                'short_desc' => 'Edge-lit 25mm slim anodized frame with tool-free silicon edge graphic (SEG) backlit fabric swap.',
                'description' => '<p>The modern architectural choice for high-end retail, jewellery boutiques, airport displays and hospitality lobbies.</p>
                <ul>
                    <li>Depth: Only 25mm - 40mm ultra sleek profile.</li>
                    <li>Print: High-intensity UV dye-sublimation on backlit crease-free fabric with silicone beading.</li>
                    <li>Changing graphics takes 60 seconds with no electrician or tools required.</li>
                    <li>Homogeneous, shadow-free backlighting with high CRI Samsung LEDs.</li>
                </ul>',
                'base_price' => 320.00, // per sqft
                'discount_price' => 280.00,
                'pricing_type' => 'per_sqft',
                'unit' => 'sqft',
                'min_quantity' => 1,
                'min_sqft' => 6.00,
                'default_width' => 3.00,
                'default_height' => 4.00,
                'sku' => 'SMD-LBOX-FAB25',
                'image' => 'https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Silver Anodized Slim Profile (25mm)', 'price_mod' => 0],
                    ['name' => 'Matte Black Powder Coated Slim Profile', 'price_mod' => 30],
                    ['name' => 'Double-Sided Freestanding Floor Unit (80mm)', 'price_mod' => 140]
                ]),
                'finish_options' => json_encode([
                    'Wall Surface Mounted',
                    'Ceiling Suspended Wire Kit'
                ]),
                'is_featured' => 0,
                'rating' => 5.0,
                'review_count' => 19
            ],

            // Corporate Stationery & Cards
            [
                'category_id' => 5,
                'name' => 'Premium Soft-Touch Velvet Visiting Cards with Spot UV (Box of 500)',
                'slug' => 'premium-soft-touch-velvet-visiting-cards-spot-uv',
                'short_desc' => '350gsm premium art card with velvet matte lamination and raised glossy spot UV lacquer highlights.',
                'description' => '<p>Leave an unforgettable first impression. Our luxury visiting cards combine a silky soft velvet touch texture with raised dimensional glossy spot UV on your logo and company name.</p>
                <ul>
                    <li>Paper Weight: 350 GSM European Art Cardboard.</li>
                    <li>Lamination: Dual-sided Thermal Soft-Touch Velvet Matte.</li>
                    <li>Enhancement: Selective 3D High-Gloss Spot UV coating on front side.</li>
                    <li>Includes custom acrylic presentation box.</li>
                </ul>',
                'base_price' => 1250.00,
                'discount_price' => 999.00,
                'pricing_type' => 'fixed',
                'unit' => 'pack',
                'min_quantity' => 1,
                'min_sqft' => 1.00,
                'default_width' => 1.00,
                'default_height' => 1.00,
                'sku' => 'SMD-CARD-UV500',
                'image' => 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Box of 500 Cards (Velvet + Spot UV)', 'price_mod' => 0],
                    ['name' => 'Box of 1,000 Cards (Best Value)', 'price_mod' => 750],
                    ['name' => 'With Metallic Gold / Silver Foil Stamping', 'price_mod' => 450]
                ]),
                'finish_options' => json_encode([
                    'Standard Square Corners',
                    'Elegant Rounded Corners (6mm radius)'
                ]),
                'is_featured' => 1,
                'rating' => 4.9,
                'review_count' => 88
            ],
            [
                'category_id' => 5,
                'name' => 'Custom Sublimation Satin Lanyards & Corporate PVC ID Cards (Pack of 50)',
                'slug' => 'custom-sublimation-satin-lanyards-pvc-id-cards',
                'short_desc' => 'High-resolution full color satin neck lanyards with dog hook, breakaway safety buckle, and contactless PVC ID cards.',
                'description' => '<p>Professional corporate identity solutions for colleges, offices, hospitals, exhibitions, and security checkposts.</p>
                <ul>
                    <li>20mm heavy satin ribbon lanyard with multi-color heat transfer sublimation printing.</li>
                    <li>Hardware: Heavy metal fish-hook / dog clip with quick-release plastic safety buckle.</li>
                    <li>ID Cards: 0.8mm CR80 Credit-card size thermal PVC cards with scratch-proof glossy overlay.</li>
                </ul>',
                'base_price' => 2450.00,
                'discount_price' => 1999.00,
                'pricing_type' => 'fixed',
                'unit' => 'pack',
                'min_quantity' => 1,
                'min_sqft' => 1.00,
                'default_width' => 1.00,
                'default_height' => 1.00,
                'sku' => 'SMD-ID-PACK50',
                'image' => 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Pack of 50 (16mm Lanyard + PVC Card)', 'price_mod' => 0],
                    ['name' => 'Pack of 50 (20mm Heavy Lanyard + Card Holder)', 'price_mod' => 350],
                    ['name' => 'Pack of 100 Bulk Set', 'price_mod' => 1650]
                ]),
                'finish_options' => json_encode([
                    'Hard Acrylic Card Holder Included',
                    'Silicone Flexible Pouch Included'
                ]),
                'is_featured' => 0,
                'rating' => 4.8,
                'review_count' => 45
            ],

            // Event, Canopy & Promo Kiosks
            [
                'category_id' => 6,
                'name' => 'Promotional Advertising Canopy Tent (6x6 ft / 10x10 ft)',
                'slug' => 'promotional-advertising-canopy-tent',
                'short_desc' => 'Heavy duty powder-coated MS frame with full waterproof Tetron branding top and back walls for outdoor campaigns.',
                'description' => '<p>Ideal for field marketing, auto expos, residential campaigns, and trade fairs across Secunderabad & Hyderabad.</p>
                <ul>
                    <li>Heavy square tube steel folding frame that collapses into a compact bundle.</li>
                    <li>100% waterproof Tetron fabric with UV resistant solvent printing.</li>
                    <li>Includes roof canopy top + 3 full half/full sidewalls as per client selection.</li>
                    <li>Sets up in under 5 minutes without tools.</li>
                </ul>',
                'base_price' => 4800.00,
                'discount_price' => 4200.00,
                'pricing_type' => 'fixed',
                'unit' => 'piece',
                'min_quantity' => 1,
                'min_sqft' => 36.00,
                'default_width' => 6.00,
                'default_height' => 6.00,
                'sku' => 'SMD-CANOPY-66',
                'image' => 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Standard 6x6 ft Canopy (Top Roof Only)', 'price_mod' => 0],
                    ['name' => 'Standard 6x6 ft Canopy with 3 Side Walls', 'price_mod' => 950],
                    ['name' => 'Large 10x10 ft Heavy Hexagonal Aluminum Frame Canopy', 'price_mod' => 4200]
                ]),
                'finish_options' => json_encode([
                    'Standard Carry Bag',
                    'Heavy Duty Wheeled Canvas Bag'
                ]),
                'is_featured' => 1,
                'rating' => 4.9,
                'review_count' => 37
            ],
            [
                'category_id' => 6,
                'name' => 'Portable Folding Promo Table / Sampling Counter',
                'slug' => 'portable-folding-promo-table-sampling-counter',
                'short_desc' => 'Lightweight PVC / ABS promotional demonstration table with top header board, internal shelf, and carry bag.',
                'description' => '<p>A neat, branded tasting, sampling or enquiry desk for mall activations, supermarkets and event registrations.</p>
                <ul>
                    <li>Lightweight white moulded ABS/PVC body with internal storage shelf for brochures and sample stock.</li>
                    <li>Full color high-resolution laminated vinyl wrap on base and overhead header board.</li>
                    <li>Load capacity up to 35 kg on countertop.</li>
                    <li>Folds completely flat into included nylon carry bag.</li>
                </ul>',
                'base_price' => 2950.00,
                'discount_price' => 2499.00,
                'pricing_type' => 'fixed',
                'unit' => 'piece',
                'min_quantity' => 1,
                'min_sqft' => 15.00,
                'default_width' => 2.80,
                'default_height' => 6.50,
                'sku' => 'SMD-TABLE-PROMO',
                'image' => 'https://images.unsplash.com/photo-1531058020387-3be344556be6?auto=format&fit=crop&w=800&q=80',
                'gallery' => json_encode([
                    'https://images.unsplash.com/photo-1531058020387-3be344556be6?auto=format&fit=crop&w=800&q=80'
                ]),
                'material_options' => json_encode([
                    ['name' => 'Standard PVC Promotional Table', 'price_mod' => 0],
                    ['name' => 'Heavy Duty Aluminum Frame Counter with Wooden Top', 'price_mod' => 1400]
                ]),
                'finish_options' => json_encode([
                    'With Overhead Header Board',
                    'Counter Table Only (No Header)'
                ]),
                'is_featured' => 0,
                'rating' => 4.7,
                'review_count' => 29
            ]
        ];

        $stmt = $pdo->prepare("INSERT INTO products (
            category_id, name, slug, short_desc, description, base_price, discount_price,
            pricing_type, unit, min_quantity, min_sqft, default_width, default_height,
            sku, image, gallery, material_options, finish_options, is_featured, rating, review_count
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?
        )");

        foreach ($products as $p) {
            $stmt->execute([
                $p['category_id'], $p['name'], $p['slug'], $p['short_desc'], $p['description'], $p['base_price'], $p['discount_price'],
                $p['pricing_type'], $p['unit'], $p['min_quantity'], $p['min_sqft'], $p['default_width'], $p['default_height'],
                $p['sku'], $p['image'], $p['gallery'], $p['material_options'], $p['finish_options'], $p['is_featured'], $p['rating'], $p['review_count']
            ]);
        }
    }

    private static function seedSampleOrders(PDO $pdo): void {
        $orders = [
            [
                'order_number' => 'SMD-20261101-01',
                'customer_name' => 'Rajesh Sharma',
                'customer_email' => 'rajesh.sharma@apolloclinic.com',
                'customer_phone' => '+91 98480 23456',
                'delivery_type' => 'delivery',
                'address' => 'Shop #14, Diamond Point, Sikh Village Road',
                'city' => 'Secunderabad',
                'state' => 'Telangana',
                'pincode' => '500009',
                'notes' => 'Please dispatch before 4 PM. We need it for clinic inauguration.',
                'artwork_file' => null,
                'subtotal' => 4500.00,
                'tax_amount' => 810.00,
                'shipping_fee' => 0.00,
                'discount_amount' => 0.00,
                'total_amount' => 5310.00,
                'payment_method' => 'upi',
                'payment_status' => 'paid',
                'order_status' => 'printing',
                'tracking_number' => 'SMD-EXP-8892',
                'items' => [
                    [
                        'product_id' => 1,
                        'product_name' => '3D Acrylic LED Front-Lit Channel Letter Board',
                        'product_image' => 'https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=800&q=80',
                        'pricing_type' => 'per_sqft',
                        'unit_price' => 150.00,
                        'quantity' => 1,
                        'width' => 10.00,
                        'height' => 3.00,
                        'total_sqft' => 30.00,
                        'material_selected' => 'Standard Cast Acrylic (3mm)',
                        'finish_selected' => 'Front-Lit Glow',
                        'item_total' => 4500.00,
                        'custom_notes' => 'Logo file sent via WhatsApp. Clinic name in Blue & Cross in Red.'
                    ]
                ]
            ],
            [
                'order_number' => 'SMD-20261102-02',
                'customer_name' => 'Priya Reddy',
                'customer_email' => 'priya.reddy@techwave.io',
                'customer_phone' => '+91 99890 34567',
                'delivery_type' => 'pickup',
                'address' => 'Pickup at Madhuban Plaza Store, S.D. Road',
                'city' => 'Secunderabad',
                'state' => 'Telangana',
                'pincode' => '500003',
                'notes' => 'Self pickup on Friday afternoon.',
                'artwork_file' => null,
                'subtotal' => 2500.00,
                'tax_amount' => 450.00,
                'shipping_fee' => 0.00,
                'discount_amount' => 0.00,
                'total_amount' => 2950.00,
                'payment_method' => 'pickup',
                'payment_status' => 'pending',
                'order_status' => 'ready',
                'tracking_number' => 'STORE-PICKUP-2',
                'items' => [
                    [
                        'product_id' => 4,
                        'product_name' => 'Luxury Aluminium Base Roll-Up Pull Standee (6x3 ft)',
                        'product_image' => 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80',
                        'pricing_type' => 'fixed',
                        'unit_price' => 1250.00,
                        'quantity' => 2,
                        'width' => 3.00,
                        'height' => 6.00,
                        'total_sqft' => 36.00,
                        'material_selected' => 'Standard Heavy Aluminum Standee (Greyback Vinyl)',
                        'finish_selected' => 'Anti-Glare Velvet Matte Finish',
                        'item_total' => 2500.00,
                        'custom_notes' => 'Recruitment drive banner'
                    ]
                ]
            ],
            [
                'order_number' => 'SMD-20261103-03',
                'customer_name' => 'Venkatesh Rao',
                'customer_email' => 'venkat@raoenterprises.com',
                'customer_phone' => '+91 98491 55667',
                'delivery_type' => 'delivery',
                'address' => 'Plot 45, Paradise Circle, M.G. Road',
                'city' => 'Secunderabad',
                'state' => 'Telangana',
                'pincode' => '500003',
                'notes' => 'Please pack securely with corner protectors.',
                'artwork_file' => null,
                'subtotal' => 2899.00,
                'tax_amount' => 521.82,
                'shipping_fee' => 0.00,
                'discount_amount' => 0.00,
                'total_amount' => 3420.82,
                'payment_method' => 'upi',
                'payment_status' => 'paid',
                'order_status' => 'dispatched',
                'tracking_number' => 'DTDC-HYD-99812',
                'items' => [
                    [
                        'product_id' => 2,
                        'product_name' => 'Custom Neon LED Flex Sign (Glow Art & Typography)',
                        'product_image' => 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&w=800&q=80',
                        'pricing_type' => 'fixed',
                        'unit_price' => 2899.00,
                        'quantity' => 1,
                        'width' => 2.00,
                        'height' => 1.00,
                        'total_sqft' => 2.00,
                        'material_selected' => 'Standard Direct Wall Mount',
                        'finish_selected' => 'Cut-to-Letter Base',
                        'item_total' => 2899.00,
                        'custom_notes' => 'Text: "Good Vibes Only" in Warm White'
                    ]
                ]
            ]
        ];

        $orderStmt = $pdo->prepare("INSERT INTO orders (
            order_number, customer_name, customer_email, customer_phone, delivery_type,
            address, city, state, pincode, notes, artwork_file, subtotal, tax_amount,
            shipping_fee, discount_amount, total_amount, payment_method, payment_status,
            order_status, tracking_number
        ) VALUES (
            ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?,
            ?, ?
        )");

        $itemStmt = $pdo->prepare("INSERT INTO order_items (
            order_id, product_id, product_name, product_image, pricing_type, unit_price,
            quantity, width, height, total_sqft, material_selected, finish_selected,
            item_total, custom_notes
        ) VALUES (
            ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?,
            ?, ?
        )");

        foreach ($orders as $o) {
            $orderStmt->execute([
                $o['order_number'], $o['customer_name'], $o['customer_email'], $o['customer_phone'], $o['delivery_type'],
                $o['address'], $o['city'], $o['state'], $o['pincode'], $o['notes'], $o['artwork_file'], $o['subtotal'], $o['tax_amount'],
                $o['shipping_fee'], $o['discount_amount'], $o['total_amount'], $o['payment_method'], $o['payment_status'],
                $o['order_status'], $o['tracking_number']
            ]);
            $orderId = (int)$pdo->lastInsertId();

            foreach ($o['items'] as $item) {
                $itemStmt->execute([
                    $orderId, $item['product_id'], $item['product_name'], $item['product_image'], $item['pricing_type'], $item['unit_price'],
                    $item['quantity'], $item['width'], $item['height'], $item['total_sqft'], $item['material_selected'], $item['finish_selected'],
                    $item['item_total'], $item['custom_notes']
                ]);
            }
        }
    }

    private static function seedSampleQuotes(PDO $pdo): void {
        $quotes = [
            [
                'quote_number' => 'SMD-Q-1001',
                'customer_name' => 'Kalyan Chakravarthy',
                'customer_phone' => '+91 97000 88219',
                'customer_email' => 'kalyan@sriharshaschools.edu.in',
                'company_name' => 'Sri Harsha High School',
                'service_needed' => 'Main Gate LED Acrylic 3D Sign & Campus Wayfinding Boards',
                'dimensions' => '30 ft x 5 ft main entrance + 12 directional signs',
                'quantity' => 13,
                'message' => 'We are renovating our school campus in Bowenpally, Secunderabad. Require quote for main gate illuminated signboard with 5-year warranty on LEDs and structure.',
                'status' => 'new'
            ],
            [
                'quote_number' => 'SMD-Q-1002',
                'customer_name' => 'Dr. Swetha Ananthan',
                'customer_phone' => '+91 98498 77123',
                'customer_email' => 'swetha.eyeclinic@gmail.com',
                'company_name' => 'Ananthan Eye Care',
                'service_needed' => 'Glow Sign Board & Frosted Glass Film with Logo Cutout',
                'dimensions' => '12 ft x 3 ft outdoor glowsign, 45 sqft glass film',
                'quantity' => 2,
                'message' => 'Looking for clean frosted glass vinyl film with clinic logo etched/cut out for our consulting room glass partitions, along with front facade signage.',
                'status' => 'in_review'
            ]
        ];

        $stmt = $pdo->prepare("INSERT INTO quotes (
            quote_number, customer_name, customer_phone, customer_email, company_name,
            service_needed, dimensions, quantity, message, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

        foreach ($quotes as $q) {
            $stmt->execute([
                $q['quote_number'], $q['customer_name'], $q['customer_phone'], $q['customer_email'], $q['company_name'],
                $q['service_needed'], $q['dimensions'], $q['quantity'], $q['message'], $q['status']
            ]);
        }
    }
}

