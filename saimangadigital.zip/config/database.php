<?php
/**
 * Sai Manga Digital - Unified Database Connection Handler
 * Supports both SQLite (Zero-config out of the box) and MySQL (Production / XAMPP)
 */

if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(__DIR__));
}

class Database {
    private static ?PDO $instance = null;

    // Database configuration
    // Driver can be 'sqlite' or 'mysql'
    // By default, if DB_DRIVER is mysql, it tries connecting; if connection fails, it falls back to sqlite gracefully
    private static string $driver = 'sqlite'; 
    private static string $mysqlHost = '127.0.0.1';
    private static string $mysqlDb = 'saimanga_db';
    private static string $mysqlUser = 'root';
    private static string $mysqlPass = '';
    private static int $mysqlPort = 3306;

    public static function getConnection(): PDO {
        if (self::$instance !== null) {
            return self::$instance;
        }

        $sqlitePath = APP_ROOT . DIRECTORY_SEPARATOR . 'database' . DIRECTORY_SEPARATOR . 'saimanga.sqlite';

        // Check if database directory exists
        $dbDir = dirname($sqlitePath);
        if (!is_dir($dbDir)) {
            mkdir($dbDir, 0777, true);
        }

        $needsInit = !file_exists($sqlitePath) || filesize($sqlitePath) === 0;

        try {
            if (self::$driver === 'mysql') {
                try {
                    $dsn = "mysql:host=" . self::$mysqlHost . ";port=" . self::$mysqlPort . ";dbname=" . self::$mysqlDb . ";charset=utf8mb4";
                    $pdo = new PDO($dsn, self::$mysqlUser, self::$mysqlPass, [
                        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                        PDO::ATTR_EMULATE_PREPARES => false,
                    ]);
                    self::$instance = $pdo;
                    return self::$instance;
                } catch (PDOException $e) {
                    // Fallback to SQLite if MySQL is unavailable
                    error_log("MySQL connection failed, falling back to SQLite: " . $e->getMessage());
                }
            }

            // SQLite Connection
            $dsn = "sqlite:" . $sqlitePath;
            $pdo = new PDO($dsn, null, null, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
            
            // Enable Foreign Keys for SQLite
            $pdo->exec('PRAGMA foreign_keys = ON;');
            self::$instance = $pdo;

            if ($needsInit) {
                self::initializeDatabase($pdo, 'sqlite');
            }

            return self::$instance;
        } catch (PDOException $e) {
            die("Database initialization error: " . htmlspecialchars($e->getMessage()));
        }
    }

    /**
     * Initializes tables and seeds initial data
     */
    public static function initializeDatabase(PDO $pdo, string $driver = 'sqlite'): void {
        require_once APP_ROOT . '/config/seed_data.php';
        SeedData::install($pdo, $driver);
    }
}

