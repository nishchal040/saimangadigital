<?php
/**
 * Sai Manga Digital - Core Initialization File
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define Root Path
if (!defined('APP_ROOT')) {
    define('APP_ROOT', dirname(__DIR__));
}

// Compute Base URL dynamically based on script name and host
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443);
$protocol = $isHttps ? "https://" : "http://";
$host = $_SERVER['HTTP_HOST'] ?? '127.0.0.1:8000';

$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$scriptDir = dirname($scriptName);
$scriptDir = str_replace('\\', '/', $scriptDir);

// Strip trailing /admin or /api to get web root
if (preg_match('#/(admin|api)(/.*)?$#', $scriptDir)) {
    $basePath = preg_replace('#/(admin|api)(/.*)?$#', '', $scriptDir);
} else {
    $basePath = $scriptDir;
}

$basePath = rtrim($basePath, '/\\');
// If basePath is just empty or single slash, keep empty
if ($basePath === '/' || $basePath === '\\' || $basePath === '.') {
    $basePath = '';
}

if (!defined('BASE_URL')) {
    define('BASE_URL', $protocol . $host . $basePath);
}

// Require Database and Functions
require_once APP_ROOT . '/config/database.php';
require_once APP_ROOT . '/includes/functions.php';

// Initialize DB Connection
$db = Database::getConnection();

// Global Settings Cache
$storeSettings = getSettings();
