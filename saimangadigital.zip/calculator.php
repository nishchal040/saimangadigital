<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Live Sqrft Signage & Flex Price Estimator | Sai Manga Digital';
$whatsapp = getSetting('whatsapp', '918047663573');
$phone = getSetting('phone', '+91 8047663573');
$mapsUrl = getSetting('google_maps_url', 'https://maps.app.goo.gl/cNSaRii6R44K9t4c8');

include __DIR__ . '/includes/header.php';
?>

<!-- Minimalist Clean Header Banner -->
<div class="page-hero-banner">
  <div class="container">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: #FFFFFF; padding: 6px 18px; border-radius: var(--radius-pill); font-size: 0.82rem; font-weight: 700; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <i class="fas fa-bolt" style="color: #F59E0B;"></i> Instant Factory Quotation Calculator
    </div>
    <h1 class="page-hero-title all-caps-title">
      Live Sqrft Price Estimator
    </h1>
    <p class="page-hero-desc">
      Calculate immediate costs for 3D acrylic LED letter boards, neon signs, star flex, vinyl stickers, and roll-up standees. Direct from our Secunderabad manufacturing workshop.
    </p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 1140px;">
    
    <div class="resp-grid-main-side">
      
      <!-- Left Configurator Form -->
      <div class="resp-card">
        <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 1px solid var(--border-subtle); display: flex; align-items: center; gap: 10px;">
          <i class="fas fa-sliders-h text-primary"></i> 1. Select Signage / Print Category
        </h3>

        <!-- Category Group -->
        <div style="margin-bottom: 20px;">
          <label class="clean-label">Product Classification</label>
          <select id="calcCategorySelect" class="sim-input-box" style="font-weight: 700;">
            <option value="3dsign" selected>3D Cast Acrylic LED Channel Letter Boards</option>
            <option value="flex">Large-Format Flex Banners (Star Frontlit &amp; Backlit)</option>
            <option value="vinyl">Self-Adhesive Vinyl, Lamination &amp; Glass Films</option>
            <option value="sunboard">Rigid Sunboard / Foam Board Mounts</option>
            <option value="neon">Custom Neon LED Flex Signs</option>
          </select>
        </div>

        <!-- Material Variant based on category -->
        <div style="margin-bottom: 28px;">
          <label class="clean-label">Material &amp; Illumination Grade</label>
          <select id="calcSubMaterialSelect" class="sim-input-box">
            <!-- Populated dynamically via JS -->
          </select>
        </div>

        <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 32px 0 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border-subtle); display: flex; align-items: center; gap: 10px;">
          <i class="fas fa-ruler-combined text-primary"></i> 2. Dimensions &amp; Scale
        </h3>

        <!-- Unit Switcher -->
        <div style="display: flex; gap: 24px; margin-bottom: 20px; flex-wrap: wrap;">
          <label style="display: flex; align-items: center; gap: 8px; font-size: 0.9rem; font-weight: 700; cursor: pointer;">
            <input type="radio" name="calc_unit" value="feet" checked style="accent-color: var(--brand-blue); transform: scale(1.2);"> Dimensions in Feet (ft)
          </label>
          <label style="display: flex; align-items: center; gap: 8px; font-size: 0.9rem; font-weight: 700; cursor: pointer;">
            <input type="radio" name="calc_unit" value="inches" style="accent-color: var(--brand-blue); transform: scale(1.2);"> Dimensions in Inches (in)
          </label>
        </div>

        <div class="form-grid-2" style="margin-bottom: 24px;">
          <div>
            <label id="labelWidth" class="clean-label">Width (Feet)</label>
            <input type="number" id="calcInputWidth" value="8" min="0.5" step="0.5" class="sim-input-box" style="font-weight: 700;">
          </div>
          <div>
            <label id="labelHeight" class="clean-label">Height (Feet)</label>
            <input type="number" id="calcInputHeight" value="3" min="0.5" step="0.5" class="sim-input-box" style="font-weight: 700;">
          </div>
        </div>

        <!-- Visual Scaled Ratio Preview Box -->
        <div style="background: #111111; border-radius: 18px; padding: 24px; text-align: center; margin-bottom: 28px; position: relative;">
          <div style="font-size: 0.75rem; color: #888888; text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 12px;">Visual Proportional Scale</div>
          <div style="display: flex; align-items: center; justify-content: center; min-height: 120px;">
            <div id="visualRatioBox" style="width: 220px; height: 82px; border: 2px dashed #00F0FF; background: rgba(0, 240, 255, 0.08); border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #FFFFFF; font-weight: 800; font-size: 0.95rem; transition: all 0.3s ease; text-shadow: 0 0 10px #00F0FF;">
              8.0 ft &times; 3.0 ft
            </div>
          </div>
          <div style="font-size: 0.8rem; color: #A7F3D0; font-weight: 700; margin-top: 10px;" id="visualAreaDisplay">
            Total Sign Area: 24.00 sq.ft
          </div>
        </div>

        <div style="margin-bottom: 28px;">
          <label class="clean-label">Quantity (Boards / Units)</label>
          <input type="number" id="calcInputQty" value="1" min="1" class="sim-input-box" style="width: 120px; font-weight: 700;">
        </div>

        <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 32px 0 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border-subtle); display: flex; align-items: center; gap: 10px;">
          <i class="fas fa-tools text-primary"></i> 3. Framework &amp; Installation Addons
        </h3>

        <div style="display: flex; flex-direction: column; gap: 14px;">
          <label style="display: flex; align-items: center; gap: 12px; font-size: 0.92rem; font-weight: 600; cursor: pointer; padding: 12px 16px; background: #FFFFFF; border: 1.5px solid #D0D5DD; border-radius: 12px;">
            <input type="checkbox" id="calcOptFrame" style="accent-color: var(--brand-blue); transform: scale(1.3);">
            <span>Include Heavy MS Pipe / Angle Iron Framework (&#8377;25/sqft)</span>
          </label>

          <label style="display: flex; align-items: center; gap: 12px; font-size: 0.92rem; font-weight: 600; cursor: pointer; padding: 12px 16px; background: #FFFFFF; border: 1.5px solid #D0D5DD; border-radius: 12px;">
            <input type="checkbox" id="calcOptInstall" style="accent-color: var(--brand-blue); transform: scale(1.3);">
            <span>Include On-Site Installation Team in Secunderabad / Hyderabad (&#8377;30/sqft)</span>
          </label>

          <label style="display: flex; align-items: center; gap: 12px; font-size: 0.92rem; font-weight: 600; cursor: pointer; padding: 12px 16px; background: #FFFFFF; border: 1.5px solid #D0D5DD; border-radius: 12px;">
            <input type="checkbox" id="calcOptEyelets" checked style="accent-color: var(--brand-blue); transform: scale(1.3);">
            <span>High-frequency hemmed borders with brass eyelets (Included Free)</span>
          </label>
        </div>

      </div>

      <!-- Right Real-time Cost Estimation Card (Sticky) -->
      <div class="resp-card" style="position: sticky; top: 100px; box-shadow: var(--shadow-card);">
        <span style="font-size: 0.75rem; font-weight: 700; text-transform: uppercase; color: var(--brand-blue); letter-spacing: 0.05em; display: inline-block; margin-bottom: 8px;">
          <i class="fas fa-bolt text-warning me-1"></i> Live Factory Rate
        </span>
        <h3 style="font-size: 1.5rem; font-weight: 900; color: #111111; margin-bottom: 20px;">
          Estimation Summary
        </h3>

        <div style="display: flex; flex-direction: column; gap: 14px; font-size: 0.92rem; margin-bottom: 24px;">
          <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
            <span>Single Board Area</span>
            <strong id="calcSummarySingleArea" style="color: #111111;">24.00 sq.ft</strong>
          </div>

          <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
            <span>Total Combined Area</span>
            <strong id="calcSummaryTotalArea" style="color: #111111;">24.00 sq.ft</strong>
          </div>

          <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
            <span>Base Fabrication Rate</span>
            <strong id="calcSummaryBaseRate" style="color: #111111;">&#8377;150.00 / sq.ft</strong>
          </div>

          <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
            <span>Iron Frame Addon</span>
            <strong id="calcSummaryFrame" style="color: #111111;">&#8377;0.00</strong>
          </div>

          <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
            <span>On-Site Mounting Addon</span>
            <strong id="calcSummaryInstall" style="color: #111111;">&#8377;0.00</strong>
          </div>

          <div style="display: flex; justify-content: space-between; align-items: baseline; padding-top: 20px; border-top: 2px dashed #D0D5DD;">
            <strong style="font-size: 1.1rem; color: #111111;">Estimated Total</strong>
            <strong id="calcSummaryGrandTotal" style="font-size: 2.2rem; font-weight: 900; color: #111111; font-family: 'Outfit', sans-serif;">&#8377; 3,600.00</strong>
          </div>
        </div>

        <!-- Action CTAs -->
        <div style="display: flex; flex-direction: column; gap: 12px;">
          <button type="button" id="calcSendWhatsApp" class="pill-btn pill-btn-primary pill-btn-lg" style="width: 100%;">
            <i class="fab fa-whatsapp me-2"></i> Send Estimate to WhatsApp
          </button>
          <a href="<?= BASE_URL ?>/contact.php#quoteForm" class="pill-btn pill-btn-outline pill-btn-lg" style="width: 100%;">
            Book Free Site Survey
          </a>
        </div>

        <div style="background: #FFFFFF; border-radius: 12px; padding: 14px; margin-top: 20px; font-size: 0.8rem; color: var(--text-muted); line-height: 1.5; text-align: center;">
          <i class="fas fa-store me-1 text-primary"></i> <strong>In-Store Pickup Available:</strong> Collect directly from Madhuban Plaza, S.D. Road Secunderabad.
        </div>
      </div>

    </div>

  </div>
</div>

<script>
const pricingMatrix = {
    flex: [
        { name: 'Star Heavy Frontlit Flex 340gsm (Popular)', rate: 11.50 },
        { name: 'Economy Frontlit Flex 280gsm', rate: 9.50 },
        { name: 'Korean Star Backlit Flex 440gsm', rate: 28.00 },
        { name: '100% Blackout Blockout Flex Banner', rate: 22.00 }
    ],
    vinyl: [
        { name: 'Eco-Solvent Photo Vinyl + Soft Matte Lamination', rate: 38.00 },
        { name: 'Eco-Solvent Photo Vinyl + High Gloss Lamination', rate: 38.00 },
        { name: 'One-Way Vision Perforated Glass Film', rate: 58.00 },
        { name: 'Frosted Glass Vinyl Film with Custom Cutout', rate: 65.00 }
    ],
    sunboard: [
        { name: 'Vinyl Mounted on 3mm Sunboard (Foam Sheet)', rate: 68.00 },
        { name: 'Vinyl Mounted on 5mm Heavy Sunboard', rate: 88.00 }
    ],
    '3dsign': [
        { name: '3D Cast Acrylic Front-Lit LED Letters (Korean Samsung Modules)', rate: 150.00 },
        { name: '3D Acrylic Halo / Backlit Glowing Letters', rate: 175.00 },
        { name: 'Titanium Gold Mirror Stainless Steel 3D Letters', rate: 210.00 },
        { name: 'Solid Etched Brass Name Board (Lacquer Coated)', rate: 240.00 }
    ],
    neon: [
        { name: 'Custom Neon LED Flex on 5mm Clear Acrylic', rate: 220.00 },
        { name: 'Multi-Color RGB Neon with Wireless Dimmer Remote', rate: 280.00 }
    ]
};

document.addEventListener('DOMContentLoaded', () => {
    const catSelect = document.getElementById('calcCategorySelect');
    const subMatSelect = document.getElementById('calcSubMaterialSelect');
    const inputW = document.getElementById('calcInputWidth');
    const inputH = document.getElementById('calcInputHeight');
    const inputQty = document.getElementById('calcInputQty');
    const optFrame = document.getElementById('calcOptFrame');
    const optInstall = document.getElementById('calcOptInstall');
    const unitRadios = document.querySelectorAll('input[name="calc_unit"]');
    const labelW = document.getElementById('labelWidth');
    const labelH = document.getElementById('labelHeight');
    const visualBox = document.getElementById('visualRatioBox');
    const visualArea = document.getElementById('visualAreaDisplay');

    function populateSubMaterials() {
        const cat = catSelect.value;
        const options = pricingMatrix[cat] || [];
        subMatSelect.innerHTML = '';
        options.forEach((opt, idx) => {
            const el = document.createElement('option');
            el.value = opt.rate;
            el.textContent = `${opt.name} - ₹${opt.rate.toFixed(2)}/sqft`;
            el.dataset.name = opt.name;
            if (idx === 0) el.selected = true;
            subMatSelect.appendChild(el);
        });
        recalculate();
    }

    function recalculate() {
        const isFeet = document.querySelector('input[name="calc_unit"]:checked').value === 'feet';
        let w = parseFloat(inputW.value) || 0;
        let h = parseFloat(inputH.value) || 0;
        const qty = parseInt(inputQty.value) || 1;

        let wFt = isFeet ? w : (w / 12);
        let hFt = isFeet ? h : (h / 12);

        let singleSqft = Math.max(0.1, wFt * hFt);
        let totalSqft = singleSqft * qty;

        const rate = parseFloat(subMatSelect.value) || 150.00;
        const subMatName = subMatSelect.selectedOptions[0]?.dataset.name || 'Signage';

        let frameRate = optFrame.checked ? 25.00 : 0.00;
        let installRate = optInstall.checked ? 30.00 : 0.00;

        let baseTotal = totalSqft * rate;
        let frameTotal = totalSqft * frameRate;
        let installTotal = totalSqft * installRate;
        let grandTotal = baseTotal + frameTotal + installTotal;

        // Update Summary DOM
        document.getElementById('calcSummarySingleArea').textContent = singleSqft.toFixed(2) + ' sq.ft';
        document.getElementById('calcSummaryTotalArea').textContent = totalSqft.toFixed(2) + ' sq.ft';
        document.getElementById('calcSummaryBaseRate').textContent = '₹' + rate.toFixed(2) + ' / sq.ft';
        document.getElementById('calcSummaryFrame').textContent = '₹' + frameTotal.toFixed(2);
        document.getElementById('calcSummaryInstall').textContent = '₹' + installTotal.toFixed(2);
        document.getElementById('calcSummaryGrandTotal').textContent = '₹ ' + grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        // Update Visual Ratio Box
        if (visualBox && visualArea) {
            const maxW = 240;
            const maxH = 140;
            let ratio = (wFt > 0 && hFt > 0) ? (wFt / hFt) : 2;
            let boxW = 160;
            let boxH = 80;
            if (ratio >= 1) {
                boxW = Math.min(maxW, Math.max(90, 80 * ratio));
                boxH = Math.min(maxH, boxW / ratio);
            } else {
                boxH = Math.min(maxH, Math.max(70, 70 / ratio));
                boxW = Math.min(maxW, boxH * ratio);
            }
            visualBox.style.width = Math.round(boxW) + 'px';
            visualBox.style.height = Math.round(boxH) + 'px';
            visualBox.textContent = `${wFt.toFixed(1)}ft × ${hFt.toFixed(1)}ft`;
            visualArea.textContent = `Total Sign Area: ${totalSqft.toFixed(2)} sq.ft (${qty} unit${qty > 1 ? 's' : ''})`;
        }

        // WhatsApp sharing link
        const msg = encodeURIComponent(
            `Hello Sai Manga Digital! I calculated an estimate on your website:\n` +
            `• Category: ${catSelect.selectedOptions[0].text}\n` +
            `• Material: ${subMatName}\n` +
            `• Size: ${wFt.toFixed(2)} ft x ${hFt.toFixed(2)} ft (${totalSqft.toFixed(2)} sq.ft)\n` +
            `• Quantity: ${qty}\n` +
            `• Framework: ${optFrame.checked ? 'Yes (₹' + frameTotal.toFixed(2) + ')' : 'No'}\n` +
            `• On-Site Installation: ${optInstall.checked ? 'Yes (₹' + installTotal.toFixed(2) + ')' : 'No'}\n` +
            `• Total Estimate: ₹${grandTotal.toFixed(2)}\n` +
            `Please confirm production lead time.`
        );
        document.getElementById('calcSendWhatsApp').onclick = () => {
            window.open(`https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsapp) ?>?text=${msg}`, '_blank');
        };
    }

    unitRadios.forEach(r => {
        r.addEventListener('change', () => {
            const isFeet = r.value === 'feet';
            labelW.textContent = isFeet ? 'Width (Feet)' : 'Width (Inches)';
            labelH.textContent = isFeet ? 'Height (Feet)' : 'Height (Inches)';
            if (isFeet) {
                inputW.value = 8;
                inputH.value = 3;
            } else {
                inputW.value = 96;
                inputH.value = 36;
            }
            recalculate();
        });
    });

    catSelect.addEventListener('change', populateSubMaterials);
    subMatSelect.addEventListener('change', recalculate);
    inputW.addEventListener('input', recalculate);
    inputH.addEventListener('input', recalculate);
    inputQty.addEventListener('input', recalculate);
    optFrame.addEventListener('change', recalculate);
    optInstall.addEventListener('change', recalculate);

    populateSubMaterials();
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>
