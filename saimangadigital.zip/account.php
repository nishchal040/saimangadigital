<?php
require_once __DIR__ . '/config/init.php';

requireCustomerAuth();

$pageTitle = 'My Account Dashboard | Sai Manga Digital';
$customer = getCustomerUser();
$error = '';
$success = '';

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = sanitize($_POST['name'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $company = sanitize($_POST['company'] ?? '');
    $address = sanitize($_POST['address'] ?? '');
    $city = sanitize($_POST['city'] ?? 'Secunderabad');
    $pincode = sanitize($_POST['pincode'] ?? '');

    if (empty($name) || empty($phone)) {
        $error = 'Name and Phone number are required.';
    } else {
        $up = $db->prepare("UPDATE customers SET name = ?, phone = ?, company = ?, address = ?, city = ?, pincode = ? WHERE id = ?");
        $up->execute([$name, $phone, $company, $address, $city, $pincode, $customer['id']]);
        $_SESSION['customer_name'] = $name;
        $success = 'Profile updated successfully!';
        $customer = getCustomerUser(); // Refresh
    }
}

// Handle Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $currentPass = $_POST['current_password'] ?? '';
    $newPass = $_POST['new_password'] ?? '';
    $confirmPass = $_POST['confirm_new_password'] ?? '';

    $stmt = $db->prepare("SELECT password_hash FROM customers WHERE id = ?");
    $stmt->execute([$customer['id']]);
    $row = $stmt->fetch();

    if (!password_verify($currentPass, $row['password_hash'])) {
        $error = 'Current password is incorrect.';
    } elseif (strlen($newPass) < 6) {
        $error = 'New password must be at least 6 characters.';
    } elseif ($newPass !== $confirmPass) {
        $error = 'New passwords do not match.';
    } else {
        $hash = password_hash($newPass, PASSWORD_DEFAULT);
        $up = $db->prepare("UPDATE customers SET password_hash = ? WHERE id = ?");
        $up->execute([$hash, $customer['id']]);
        $success = 'Password changed successfully!';
    }
}

// Fetch Customer Orders (by customer_id or matching email)
$ordersStmt = $db->prepare("
    SELECT * FROM orders 
    WHERE customer_id = ? OR customer_email = ? 
    ORDER BY id DESC
");
$ordersStmt->execute([$customer['id'], $customer['email']]);
$customerOrders = $ordersStmt->fetchAll();

// Statistics
$totalOrders = count($customerOrders);
$deliveredCount = 0;
$pendingCount = 0;
foreach ($customerOrders as $ord) {
    if ($ord['order_status'] === 'delivered') $deliveredCount++;
    if (in_array($ord['order_status'], ['pending', 'in_design', 'printing'])) $pendingCount++;
}

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
      <div>
        <h1 class="page-hero-title all-caps-title" style="margin-bottom: 4px;">My Account</h1>
        <p class="page-hero-desc" style="margin: 0; text-align: left;">Welcome back, <strong><?= htmlspecialchars($customer['name']) ?></strong> (<?= htmlspecialchars($customer['email']) ?>)</p>
      </div>
      <div>
        <a href="<?= BASE_URL ?>/logout.php" class="pill-btn pill-btn-outline pill-btn-sm" style="background: #FFFFFF;">
          <i class="fas fa-sign-out-alt me-1"></i> Sign Out
        </a>
      </div>
    </div>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container">
    
    <!-- Feedback Alerts -->
    <?php if (!empty($success)): ?>
      <div style="background: #DCFCE7; border-left: 4px solid #10B981; padding: 14px 18px; border-radius: 8px; margin-bottom: 24px; color: #15803D; font-weight: 600;">
        <i class="fas fa-check-circle me-1"></i> <?= htmlspecialchars($success) ?>
      </div>
    <?php endif; ?>
    <?php if (!empty($error)): ?>
      <div style="background: #FEE2E2; border-left: 4px solid #EF4444; padding: 14px 18px; border-radius: 8px; margin-bottom: 24px; color: #B91C1C; font-weight: 600;">
        <i class="fas fa-exclamation-circle me-1"></i> <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <!-- Metric Badges Row -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 16px; margin-bottom: 36px;">
      <div style="background: var(--card-bg); border-radius: 16px; padding: 20px 14px; text-align: center;">
        <div style="font-size: 2.2rem; font-weight: 900; color: #111111; font-family: 'Outfit', sans-serif;"><?= $totalOrders ?></div>
        <div style="font-size: 0.82rem; color: var(--text-muted); font-weight: 600;">Total Orders</div>
      </div>
      <div style="background: var(--card-bg); border-radius: 16px; padding: 20px 14px; text-align: center;">
        <div style="font-size: 2.2rem; font-weight: 900; color: #F59E0B; font-family: 'Outfit', sans-serif;"><?= $pendingCount ?></div>
        <div style="font-size: 0.82rem; color: var(--text-muted); font-weight: 600;">In-Production</div>
      </div>
      <div style="background: var(--card-bg); border-radius: 16px; padding: 20px 14px; text-align: center;">
        <div style="font-size: 2.2rem; font-weight: 900; color: #10B981; font-family: 'Outfit', sans-serif;"><?= $deliveredCount ?></div>
        <div style="font-size: 0.82rem; color: var(--text-muted); font-weight: 600;">Delivered</div>
      </div>
    </div>

    <!-- Main Content: Orders on Left, Profile on Right -->
    <div class="resp-grid-account">
      
      <!-- Orders List Column -->
      <div class="resp-card">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 1px solid var(--border-subtle);">
          <h2 style="font-size: 1.35rem; font-weight: 800; color: #111111; margin: 0;">Recent Orders</h2>
          <span style="font-size: 0.85rem; color: var(--text-muted);"><?= count($customerOrders) ?> records</span>
        </div>

        <?php if (empty($customerOrders)): ?>
          <div style="text-align: center; padding: 48px 20px; background: #FFFFFF; border-radius: 16px;">
            <i class="fas fa-box-open" style="font-size: 3rem; color: var(--text-light); margin-bottom: 16px;"></i>
            <h3 style="font-size: 1.15rem; font-weight: 700; color: #111111; margin-bottom: 8px;">No Orders Found</h3>
            <p style="font-size: 0.88rem; color: var(--text-muted); margin-bottom: 20px;">You haven't placed any orders with this account yet.</p>
            <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-primary pill-btn-sm">
              Explore Products &rarr;
            </a>
          </div>
        <?php else: ?>
          <div style="display: flex; flex-direction: column; gap: 16px;">
            <?php foreach ($customerOrders as $order): ?>
              <div style="background: #FFFFFF; border-radius: 16px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.03); border: 1px solid var(--border-subtle);">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; gap: 10px; margin-bottom: 12px;">
                  <div>
                    <strong style="font-size: 1rem; color: #111111; font-family: 'Outfit', sans-serif;">
                      #<?= htmlspecialchars($order['order_number']) ?>
                    </strong>
                    <div style="font-size: 0.8rem; color: var(--text-muted);">
                      Placed on <?= date('d M Y, h:i A', strtotime($order['created_at'])) ?>
                    </div>
                  </div>

                  <div style="display: flex; gap: 8px; align-items: center;">
                    <?= getOrderStatusBadge($order['order_status']) ?>
                    <?= getPaymentStatusBadge($order['payment_status']) ?>
                  </div>
                </div>

                <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 12px; border-top: 1px dashed var(--border-subtle); flex-wrap: wrap; gap: 10px;">
                  <div>
                    <span style="font-size: 0.82rem; color: var(--text-muted);">Amount:</span>
                    <strong style="font-size: 1.15rem; color: #111111; font-family: 'Outfit', sans-serif; margin-left: 6px;">
                      <?= formatPrice($order['total_amount']) ?>
                    </strong>
                  </div>

                  <div style="display: flex; gap: 8px;">
                    <a href="<?= BASE_URL ?>/track-order.php?order_number=<?= urlencode($order['order_number']) ?>" class="pill-btn pill-btn-outline pill-btn-sm" style="padding: 6px 14px; font-size: 0.75rem;">
                      <i class="fas fa-truck me-1"></i> Track
                    </a>
                    <a href="<?= BASE_URL ?>/invoice.php?order=<?= urlencode($order['order_number']) ?>" target="_blank" class="pill-btn pill-btn-primary pill-btn-sm" style="padding: 6px 14px; font-size: 0.75rem;">
                      <i class="fas fa-file-invoice me-1"></i> Invoice
                    </a>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>

      <!-- Profile & Settings Column -->
      <div>
        <div class="resp-card" style="margin-bottom: 24px;">
          <h2 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--border-subtle);">
            Profile Details
          </h2>

          <form action="" method="POST">
            <input type="hidden" name="update_profile" value="1">

            <div style="margin-bottom: 14px;">
              <label class="clean-label">Full Name *</label>
              <input type="text" name="name" class="clean-input" value="<?= htmlspecialchars($customer['name']) ?>" required>
            </div>

            <div style="margin-bottom: 14px;">
              <label class="clean-label">Email Address (Read-only)</label>
              <input type="email" class="clean-input" value="<?= htmlspecialchars($customer['email']) ?>" disabled style="background: #E8ECEF;">
            </div>

            <div style="margin-bottom: 14px;">
              <label class="clean-label">Mobile Number *</label>
              <input type="tel" name="phone" class="clean-input" value="<?= htmlspecialchars($customer['phone']) ?>" required>
            </div>

            <div style="margin-bottom: 14px;">
              <label class="clean-label">Company / Brand</label>
              <input type="text" name="company" class="clean-input" value="<?= htmlspecialchars($customer['company'] ?? '') ?>">
            </div>

            <div style="margin-bottom: 14px;">
              <label class="clean-label">Delivery Street Address</label>
              <input type="text" name="address" class="clean-input" value="<?= htmlspecialchars($customer['address'] ?? '') ?>">
            </div>

            <div class="form-grid-2" style="margin-bottom: 20px;">
              <div>
                <label class="clean-label">City</label>
                <input type="text" name="city" class="clean-input" value="<?= htmlspecialchars($customer['city'] ?? 'Secunderabad') ?>">
              </div>
              <div>
                <label class="clean-label">Pincode</label>
                <input type="text" name="pincode" class="clean-input" value="<?= htmlspecialchars($customer['pincode'] ?? '') ?>">
              </div>
            </div>

            <button type="submit" class="pill-btn pill-btn-primary pill-btn-sm" style="width: 100%;">
              Save Profile Changes
            </button>
          </form>
        </div>

        <!-- Password Change Card -->
        <div class="resp-card">
          <h2 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--border-subtle);">
            Change Password
          </h2>

          <form action="" method="POST">
            <input type="hidden" name="change_password" value="1">

            <div style="margin-bottom: 12px;">
              <label class="clean-label">Current Password</label>
              <input type="password" name="current_password" class="clean-input" required>
            </div>

            <div style="margin-bottom: 12px;">
              <label class="clean-label">New Password (Min 6)</label>
              <input type="password" name="new_password" class="clean-input" required>
            </div>

            <div style="margin-bottom: 18px;">
              <label class="clean-label">Confirm New Password</label>
              <input type="password" name="confirm_new_password" class="clean-input" required>
            </div>

            <button type="submit" class="pill-btn pill-btn-outline pill-btn-sm" style="width: 100%;">
              Update Password
            </button>
          </form>
        </div>
      </div>

    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

