<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Customer Login | Sai Manga Digital';
$error = '';
$redirect = sanitize($_GET['redirect'] ?? BASE_URL . '/account.php');

if (isCustomerLoggedIn()) {
    header('Location: ' . $redirect);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        $error = 'Please enter both your email address and password.';
    } else {
        $stmt = $db->prepare("SELECT id, name, email, password_hash FROM customers WHERE email = ?");
        $stmt->execute([$email]);
        $customer = $stmt->fetch();

        if ($customer && password_verify($password, $customer['password_hash'])) {
            $_SESSION['customer_id'] = (int)$customer['id'];
            $_SESSION['customer_name'] = $customer['name'];
            $_SESSION['customer_email'] = $customer['email'];

            setFlash('success', 'Welcome back, ' . htmlspecialchars($customer['name']) . '!');
            header('Location: ' . $redirect);
            exit;
        } else {
            $error = 'Invalid email address or password. Please try again.';
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <h1 class="page-hero-title all-caps-title">Customer Login</h1>
    <p class="page-hero-desc">Access your orders, track active print jobs, and manage your billing profiles.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 520px;">
    <div class="resp-card" style="box-shadow: var(--shadow-card);">
      
      <?php if (!empty($error)): ?>
        <div style="background: #FEE2E2; border-left: 4px solid #EF4444; padding: 14px 18px; border-radius: 8px; margin-bottom: 24px; color: #B91C1C; font-weight: 600; font-size: 0.9rem;">
          <i class="fas fa-exclamation-circle me-1"></i> <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form action="" method="POST">
        <input type="hidden" name="redirect" value="<?= htmlspecialchars($redirect) ?>">

        <div style="margin-bottom: 20px;">
          <label class="clean-label">Email Address *</label>
          <input type="email" name="email" class="clean-input" placeholder="e.g. yourname@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autofocus>
        </div>

        <div style="margin-bottom: 24px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <label class="clean-label" style="margin-bottom: 0;">Password *</label>
            <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', getSetting('whatsapp', '918047663573')) ?>?text=Hi%20Sai%20Manga%20Digital,%20I%20need%20help%20recovering%20my%20account" target="_blank" style="font-size: 0.78rem; color: var(--brand-blue); font-weight: 600;">
              Forgot password?
            </a>
          </div>
          <input type="password" name="password" class="clean-input" placeholder="Enter your password" required>
        </div>

        <button type="submit" class="pill-btn pill-btn-primary pill-btn-lg" style="width: 100%; margin-bottom: 20px;">
          Sign In &rarr;
        </button>

        <div style="text-align: center; font-size: 0.9rem; color: var(--text-muted); padding-top: 18px; border-top: 1px solid var(--border-subtle);">
          Don't have an account yet? 
          <a href="<?= BASE_URL ?>/register.php?redirect=<?= urlencode($redirect) ?>" style="color: var(--brand-blue); font-weight: 700;">
            Register now
          </a>
        </div>
      </form>
    </div>

    <!-- Quick Help Note -->
    <div style="margin-top: 24px; text-align: center; font-size: 0.85rem; color: var(--text-muted);">
      <i class="fas fa-shield-alt text-success me-1"></i> Need staff access? <a href="<?= BASE_URL ?>/admin/login.php" style="color: #111111; font-weight: 700;">Staff Portal Login</a>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

