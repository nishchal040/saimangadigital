<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Track Order Status | Sai Manga Digital';
$orderQuery = isset($_GET['order']) ? trim($_GET['order']) : '';
$order = null;
$items = [];
$error = '';

if (!empty($orderQuery)) {
    $stmt = $db->prepare("
        SELECT * FROM orders 
        WHERE order_number = ? OR customer_phone = ? 
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute([$orderQuery, $orderQuery]);
    $order = $stmt->fetch();

    if ($order) {
        $itemStmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $itemStmt->execute([$order['id']]);
        $items = $itemStmt->fetchAll();
    } else {
        $error = 'No order found matching "' . htmlspecialchars($orderQuery) . '". Please check your order reference.';
    }
}

// Stage map
$stages = [
    'pending' => 1,
    'in_design' => 2,
    'printing' => 3,
    'ready' => 4,
    'dispatched' => 5,
    'delivered' => 6
];
$currentStageIndex = $order ? ($stages[$order['order_status']] ?? 1) : 0;

include __DIR__ . '/includes/header.php';
?>

<!-- Header Banner -->
<div style="background: linear-gradient(135deg, #140E36 0%, #1A1344 60%, #342784 100%); color: #ffffff; padding: 50px 0;">
  <div class="container" style="text-align: center;">
    <span class="section-subtitle" style="color: #38bdf8;">Production Live Tracker</span>
    <h1 style="font-size: 2.3rem; font-weight: 800; margin-top: 4px;">Track Your Signage &amp; Print Order</h1>
    <p style="color: #94a3b8; max-width: 580px; margin: 8px auto 24px;">
      Enter your Order Number (e.g. SMD-20261101-01) or Registered Phone Number to inspect production progress in real-time.
    </p>

    <!-- Search Form -->
    <form action="" method="GET" style="max-width: 500px; margin: 0 auto; display: flex; gap: 8px;">
      <input type="text" name="order" value="<?= htmlspecialchars($orderQuery) ?>" placeholder="Enter Order Number or Phone Number" required style="flex: 1; height: 50px; border-radius: var(--radius-full); border: 2px solid #334155; padding: 0 24px; font-size: 0.95rem; background: #1e293b; color: #ffffff; font-family: inherit;">
      <button type="submit" class="btn btn-primary" style="border-radius: var(--radius-full); padding: 0 28px;">
        <i class="fas fa-search me-1"></i> Track
      </button>
    </form>
  </div>
</div>

<div class="section-padding" style="background-color: #f8fafc;">
  <div class="container" style="max-width: 900px;">
    
    <?php if (!empty($error)): ?>
      <div style="background: #fee2e2; border-left: 4px solid var(--danger); padding: 18px 24px; border-radius: var(--radius-sm); margin-bottom: 24px; color: #b91c1c; font-weight: 600;">
        <i class="fas fa-exclamation-triangle me-2"></i> <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <?php if ($order): ?>
      <!-- Order Card -->
      <div class="resp-card" style="background: #ffffff; border: 1px solid var(--border-color); box-shadow: var(--shadow-md); margin-bottom: 30px;">
        
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 14px; padding-bottom: 20px; border-bottom: 1px solid var(--border-color); margin-bottom: 30px;">
          <div>
            <div style="font-size: 0.8rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); font-weight: 700;">Order Reference</div>
            <h2 style="font-size: 1.6rem; font-weight: 800; color: var(--secondary); margin: 2px 0;"><?= htmlspecialchars($order['order_number']) ?></h2>
            <div style="font-size: 0.85rem; color: var(--text-muted);">Placed on <?= date('d M Y, h:i A', strtotime($order['created_at'])) ?></div>
          </div>
          <div>
            <span style="margin-right: 8px;"><?= getOrderStatusBadge($order['order_status']) ?></span>
            <span><?= getPaymentStatusBadge($order['payment_status']) ?></span>
          </div>
        </div>

        <!-- Visual Stepper Progress Bar -->
        <div class="order-stepper">
          <!-- Step 1 -->
          <div class="step-item <?= $currentStageIndex >= 1 ? ($currentStageIndex > 1 ? 'completed' : 'active') : '' ?>">
            <div class="step-circle">
              <i class="fas <?= $currentStageIndex > 1 ? 'fa-check' : 'fa-receipt' ?>"></i>
            </div>
            <div class="step-label">Order Received</div>
          </div>

          <!-- Step 2 -->
          <div class="step-item <?= $currentStageIndex >= 2 ? ($currentStageIndex > 2 ? 'completed' : 'active') : '' ?>">
            <div class="step-circle">
              <i class="fas <?= $currentStageIndex > 2 ? 'fa-check' : 'fa-palette' ?>"></i>
            </div>
            <div class="step-label">Design Check</div>
          </div>

          <!-- Step 3 -->
          <div class="step-item <?= $currentStageIndex >= 3 ? ($currentStageIndex > 3 ? 'completed' : 'active') : '' ?>">
            <div class="step-circle">
              <i class="fas <?= $currentStageIndex > 3 ? 'fa-check' : 'fa-print' ?>"></i>
            </div>
            <div class="step-label">Printing / CNC</div>
          </div>

          <!-- Step 4 -->
          <div class="step-item <?= $currentStageIndex >= 4 ? ($currentStageIndex > 4 ? 'completed' : 'active') : '' ?>">
            <div class="step-circle">
              <i class="fas <?= $currentStageIndex > 4 ? 'fa-check' : 'fa-certificate' ?>"></i>
            </div>
            <div class="step-label">QC &amp; Packing</div>
          </div>

          <!-- Step 5 -->
          <div class="step-item <?= $currentStageIndex >= 5 ? ($currentStageIndex > 5 ? 'completed' : 'active') : '' ?>">
            <div class="step-circle">
              <i class="fas <?= $currentStageIndex > 5 ? 'fa-check' : 'fa-shipping-fast' ?>"></i>
            </div>
            <div class="step-label">Dispatched</div>
          </div>

          <!-- Step 6 -->
          <div class="step-item <?= $currentStageIndex >= 6 ? 'completed' : '' ?>">
            <div class="step-circle">
              <i class="fas fa-box-open"></i>
            </div>
            <div class="step-label">Delivered</div>
          </div>
        </div>

        <!-- Tracking info note -->
        <?php if (!empty($order['tracking_number'])): ?>
          <div style="background: #eff6ff; border: 1.5px solid #bfdbfe; border-radius: var(--radius-md); padding: 16px 20px; display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px;">
            <div>
              <strong style="color: #1e40af; font-size: 0.95rem;"><i class="fas fa-barcode me-2"></i> Courier / Waybill Tracking:</strong>
              <span style="font-family: monospace; font-size: 1rem; color: var(--primary); font-weight: 700; margin-left: 6px;"><?= htmlspecialchars($order['tracking_number']) ?></span>
            </div>
            <span class="badge bg-primary">In Transit</span>
          </div>
        <?php endif; ?>

        <!-- Customer & Destination Details -->
        <div class="form-grid-2" style="padding: 20px; background: #f8fafc; border-radius: var(--radius-md); margin-bottom: 24px;">
          <div>
            <strong style="color: var(--secondary); font-size: 0.88rem; text-transform: uppercase; display: block; margin-bottom: 6px;">Customer Information</strong>
            <div style="font-size: 0.9rem; color: var(--text-main); font-weight: 600;"><?= htmlspecialchars($order['customer_name']) ?></div>
            <div style="font-size: 0.85rem; color: var(--text-muted);"><i class="fas fa-phone-alt me-1"></i> <?= htmlspecialchars($order['customer_phone']) ?></div>
            <div style="font-size: 0.85rem; color: var(--text-muted);"><i class="fas fa-envelope me-1"></i> <?= htmlspecialchars($order['customer_email']) ?></div>
          </div>

          <div>
            <strong style="color: var(--secondary); font-size: 0.88rem; text-transform: uppercase; display: block; margin-bottom: 6px;">Delivery / Collection Method</strong>
            <?php if ($order['delivery_type'] === 'pickup'): ?>
              <div style="font-size: 0.9rem; color: #15803d; font-weight: 700;"><i class="fas fa-store me-1"></i> Store Pickup at Madhuban Plaza</div>
              <div style="font-size: 0.82rem; color: var(--text-muted);">S.D. Road, Secunderabad, Telangana - 500003</div>
            <?php else: ?>
              <div style="font-size: 0.9rem; color: var(--secondary); font-weight: 600;"><i class="fas fa-map-marker-alt text-danger me-1"></i> Doorstep Courier Delivery</div>
              <div style="font-size: 0.85rem; color: var(--text-muted);"><?= nl2br(htmlspecialchars($order['address'] . ', ' . $order['city'] . ' - ' . $order['pincode'])) ?></div>
            <?php endif; ?>
          </div>
        </div>

        <!-- Items Table -->
        <h4 style="font-size: 1.05rem; font-weight: 800; color: var(--secondary); margin-bottom: 14px;">Items in this Order</h4>
        <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 24px;">
          <?php foreach ($items as $item): ?>
          <div style="display: flex; justify-content: space-between; padding-bottom: 12px; border-bottom: 1px solid var(--border-light); font-size: 0.9rem;">
            <div>
              <strong style="color: var(--secondary);"><?= htmlspecialchars($item['product_name']) ?></strong>
              <div style="font-size: 0.8rem; color: var(--text-muted);">
                Qty: <?= $item['quantity'] ?>
                <?= $item['pricing_type'] === 'per_sqft' ? ' • ' . $item['width'] . 'x' . $item['height'] . 'ft' : '' ?>
                <?= !empty($item['material_selected']) ? ' • ' . htmlspecialchars($item['material_selected']) : '' ?>
              </div>
            </div>
            <strong style="color: var(--secondary);"><?= formatPrice($item['item_total']) ?></strong>
          </div>
          <?php endforeach; ?>
        </div>

        <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 14px; border-top: 2px dashed var(--border-color);">
          <a href="<?= BASE_URL ?>/invoice.php?order=<?= urlencode($order['order_number']) ?>" target="_blank" class="btn btn-outline btn-sm">
            <i class="fas fa-file-invoice"></i> View Tax Invoice
          </a>
          <div style="font-size: 1.25rem; font-weight: 800; color: var(--secondary);">
            Total: <span style="color: var(--primary);"><?= formatPrice($order['total_amount']) ?></span>
          </div>
        </div>

      </div>
    <?php endif; ?>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

