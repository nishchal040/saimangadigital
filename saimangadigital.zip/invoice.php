<?php
require_once __DIR__ . '/config/init.php';

$orderNumber = isset($_GET['order']) ? trim($_GET['order']) : '';

if (empty($orderNumber)) {
    die("Error: Order number required.");
}

$stmt = $db->prepare("SELECT * FROM orders WHERE order_number = ?");
$stmt->execute([$orderNumber]);
$order = $stmt->fetch();

if (!$order) {
    die("Error: Order not found.");
}

$itemStmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->execute([$order['id']]);
$items = $itemStmt->fetchAll();

$siteName = getSetting('site_name', 'Sai Manga Digital');
$address = getSetting('address', 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, S.D. Road, Secunderabad - 500003');
$phone = getSetting('phone', '+91 8047663573');
$email = getSetting('email', 'sales@saimangadigital.com');
$upiId = getSetting('upi_id', 'saimanga@upi');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Invoice - <?= htmlspecialchars($order['order_number']) ?> | <?= htmlspecialchars($siteName) ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  
  <style>
    body {
      font-family: 'Inter', -apple-system, sans-serif;
      color: #0f172a;
      background: #f1f5f9;
      margin: 0;
      padding: 40px 20px;
    }
    .invoice-wrapper {
      max-width: 820px;
      margin: 0 auto;
      background: #ffffff;
      padding: 48px;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.06);
    }
    .invoice-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      padding-bottom: 24px;
      border-bottom: 2px solid #e2e8f0;
      margin-bottom: 28px;
    }
    .brand-meta img {
      height: 48px;
      width: auto;
      max-width: 200px;
      object-fit: contain;
      margin-bottom: 8px;
    }
    .brand-meta p {
      font-size: 0.82rem;
      color: #64748b;
      margin: 0;
      line-height: 1.5;
      max-width: 320px;
    }
    .invoice-title-block {
      text-align: right;
    }
    .invoice-title {
      font-size: 1.8rem;
      font-weight: 800;
      color: #342784;
      margin: 0 0 4px;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .invoice-meta-row {
      font-size: 0.85rem;
      color: #64748b;
      margin-bottom: 3px;
    }
    .invoice-meta-row strong {
      color: #0f172a;
    }
    .bill-to-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 30px;
      margin-bottom: 30px;
      font-size: 0.88rem;
    }
    .bill-to-box {
      background: #f8fafc;
      padding: 18px;
      border-radius: 8px;
      border: 1px solid #e2e8f0;
    }
    .bill-to-box h4 {
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #64748b;
      margin: 0 0 8px;
    }
    .table-invoice {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 28px;
      font-size: 0.88rem;
    }
    .table-invoice th {
      background: #1e293b;
      color: #ffffff;
      padding: 10px 14px;
      text-align: left;
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .table-invoice td {
      padding: 14px;
      border-bottom: 1px solid #e2e8f0;
      vertical-align: top;
    }
    .table-invoice tbody tr:nth-child(even) {
      background-color: #f8fafc;
    }
    .totals-area {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-top: 10px;
    }
    .payment-notes {
      max-width: 420px;
      font-size: 0.8rem;
      color: #64748b;
      line-height: 1.6;
    }
    .totals-table {
      width: 300px;
      font-size: 0.88rem;
    }
    .totals-table td {
      padding: 6px 0;
    }
    .totals-table tr.grand-total {
      font-size: 1.15rem;
      font-weight: 800;
      color: #1e3a8a;
      border-top: 2px solid #e2e8f0;
    }
    .actions-bar {
      max-width: 820px;
      margin: 0 auto 20px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    @media (max-width: 640px) {
      body {
        padding: 12px;
      }
      .actions-bar {
        flex-direction: column;
        gap: 12px;
        align-items: stretch;
        text-align: center;
      }
      .actions-bar button {
        width: 100%;
        justify-content: center;
      }
      .invoice-wrapper {
        padding: 20px 16px;
      }
      .invoice-header {
        flex-direction: column;
        gap: 16px;
      }
      .invoice-title-block {
        text-align: left;
      }
      .bill-to-grid {
        grid-template-columns: 1fr;
        gap: 14px;
      }
      .totals-area {
        flex-direction: column;
        gap: 20px;
      }
      .totals-table {
        width: 100%;
      }
      .table-invoice-wrap {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
      }
    }

    @media print {
      body {
        background: #ffffff;
        padding: 0;
      }
      .actions-bar {
        display: none !important;
      }
      .invoice-wrapper {
        box-shadow: none;
        border: none;
        padding: 0;
      }
    }
  </style>
</head>
<body>

<div class="actions-bar">
  <a href="<?= BASE_URL ?>/index.php" style="color: #2563eb; text-decoration: none; font-weight: 600; font-size: 0.9rem;">
    &larr; Back to Sai Manga Digital
  </a>
  <button type="button" onclick="window.print()" style="background: #2563eb; color: #ffffff; border: none; padding: 10px 20px; border-radius: 8px; font-weight: 700; cursor: pointer; display: inline-flex; align-items: center; gap: 8px;">
    <i class="fas fa-print"></i> Print Invoice / Save as PDF
  </button>
</div>

<div class="invoice-wrapper">
  <!-- Invoice Header -->
  <div class="invoice-header">
    <div class="brand-meta">
      <img src="<?= BASE_URL ?>/assets/images/logo.svg" alt="Sai Manga Digital">
      <p>
        <?= nl2br(htmlspecialchars($address)) ?><br>
        <strong>Phone:</strong> <?= htmlspecialchars($phone) ?><br>
        <strong>Email:</strong> <?= htmlspecialchars($email) ?>
      </p>
    </div>
    <div class="invoice-title-block">
      <h1 class="invoice-title">TAX INVOICE</h1>
      <div class="invoice-meta-row">Invoice #: <strong><?= htmlspecialchars($order['order_number']) ?></strong></div>
      <div class="invoice-meta-row">Date: <strong><?= date('d M Y', strtotime($order['created_at'])) ?></strong></div>
      <div class="invoice-meta-row">Payment: <strong><?= strtoupper(htmlspecialchars($order['payment_method'])) ?> (<?= ucfirst(htmlspecialchars($order['payment_status'])) ?>)</strong></div>
      <div class="invoice-meta-row">Status: <strong><?= strtoupper(str_replace('_', ' ', htmlspecialchars($order['order_status']))) ?></strong></div>
    </div>
  </div>

  <!-- Billed To -->
  <div class="bill-to-grid">
    <div class="bill-to-box">
      <h4>Billed To (Customer):</h4>
      <strong style="font-size: 1.05rem; color: #0f172a; display: block; margin-bottom: 4px;"><?= htmlspecialchars($order['customer_name']) ?></strong>
      <div>Phone: <?= htmlspecialchars($order['customer_phone']) ?></div>
      <div>Email: <?= htmlspecialchars($order['customer_email']) ?></div>
    </div>
    <div class="bill-to-box">
      <h4>Dispatch / Delivery Mode:</h4>
      <?php if ($order['delivery_type'] === 'pickup'): ?>
        <strong style="color: #15803d;"><i class="fas fa-store me-1"></i> Madhuban Plaza Store Pickup</strong>
        <div style="color: #64748b; font-size: 0.82rem; margin-top: 4px;">S.D. Road, Secunderabad, Telangana - 500003</div>
      <?php else: ?>
        <strong style="color: #0f172a;"><i class="fas fa-truck me-1"></i> Courier Delivery</strong>
        <div style="color: #64748b; font-size: 0.82rem; margin-top: 4px;"><?= nl2br(htmlspecialchars($order['address'] . ', ' . $order['city'] . ' - ' . $order['pincode'])) ?></div>
      <?php endif; ?>
    </div>
  </div>

  <!-- Items Table -->
  <div class="table-invoice-wrap">
  <table class="table-invoice">
    <thead>
      <tr>
        <th style="width: 5%;">#</th>
        <th style="width: 50%;">Description / Product Specifications</th>
        <th style="width: 15%; text-align: center;">Qty / Sqrft</th>
        <th style="width: 15%; text-align: right;">Unit Rate</th>
        <th style="width: 15%; text-align: right;">Total Amount</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $idx => $item): ?>
      <tr>
        <td><?= $idx + 1 ?></td>
        <td>
          <strong style="color: #0f172a;"><?= htmlspecialchars($item['product_name']) ?></strong>
          <div style="font-size: 0.8rem; color: #64748b; margin-top: 4px;">
            <?php if ($item['pricing_type'] === 'per_sqft' && $item['width'] > 0): ?>
              Dimensions: <?= $item['width'] ?> ft &times; <?= $item['height'] ?> ft (<?= number_format($item['total_sqft'], 2) ?> sq.ft)
            <?php endif; ?>
            <?php if (!empty($item['material_selected'])): ?>
              • Material: <?= htmlspecialchars($item['material_selected']) ?>
            <?php endif; ?>
            <?php if (!empty($item['finish_selected'])): ?>
              • Finish: <?= htmlspecialchars($item['finish_selected']) ?>
            <?php endif; ?>
          </div>
          <?php if (!empty($item['custom_notes'])): ?>
            <div style="font-size: 0.78rem; color: #1e40af; margin-top: 4px;">Note: <?= htmlspecialchars($item['custom_notes']) ?></div>
          <?php endif; ?>
        </td>
        <td style="text-align: center;">
          <?= $item['quantity'] ?> <?= $item['pricing_type'] === 'per_sqft' ? '(' . number_format($item['total_sqft'], 2) . ' sqft)' : 'pc' ?>
        </td>
        <td style="text-align: right;">
          <?= formatPrice($item['unit_price']) ?>
        </td>
        <td style="text-align: right; font-weight: 700;">
          <?= formatPrice($item['item_total']) ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  </div>

  <!-- Totals & Payment Notes -->
  <div class="totals-area">
    <div class="payment-notes">
      <h4 style="font-size: 0.8rem; text-transform: uppercase; color: #64748b; margin: 0 0 6px;">Terms &amp; Settlement:</h4>
      <p style="margin: 0 0 8px;">
        1. All 3D Cast Acrylic signage modules carry a 3-Year LED replacement warranty.<br>
        2. Flex banner and vinyl print colors are calibrated according to standard ISO CMYK profiles.<br>
        3. Settlement UPI: <strong><?= htmlspecialchars($upiId) ?></strong> (Sai Manga Digital Solutions).
      </p>
      <div style="margin-top: 20px;">
        <div style="font-size: 0.82rem; font-weight: 700; color: #0f172a;">For SAI MANGA DIGITAL</div>
        <div style="margin-top: 25px; font-size: 0.78rem; color: #64748b;">(Authorised Signatory)</div>
      </div>
    </div>

    <table class="totals-table">
      <tr>
        <td style="color: #64748b;">Items Subtotal:</td>
        <td style="text-align: right; font-weight: 600;"><?= formatPrice($order['subtotal']) ?></td>
      </tr>
      <tr>
        <td style="color: #64748b;">CGST + SGST (18%):</td>
        <td style="text-align: right; font-weight: 600;"><?= formatPrice($order['tax_amount']) ?></td>
      </tr>
      <tr>
        <td style="color: #64748b;">Shipping / Packaging:</td>
        <td style="text-align: right; font-weight: 600;"><?= $order['shipping_fee'] == 0 ? 'FREE' : formatPrice($order['shipping_fee']) ?></td>
      </tr>
      <tr class="grand-total">
        <td style="padding-top: 10px;">Grand Total:</td>
        <td style="text-align: right; padding-top: 10px;"><?= formatPrice($order['total_amount']) ?></td>
      </tr>
    </table>
  </div>
</div>

</body>
</html>

