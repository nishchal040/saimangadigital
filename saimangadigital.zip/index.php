<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Sai Manga Digital | Premier 3D LED Signage & Large-Format Printing Secunderabad';

// Fetch categories
$categories = $db->query("SELECT * FROM categories WHERE is_active = 1 ORDER BY display_order ASC")->fetchAll();

// Fetch featured products
$featuredProducts = $db->query("
    SELECT p.*, c.name as category_name, c.slug as category_slug 
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    WHERE p.is_featured = 1 AND p.is_active = 1 
    ORDER BY p.id ASC 
    LIMIT 6
")->fetchAll();

$phone = getSetting('phone', '+91 8047663573');
$whatsapp = getSetting('whatsapp', '918047663573');
$mapsUrl = getSetting('google_maps_url', 'https://maps.app.goo.gl/cNSaRii6R44K9t4c8');
$instagramUrl = getSetting('instagram', 'https://www.instagram.com/saimangadigital');
$address = getSetting('address', 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, Beside Manyavar Showroom, S.D. Road, Secunderabad, Telangana - 500003');
$proprietor = getSetting('proprietor', 'Marri Prasad Naidu');
$hours = getSetting('business_hours', 'Monday - Saturday: 9:30 AM to 9:00 PM (Sunday Closed)');
$rating = getSetting('google_rating', '4.8');
$reviewsCount = getSetting('google_reviews_count', '68');

include __DIR__ . '/includes/header.php';
?>

<!-- ==========================================================================
     1. HERO SECTION (Focused 100% On Large-Format & Digital Printing)
     ========================================================================== -->
<section class="hero-minimal-section">
  <div class="container">
    <div class="hero-minimal-grid">
      <!-- Left: Big Bold All-Caps Title & Printing Focused CTAs -->
      <div>
        <h1 class="hero-minimal-title">
          EXPLORE THE WORLD OF<br>
          HIGH-PRECISION PRINTING
        </h1>

        <p class="hero-minimal-subtitle">
          Secunderabad &amp; Hyderabad's leading high-capacity digital printing press since 1994. Heavy Star frontlit &amp; backlit flex, 1440 DPI Japanese eco-solvent vinyl, canvas cloth, and trade show roll-up banners. Engineered for razor-sharp color fidelity and same-day express delivery.
        </p>

        <div class="hero-cta-row">
          <a href="<?= BASE_URL ?>/shop.php?category=flex-large-format-printing" class="pill-btn pill-btn-primary pill-btn-lg">
            ORDER PRINTING NOW
          </a>
          <a href="<?= BASE_URL ?>/calculator.php" class="pill-btn pill-btn-outline pill-btn-lg">
            SQRFT PRINT ESTIMATOR
          </a>
        </div>

        <div class="hero-minimal-badge-row">
          <div>
            <i class="fas fa-print" style="color: var(--brand-blue); margin-right: 4px;"></i>
            <strong>1440 DPI Japanese Inks</strong>
          </div>
          <div style="opacity: 0.4;">•</div>
          <div>
            <i class="fas fa-bolt" style="color: #F59E0B; margin-right: 4px;"></i>
            <strong>Star Flex from &#8377;11.50/sq.ft</strong>
          </div>
          <div style="opacity: 0.4;">•</div>
          <div>
            <i class="fab fa-google" style="color: #4285F4; margin-right: 4px;"></i>
            <strong><?= htmlspecialchars($rating) ?> ★</strong> (<?= htmlspecialchars($reviewsCount) ?>+ Reviews)
          </div>
          <div style="opacity: 0.4;">•</div>
          <div>
            <a href="<?= $instagramUrl ?>" target="_blank" style="color: #E1306C; font-weight: 700;">
              <i class="fab fa-instagram" style="margin-right: 4px;"></i> @saimangadigital
            </a>
          </div>
        </div>
      </div>

      <!-- Right: Real 3D Large-Format Roll-to-Roll Digital Printing Visual -->
      <div class="hero-3d-visual-wrap">
        <img src="<?= BASE_URL ?>/assets/images/hero-printing-3d.jpg" alt="Sai Manga Digital - Large Format Digital &amp; Flex Printing Machinery">
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     2. FEATURED COLLECTIONS (Real Commercial Signage Categories)
     ========================================================================== -->
<section class="featured-collections-section">
  <div class="container">
    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 36px; flex-wrap: wrap; gap: 12px;">
      <div>
        <h2 class="section-title-minimal" style="margin-bottom: 6px;">Featured Collections</h2>
        <p style="color: var(--text-muted); font-size: 0.95rem;">Engineered for retail stores, corporate elevations, events, and commercial branding.</p>
      </div>
      <a href="<?= $instagramUrl ?>" target="_blank" style="font-size: 0.88rem; font-weight: 700; color: #E1306C;">
        <i class="fab fa-instagram me-1"></i> View Live Installs @saimangadigital &rarr;
      </a>
    </div>

    <div class="collections-grid-3">
      <!-- Collection Card 1: 3D LED Letters -->
      <div class="collection-card-minimal">
        <div class="collection-image-box">
          <img src="<?= BASE_URL ?>/assets/images/collection-sign-letters.jpg" alt="3D Acrylic LED Letters">
        </div>
        <div>
          <h3 class="collection-title-minimal">3D LED Channel Letters</h3>
          <p style="font-size: 0.84rem; color: var(--text-muted); margin-bottom: 18px;">Korean Samsung LED modules &amp; cast acrylic with halo backlit options.</p>
          <a href="<?= BASE_URL ?>/shop.php?category=sign-boards-3d-letters" class="pill-btn pill-btn-primary">
            SHOP NOW
          </a>
        </div>
      </div>

      <!-- Collection Card 2: Roll-Up Pull Standees -->
      <div class="collection-card-minimal">
        <div class="collection-image-box">
          <img src="<?= BASE_URL ?>/assets/images/collection-standee.jpg" alt="Roll-Up Pull Standees">
        </div>
        <div>
          <h3 class="collection-title-minimal">Roll-Up Pull Standees</h3>
          <p style="font-size: 0.84rem; color: var(--text-muted); margin-bottom: 18px;">Heavy aluminium cassette base with 1440 DPI non-tearable banner film.</p>
          <a href="<?= BASE_URL ?>/shop.php?category=rollup-standees-displays" class="pill-btn pill-btn-primary">
            SHOP NOW
          </a>
        </div>
      </div>

      <!-- Collection Card 3: Custom Neon LED Signs -->
      <div class="collection-card-minimal">
        <div class="collection-image-box">
          <img src="<?= BASE_URL ?>/assets/images/collection-neon.jpg" alt="Custom Neon LED Signs">
        </div>
        <div>
          <h3 class="collection-title-minimal">Custom Neon LED Art</h3>
          <p style="font-size: 0.84rem; color: var(--text-muted); margin-bottom: 18px;">Silicone 12V glowing typography &amp; custom artwork on laser-cut acrylic.</p>
          <a href="<?= BASE_URL ?>/shop.php?category=sign-boards-3d-letters" class="pill-btn pill-btn-primary">
            SHOP NOW
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     3. ABOUT US SECTION (Real Signage Craftsmanship Visual)
     ========================================================================== -->
<section class="about-minimal-section">
  <div class="container">
    <div class="about-minimal-grid">
      <!-- Left: Text Content -->
      <div class="about-text-content">
        <h2>About Us</h2>
        <p>
          Sai Manga Digital is dedicated to providing state-of-the-art 3D architectural signage, illuminated channel letters, neon installations, and large-format printing services. With an uncompromising commitment to structural quality and high-lumen illumination, we push the boundaries of retail and corporate branding.
        </p>
        <p>
          Founded in 1994 by <strong><?= htmlspecialchars($proprietor) ?></strong> at Madhuban Plaza on S.D. Road, Secunderabad, our in-house manufacturing unit has fabricated more than 15,000+ signboards across Hyderabad &amp; Telangana with a 4.8★ Google rating.
        </p>

        <div class="about-stats-pills">
          <span class="about-stat-pill">
            <i class="fas fa-award text-warning"></i> 30+ Years Legacy
          </span>
          <span class="about-stat-pill">
            <i class="fas fa-cube text-primary"></i> 15,000+ Installations
          </span>
          <span class="about-stat-pill">
            <i class="fas fa-print text-danger"></i> 1440 DPI Japanese Plotters
          </span>
          <span class="about-stat-pill">
            <i class="fab fa-google text-success"></i> 4.8★ Google Rating
          </span>
        </div>

        <div style="margin-top: 24px;">
          <a href="<?= BASE_URL ?>/about.php" class="pill-btn pill-btn-dark">
            OUR STORY &rarr;
          </a>
          <a href="<?= $instagramUrl ?>" target="_blank" class="pill-btn pill-btn-outline" style="margin-left: 10px;">
            <i class="fab fa-instagram text-danger me-1"></i> Instagram Portfolio
          </a>
        </div>
      </div>

      <!-- Right: Real Executive Craftsmanship Signboard Visual -->
      <div class="about-3d-visual-box">
        <img src="<?= BASE_URL ?>/assets/images/about-craftsmanship.jpg" alt="Sai Manga Digital Signage Craftsmanship">
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     4. FEATURED PRODUCTS (Real Signage & Large Format Products)
     ========================================================================== -->
<section class="featured-products-section">
  <div class="container">
    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 36px; flex-wrap: wrap; gap: 16px;">
      <div>
        <h2 class="section-title-minimal" style="margin-bottom: 6px;">Featured Products</h2>
        <p style="color: var(--text-muted); font-size: 0.95rem;">Precision-engineered signboards and large format materials ready for custom fabrication.</p>
      </div>
      <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-outline pill-btn-sm">
        View All Catalog &rarr;
      </a>
    </div>

    <div class="products-grid-3">
      <?php foreach ($featuredProducts as $product): ?>
        <div class="product-card-minimal">
          <div class="product-card-thumb">
            <span class="product-badge-pill">
              <?= $product['pricing_type'] === 'per_sqft' ? 'Custom Size' : 'Direct Order' ?>
            </span>
            <?php $inWishlist = isInWishlist($product['id']); ?>
            <a href="<?= BASE_URL ?>/wishlist.php?action=<?= $inWishlist ? 'remove' : 'add' ?>&id=<?= $product['id'] ?>&redirect=<?= urlencode($_SERVER['REQUEST_URI'] ?? '/index.php') ?>" 
               class="wishlist-thumb-btn <?= $inWishlist ? 'active' : '' ?>" 
               title="<?= $inWishlist ? 'Remove from Wishlist' : 'Save to Wishlist' ?>">
              <i class="<?= $inWishlist ? 'fas' : 'far' ?> fa-heart"></i>
            </a>
            <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" loading="lazy">
          </div>

          <div class="product-card-body">
            <div>
              <div class="product-cat-tag"><?= htmlspecialchars($product['category_name']) ?></div>
              <h3 class="product-card-title">
                <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($product['slug']) ?>">
                  <?= htmlspecialchars($product['name']) ?>
                </a>
              </h3>
            </div>

            <div>
              <div class="product-pricing-row">
                <span class="product-price-current">
                  &#8377;<?= number_format($product['discount_price'] ?? $product['base_price'], 2) ?>
                </span>
                <?php if (!empty($product['discount_price']) && $product['discount_price'] < $product['base_price']): ?>
                  <span class="product-price-old">
                    &#8377;<?= number_format($product['base_price'], 2) ?>
                  </span>
                <?php endif; ?>
                <span class="product-price-unit">/ <?= htmlspecialchars($product['unit']) ?></span>
              </div>

              <div class="product-actions-row">
                <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($product['slug']) ?>" class="pill-btn pill-btn-primary pill-btn-sm" style="flex: 1;">
                  Configure &amp; Buy
                </a>
                <?php if ($product['pricing_type'] === 'per_sqft'): ?>
                  <a href="<?= BASE_URL ?>/calculator.php?product=<?= $product['id'] ?>" class="pill-btn pill-btn-outline pill-btn-sm" title="Estimate by Sq.Ft">
                    <i class="fas fa-calculator"></i>
                  </a>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ==========================================================================
     5. INSTAGRAM PORTFOLIO SHOWCASE STRIP (@saimangadigital)
     ========================================================================== -->
<section style="padding: 60px 0; background-color: var(--card-bg); border-top: 1px solid var(--border-subtle); border-bottom: 1px solid var(--border-subtle);">
  <div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 28px; flex-wrap: wrap; gap: 16px;">
      <div>
        <div style="display: inline-flex; align-items: center; gap: 6px; font-size: 0.8rem; font-weight: 700; text-transform: uppercase; color: #E1306C; letter-spacing: 0.05em;">
          <i class="fab fa-instagram"></i> Live Production Feed
        </div>
        <h3 style="font-size: 1.8rem; font-weight: 800; color: #111111; margin-top: 4px;">
          Follow @saimangadigital On Instagram
        </h3>
      </div>
      <a href="<?= $instagramUrl ?>" target="_blank" class="pill-btn pill-btn-primary pill-btn-sm" style="background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%);">
        <i class="fab fa-instagram me-1"></i> Follow On Instagram
      </a>
    </div>

    <!-- 4-Card Portfolio Showcase -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px;">
      <a href="<?= $instagramUrl ?>" target="_blank" style="background: #FFFFFF; border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-card); display: block; transition: transform 0.25s ease;" onmouseover="this.style.transform='translateY(-4px)'" onmouseout="this.style.transform='translateY(0)'">
        <div style="height: 180px; overflow: hidden;">
          <img src="<?= BASE_URL ?>/assets/images/collection-sign-letters.jpg" alt="3D Acrylic Signboard" style="width: 100%; height: 100%; object-fit: cover;">
        </div>
        <div style="padding: 16px;">
          <strong style="color: #111111; font-size: 0.92rem; display: block;">3D Acrylic LED Elevations</strong>
          <span style="font-size: 0.78rem; color: #E1306C; font-weight: 600;">@saimangadigital &bull; Showroom Signs</span>
        </div>
      </a>

      <a href="<?= $instagramUrl ?>" target="_blank" style="background: #FFFFFF; border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-card); display: block; transition: transform 0.25s ease;" onmouseover="this.style.transform='translateY(-4px)'" onmouseout="this.style.transform='translateY(0)'">
        <div style="height: 180px; overflow: hidden;">
          <img src="<?= BASE_URL ?>/assets/images/collection-blade-sign.jpg" alt="Square LED Blade Sign" style="width: 100%; height: 100%; object-fit: cover;">
        </div>
        <div style="padding: 16px;">
          <strong style="color: #111111; font-size: 0.92rem; display: block;">Square Double-Sided Lightboxes</strong>
          <span style="font-size: 0.78rem; color: #E1306C; font-weight: 600;">@saimangadigital &bull; Projection Signs</span>
        </div>
      </a>

      <a href="<?= $instagramUrl ?>" target="_blank" style="background: #FFFFFF; border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-card); display: block; transition: transform 0.25s ease;" onmouseover="this.style.transform='translateY(-4px)'" onmouseout="this.style.transform='translateY(0)'">
        <div style="height: 180px; overflow: hidden;">
          <img src="<?= BASE_URL ?>/assets/images/collection-neon.jpg" alt="Custom Neon Signs" style="width: 100%; height: 100%; object-fit: cover;">
        </div>
        <div style="padding: 16px;">
          <strong style="color: #111111; font-size: 0.92rem; display: block;">Custom Neon Art Typography</strong>
          <span style="font-size: 0.78rem; color: #E1306C; font-weight: 600;">@saimangadigital &bull; Cafe &amp; Studio Decor</span>
        </div>
      </a>

      <a href="<?= $instagramUrl ?>" target="_blank" style="background: #FFFFFF; border-radius: 16px; overflow: hidden; box-shadow: var(--shadow-card); display: block; transition: transform 0.25s ease;" onmouseover="this.style.transform='translateY(-4px)'" onmouseout="this.style.transform='translateY(0)'">
        <div style="height: 180px; overflow: hidden;">
          <img src="<?= BASE_URL ?>/assets/images/collection-standee.jpg" alt="Rollup Standees" style="width: 100%; height: 100%; object-fit: cover;">
        </div>
        <div style="padding: 16px;">
          <strong style="color: #111111; font-size: 0.92rem; display: block;">Aluminium Roll-Up Standees</strong>
          <span style="font-size: 0.78rem; color: #E1306C; font-weight: 600;">@saimangadigital &bull; Expo &amp; Event Displays</span>
        </div>
      </a>
    </div>
  </div>
</section>

<!-- ==========================================================================
     6. GOOGLE MAPS VERIFIED SECUNDERABAD STUDIO
     ========================================================================== -->
<section class="maps-hub-section">
  <div class="container">
    <div class="maps-hub-card">
      <div>
        <div class="maps-rating-badge">
          <i class="fab fa-google" style="color: #4285F4;"></i>
          <span><?= htmlspecialchars($rating) ?> / 5.0 Star Rating</span>
          <span style="opacity: 0.3;">•</span>
          <span><?= htmlspecialchars($reviewsCount) ?>+ Verified Reviews</span>
        </div>

        <h3>Visit Flagship Secunderabad Studio</h3>
        <p class="maps-address-text">
          <strong>Sai Manga Digital</strong><br>
          <?= nl2br(htmlspecialchars($address)) ?><br>
          <span style="color: #059669; font-weight: 600;"><i class="fas fa-clock me-1"></i> <?= htmlspecialchars($hours) ?></span>
        </p>

        <div style="display: flex; gap: 12px; flex-wrap: wrap;">
          <a href="<?= htmlspecialchars($mapsUrl) ?>" target="_blank" class="pill-btn pill-btn-primary">
            <i class="fab fa-google me-1"></i> Open Google Maps &rarr;
          </a>
          <a href="tel:<?= preg_replace('/[^0-9+]/', '', $phone) ?>" class="pill-btn pill-btn-outline">
            <i class="fas fa-phone me-1"></i> <?= htmlspecialchars($phone) ?>
          </a>
        </div>
      </div>

      <div style="background: #FFFFFF; border-radius: 20px; padding: 24px; box-shadow: var(--shadow-card); border: 1px solid var(--border-subtle);">
        <h4 style="font-size: 1.1rem; font-weight: 700; margin-bottom: 12px; color: #111111;">Verified Client Review</h4>
        <div style="color: #F59E0B; margin-bottom: 8px; font-size: 0.9rem;">
          <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
        </div>
        <p style="font-size: 0.92rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 12px;">
          &ldquo;Best 3D LED signage manufacturer in Secunderabad! Ordered acrylic channel letters for our commercial showroom at S.D. Road. Mr. Marri Prasad Naidu gave personal attention to precision and delivered on time.&rdquo;
        </p>
        <div style="font-size: 0.8rem; font-weight: 700; color: #111111;">
          — Dr. R. Krishna • Secunderabad
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ==========================================================================
     7. DIRECT FACTORY QUOTATION / NEWSLETTER STRIP (Exact Reference Design)
     ========================================================================== -->
<div class="container">
  <div class="newsletter-dark-strip">
    <div class="newsletter-title-text">
      Sign Up For Direct Factory Quotations
    </div>

    <form action="<?= BASE_URL ?>/contact.php#quoteForm" method="GET" class="newsletter-pill-form">
      <input type="text" name="phone_quote" placeholder="Enter phone or email address..." required>
      <button type="submit">GET QUOTE</button>
    </form>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
