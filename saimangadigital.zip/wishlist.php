<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'My Saved Wishlist | Sai Manga Digital';

// Handle Add/Remove actions
if (isset($_GET['action'])) {
    $productId = (int)($_GET['id'] ?? 0);
    $redirect = BASE_URL . '/wishlist.php';
    if (!empty($_GET['redirect'])) {
        $candidate = $_GET['redirect'];
        if (str_starts_with($candidate, '/') || str_starts_with($candidate, BASE_URL)) {
            $redirect = $candidate;
        }
    }
    if ($productId > 0) {
        if ($_GET['action'] === 'add') {
            addToWishlist($productId);
            setFlash('success', 'Item saved to your wishlist!');
        } elseif ($_GET['action'] === 'remove') {
            removeFromWishlist($productId);
            setFlash('info', 'Item removed from your wishlist.');
        }
    }
    header('Location: ' . $redirect);
    exit;
}

$wishlistIds = getWishlist();
$products = [];
if (!empty($wishlistIds)) {
    $placeholders = implode(',', array_fill(0, count($wishlistIds), '?'));
    $stmt = $db->prepare("
        SELECT p.*, c.name as category_name, c.slug as category_slug 
        FROM products p 
        JOIN categories c ON p.category_id = c.id 
        WHERE p.id IN ($placeholders) AND p.is_active = 1
    ");
    $stmt->execute($wishlistIds);
    $products = $stmt->fetchAll();
}

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <h1 class="page-hero-title all-caps-title">My Wishlist</h1>
    <p class="page-hero-desc">Your curated list of custom signage &amp; print specifications saved for later.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container">
    
    <?php if (empty($products)): ?>
      <div style="background: var(--card-bg); border-radius: var(--radius-card); padding: 70px 20px; text-align: center; max-width: 600px; margin: 0 auto;">
        <i class="far fa-heart" style="font-size: 3.5rem; color: var(--text-light); margin-bottom: 20px;"></i>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: #111111; margin-bottom: 8px;">Your Wishlist is Empty</h2>
        <p style="color: var(--text-muted); margin-bottom: 24px; font-size: 0.95rem;">
          Save products you are planning for your showroom, clinic, cafe, or upcoming trade exhibition.
        </p>
        <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-primary pill-btn-lg">
          Browse Catalog &rarr;
        </a>
      </div>
    <?php else: ?>
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 28px; flex-wrap: wrap; gap: 12px;">
        <h2 style="font-size: 1.4rem; font-weight: 800; color: #111111; margin: 0;">
          Saved Products (<?= count($products) ?>)
        </h2>
        <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-outline pill-btn-sm">
          Continue Browsing
        </a>
      </div>

      <div class="products-grid-3">
        <?php foreach ($products as $prod): ?>
          <div class="product-card-minimal">
            <div class="product-card-thumb">
              <span class="product-badge-pill">
                <?= $prod['pricing_type'] === 'per_sqft' ? 'Per Sq.Ft' : 'Per Unit' ?>
              </span>
              <img src="<?= htmlspecialchars($prod['image']) ?>" alt="<?= htmlspecialchars($prod['name']) ?>" loading="lazy">
            </div>

            <div class="product-card-body">
              <div>
                <div class="product-cat-tag"><?= htmlspecialchars($prod['category_name']) ?></div>
                <h3 class="product-card-title">
                  <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($prod['slug']) ?>">
                    <?= htmlspecialchars($prod['name']) ?>
                  </a>
                </h3>
              </div>

              <div>
                <div class="product-pricing-row">
                  <span class="product-price-current">
                    &#8377;<?= number_format($prod['discount_price'] ?? $prod['base_price'], 2) ?>
                  </span>
                  <?php if (!empty($prod['discount_price']) && $prod['discount_price'] < $prod['base_price']): ?>
                    <span class="product-price-old">
                      &#8377;<?= number_format($prod['base_price'], 2) ?>
                    </span>
                  <?php endif; ?>
                  <span class="product-price-unit">/ <?= htmlspecialchars($prod['unit']) ?></span>
                </div>

                <div class="product-actions-row">
                  <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($prod['slug']) ?>" class="pill-btn pill-btn-primary pill-btn-sm" style="flex: 1;">
                    Configure &amp; Buy
                  </a>
                  <a href="<?= BASE_URL ?>/wishlist.php?action=remove&id=<?= $prod['id'] ?>" class="pill-btn pill-btn-outline pill-btn-sm" title="Remove from Wishlist" style="color: var(--brand-red) !important;">
                    <i class="fas fa-trash-alt"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
