<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Artwork & File Preparation Guidelines | Sai Manga Digital';
$whatsapp = getSetting('whatsapp', '918047663573');

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: #FFFFFF; padding: 6px 18px; border-radius: var(--radius-pill); font-size: 0.82rem; font-weight: 700; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <i class="fas fa-file-invoice text-primary"></i> Pre-Press Specifications
    </div>
    <h1 class="page-hero-title all-caps-title">Artwork &amp; File Guidelines</h1>
    <p class="page-hero-desc">Follow these technical recommendations to ensure razor-sharp color calibration and zero printing delays.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 1040px;">

    <!-- 4 Key Rules Overview Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 20px; margin-bottom: 48px;">
      <div style="background: var(--card-bg); border-radius: 18px; padding: 26px; text-align: center;">
        <div style="width: 50px; height: 50px; border-radius: 50%; background: var(--brand-blue-subtle); color: var(--brand-blue); display: flex; align-items: center; justify-content: center; font-size: 1.4rem; margin: 0 auto 14px;">
          <i class="fas fa-palette"></i>
        </div>
        <h4 style="font-size: 1.1rem; font-weight: 800; color: #111111; margin-bottom: 6px;">CMYK Color Mode</h4>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0;">Always export artwork in CMYK. RGB files may cause unexpected color shifts when printed.</p>
      </div>

      <div style="background: var(--card-bg); border-radius: 18px; padding: 26px; text-align: center;">
        <div style="width: 50px; height: 50px; border-radius: 50%; background: #FEF3C7; color: #D97706; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; margin: 0 auto 14px;">
          <i class="fas fa-compress-arrows-alt"></i>
        </div>
        <h4 style="font-size: 1.1rem; font-weight: 800; color: #111111; margin-bottom: 6px;">150 - 300 DPI</h4>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0;">150 DPI at actual 1:1 scale for large flex banners. 300 DPI for visiting cards &amp; vinyl.</p>
      </div>

      <div style="background: var(--card-bg); border-radius: 18px; padding: 26px; text-align: center;">
        <div style="width: 50px; height: 50px; border-radius: 50%; background: #DCFCE7; color: #15803D; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; margin: 0 auto 14px;">
          <i class="fas fa-vector-square"></i>
        </div>
        <h4 style="font-size: 1.1rem; font-weight: 800; color: #111111; margin-bottom: 6px;">Vector Curves / Outlines</h4>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0;">Convert all typography to curves (Ctrl+Q in CorelDraw, Shift+Ctrl+O in Illustrator).</p>
      </div>

      <div style="background: var(--card-bg); border-radius: 18px; padding: 26px; text-align: center;">
        <div style="width: 50px; height: 50px; border-radius: 50%; background: #FEE2E2; color: #B91C1C; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; margin: 0 auto 14px;">
          <i class="fas fa-border-style"></i>
        </div>
        <h4 style="font-size: 1.1rem; font-weight: 800; color: #111111; margin-bottom: 6px;">Bleed &amp; Safe Margins</h4>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0;">Keep critical text at least 2 inches inside borders for banner hemming and brass eyelets.</p>
      </div>
    </div>

    <!-- Detailed Guidelines Content -->
    <div class="resp-card" style="margin-bottom: 40px;">
      <h3 style="font-size: 1.35rem; font-weight: 800; color: #111111; margin-bottom: 18px;">Supported File Formats</h3>
      
      <div class="resp-grid-two-col" style="margin-bottom: 32px; gap: 24px;">
        <div style="background: #FFFFFF; border-radius: 14px; padding: 20px; border: 1px solid var(--border-subtle);">
          <strong style="color: var(--brand-blue); font-size: 1rem; display: block; margin-bottom: 6px;">
            <i class="fas fa-check-circle me-1"></i> Recommended Vector Formats (Preferred)
          </strong>
          <ul style="font-size: 0.88rem; color: var(--text-muted); line-height: 1.6; margin-left: 20px;">
            <li><strong>CorelDraw (.CDR)</strong> – Version X7 up to 2024 (Text converted to curves)</li>
            <li><strong>Adobe Illustrator (.AI / .EPS)</strong> – With embedded raster assets</li>
            <li><strong>Print-Ready PDF (.PDF)</strong> – High-Quality Print or PDF/X-1a standard</li>
          </ul>
        </div>

        <div style="background: #FFFFFF; border-radius: 14px; padding: 20px; border: 1px solid var(--border-subtle);">
          <strong style="color: #10B981; font-size: 1rem; display: block; margin-bottom: 6px;">
            <i class="fas fa-check-circle me-1"></i> Supported Raster / Bitmap Formats
          </strong>
          <ul style="font-size: 0.88rem; color: var(--text-muted); line-height: 1.6; margin-left: 20px;">
            <li><strong>Tagged Image File (.TIFF / .TIF)</strong> – LZW compression enabled</li>
            <li><strong>Adobe Photoshop (.PSD)</strong> – Flattened layers or grouped</li>
            <li><strong>JPEG / PNG (.JPG / .PNG)</strong> – High resolution at 100% actual dimensions</li>
          </ul>
        </div>
      </div>

      <h3 style="font-size: 1.35rem; font-weight: 800; color: #111111; margin-bottom: 14px;">Special Instructions by Category</h3>
      
      <div style="display: flex; flex-direction: column; gap: 14px; font-size: 0.92rem; color: var(--text-muted); line-height: 1.6;">
        <div style="padding: 14px 18px; background: #FFFFFF; border-radius: 12px; border-left: 4px solid var(--brand-blue);">
          <strong style="color: #111111;">3D Cast Acrylic LED Channel Letters:</strong> Vector files (.CDR or .AI) are required for CNC routers and automated letter benders. Provide the exact cut path with dimensions in inches or feet.
        </div>
        <div style="padding: 14px 18px; background: #FFFFFF; border-radius: 12px; border-left: 4px solid #F59E0B);">
          <strong style="color: #111111;">Custom Neon Flex Signs:</strong> Single-line center vector stroke or silhouette contour outlines. Specify the desired acrylic backing shape (contour cut-to-shape or rectangular base).
        </div>
        <div style="padding: 14px 18px; background: #FFFFFF; border-radius: 12px; border-left: 4px solid #10B981);">
          <strong style="color: #111111;">Roll-Up Standees (6x3 ft &amp; 6x2.5 ft):</strong> Standard design canvas is 36 inches wide &times; 72 inches high. Leave the bottom 3 inches free of critical text or logos, as this portion remains inside the aluminium base cassette.
        </div>
      </div>
    </div>

    <!-- Need Help with Artwork? -->
    <div style="background: #111111; color: #FFFFFF; border-radius: var(--radius-card); padding: 36px 44px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
      <div>
        <h3 style="font-size: 1.4rem; font-weight: 800; margin-bottom: 6px; color: #FFFFFF;">Need help converting or setting up your files?</h3>
        <p style="color: #AAAAAA; font-size: 0.92rem; margin: 0;">Our in-house pre-press designers at Madhuban Plaza will review your files free of charge.</p>
      </div>
      <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsapp) ?>?text=Hi%20Sai%20Manga%20Digital,%20please%20check%20my%20design%20artwork" target="_blank" class="pill-btn pill-btn-primary pill-btn-lg">
        <i class="fab fa-whatsapp me-2"></i> Free Artwork Check
      </a>
    </div>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

