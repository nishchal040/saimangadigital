<?php
require_once __DIR__ . '/config/init.php';

$orderNumber = isset($_GET['order']) ? trim($_GET['order']) : '';

if (empty($orderNumber)) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$stmt = $db->prepare("SELECT * FROM orders WHERE order_number = ?");
$stmt->execute([$orderNumber]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

// Fetch order items
$itemStmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->execute([$order['id']]);
$items = $itemStmt->fetchAll();

$pageTitle = 'Order Received: ' . htmlspecialchars($orderNumber) . ' | Sai Manga Digital';
include __DIR__ . '/includes/header.php';

$whatsapp = getSetting('whatsapp', '918047663573');
$upiId = getSetting('upi_id', 'saimanga@upi');
$upiName = getSetting('upi_name', 'Sai Manga Digital Solutions');
$upiUrl = "upi://pay?pa=" . urlencode($upiId) . "&pn=" . urlencode($upiName) . "&am=" . $order['total_amount'] . "&tn=" . urlencode("Order " . $order['order_number']) . "&cu=INR";
$qrApiUrl = "https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=" . urlencode($upiUrl);
?>

<div class="section-padding" style="background-color: #f8fafc;">
  <div class="container" style="max-width: 860px;">
    
    <!-- Success Celebration Card -->
    <div style="background: #ffffff; border-radius: var(--radius-lg); border: 1px solid var(--border-color); padding: 40px; box-shadow: var(--shadow-md); text-align: center; margin-bottom: 30px;">
      <div style="width: 80px; height: 80px; border-radius: 50%; background: #dcfce7; color: #15803d; display: inline-flex; align-items: center; justify-content: center; font-size: 2.5rem; margin-bottom: 20px;">
        <i class="fas fa-check"></i>
      </div>
      <h1 style="font-size: 2.2rem; font-weight: 800; color: var(--secondary); margin-bottom: 8px;">Order Placed Successfully!</h1>
      <p style="font-size: 1.05rem; color: var(--text-muted); max-width: 580px; margin: 0 auto 24px;">
        Thank you, <strong><?= htmlspecialchars($order['customer_name']) ?></strong>! Your order reference is <strong style="color: var(--primary);"><?= htmlspecialchars($order['order_number']) ?></strong>.
      </p>

      <div style="display: flex; justify-content: center; gap: 14px; flex-wrap: wrap;">
        <a href="<?= BASE_URL ?>/track-order.php?order=<?= urlencode($order['order_number']) ?>" class="btn btn-outline">
          <i class="fas fa-truck text-primary"></i> Track Production Status
        </a>
        <a href="<?= BASE_URL ?>/invoice.php?order=<?= urlencode($order['order_number']) ?>" target="_blank" class="btn btn-secondary">
          <i class="fas fa-print"></i> Print Official Invoice
        </a>
        <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsapp) ?>?text=<?= urlencode("Hello Sai Manga Digital! I just placed order #" . $order['order_number'] . " for total " . formatPrice($order['total_amount']) . ". Please verify my artwork and production timeline.") ?>" target="_blank" class="btn btn-whatsapp">
          <i class="fab fa-whatsapp"></i> Notify via WhatsApp
        </a>
      </div>
    </div>

    <!-- UPI QR Code Display (if UPI selected) -->
    <?php if ($order['payment_method'] === 'upi'): ?>
    <div class="resp-grid-success" style="background: #ffffff; border-radius: var(--radius-lg); border: 2px solid #38bdf8; padding: 28px; box-shadow: var(--shadow-md); margin-bottom: 30px;">
      <div style="text-align: center;">
        <img src="<?= $qrApiUrl ?>" alt="UPI QR Code" style="width: 200px; height: 200px; border-radius: var(--radius-md); border: 1px solid var(--border-color); margin: 0 auto; display: block;">
        <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 8px;">Scan with GPay, PhonePe, Paytm</div>
      </div>
      <div>
        <span class="badge bg-primary" style="margin-bottom: 8px;">Instant UPI Transfer</span>
        <h3 style="font-size: 1.3rem; font-weight: 800; color: var(--secondary); margin-bottom: 6px;">Pay <?= formatPrice($order['total_amount']) ?> via UPI</h3>
        <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 12px;">
          Send payment to official merchant ID: <strong style="color: var(--secondary); background: #f1f5f9; padding: 2px 8px; border-radius: 4px;"><?= htmlspecialchars($upiId) ?></strong>
        </p>
        <p style="font-size: 0.85rem; color: var(--text-muted); line-height: 1.5;">
          Once paid, please screenshot or message the UTR/Reference ID to our WhatsApp desk (+91 8047663573) or mention it during file verification.
        </p>
      </div>
    </div>
    <?php endif; ?>

    <!-- Order Items Breakdown -->
    <div class="resp-card" style="background: #ffffff; border: 1px solid var(--border-color);">
      <h3 style="font-size: 1.2rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border-color);">
        Ordered Products &amp; Specifications
      </h3>

      <div style="display: flex; flex-direction: column; gap: 16px; margin-bottom: 24px;">
        <?php foreach ($items as $item): ?>
        <div style="display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 16px; border-bottom: 1px solid var(--border-light); font-size: 0.92rem;">
          <div>
            <strong style="color: var(--secondary); font-size: 1rem;"><?= htmlspecialchars($item['product_name']) ?></strong>
            <div style="font-size: 0.82rem; color: var(--text-muted); margin-top: 4px;">
              Qty: <?= $item['quantity'] ?>
              <?php if ($item['pricing_type'] === 'per_sqft' && $item['width'] > 0): ?>
                • Size: <?= $item['width'] ?> ft &times; <?= $item['height'] ?> ft (<?= number_format($item['total_sqft'], 2) ?> sq.ft)
              <?php endif; ?>
              <?php if (!empty($item['material_selected'])): ?>
                • Material: <?= htmlspecialchars($item['material_selected']) ?>
              <?php endif; ?>
              <?php if (!empty($item['finish_selected'])): ?>
                • Finish: <?= htmlspecialchars($item['finish_selected']) ?>
              <?php endif; ?>
            </div>
            <?php if (!empty($item['custom_notes'])): ?>
              <div style="font-size: 0.8rem; color: #1e40af; margin-top: 4px; background: #eff6ff; padding: 4px 8px; border-radius: 4px;">
                <i class="fas fa-comment-dots me-1"></i> <?= htmlspecialchars($item['custom_notes']) ?>
              </div>
            <?php endif; ?>
          </div>
          <strong style="color: var(--secondary); font-size: 1.05rem; white-space: nowrap;">
            <?= formatPrice($item['item_total']) ?>
          </strong>
        </div>
        <?php endforeach; ?>
      </div>

      <!-- Financial Totals -->
      <div style="max-width: 340px; margin-left: auto; display: flex; flex-direction: column; gap: 10px; font-size: 0.92rem;">
        <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
          <span>Subtotal</span>
          <strong style="color: var(--secondary);"><?= formatPrice($order['subtotal']) ?></strong>
        </div>
        <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
          <span>GST (18%)</span>
          <strong style="color: var(--secondary);"><?= formatPrice($order['tax_amount']) ?></strong>
        </div>
        <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
          <span>Delivery</span>
          <strong style="color: var(--secondary);"><?= $order['shipping_fee'] == 0 ? 'FREE' : formatPrice($order['shipping_fee']) ?></strong>
        </div>
        <div style="display: flex; justify-content: space-between; font-size: 1.25rem; color: var(--secondary); padding-top: 10px; border-top: 2px dashed var(--border-color);">
          <strong>Total Paid/Payable</strong>
          <strong style="color: var(--primary);"><?= formatPrice($order['total_amount']) ?></strong>
        </div>
      </div>
    </div>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

