# Sai Manga Digital - Premium E-Commerce Website & Admin Backoffice

An agency-grade, responsive e-commerce web platform engineered for **Sai Manga Digital** (Instagram: [@saimangadigital](https://www.instagram.com/saimangadigital)), Secunderabad & Hyderabad's premier signage, 3D acrylic LED channel letters, and large-format flex printing enterprise established in 1994.

Built using clean, modern PHP 8, SQLite (auto-booting with zero configuration) and MySQL / MariaDB (production-ready schema included).

---

## 🌟 Key Features

### 🛍️ Client & Customer Storefront
1. **Interactive Sqrft Live Price Estimator (`/calculator.php`)**:
   - Calculates custom square footage for flex banners, 3D LED acrylic letters, vinyl stickers, and sunboards.
   - Live unit conversions (Feet & Inches), framework addons, and on-site installation estimates.
2. **Product Detail Configurator (`/product.php`)**:
   - Dynamic dimension inputs (Width &times; Height in feet), live area calculation, and instant cost updates.
   - Material/thickness variant selector (3mm Cast Acrylic, 5mm, Titanium Gold, etc.).
   - Artwork upload support (PDF, CDR, AI, PSD, PNG, JPG).
   - **1-Click WhatsApp Order Button**: Pre-fills product details, dimensions, and estimated price directly into a WhatsApp message.
3. **Shopping Cart & Checkout (`/cart.php`, `/checkout.php`)**:
   - Delivery or In-Store Pickup at Madhuban Plaza, S.D. Road, Secunderabad.
   - Instant UPI payment QR code generator (`saimanga@upi`), Cash on Delivery / Pay on Pickup.
4. **Real-Time Order Tracking (`/track-order.php`)**:
   - Visual 6-stage production stepper: *Order Received &rarr; Design Proofing &rarr; Printing / Laser CNC &rarr; QC &amp; Packing &rarr; Dispatched &rarr; Delivered*.
5. **Printable Tax Invoice (`/invoice.php`)**:
   - Professional printable invoice with GST breakdown, terms, and authorized signature block.
6. **Social & Instagram Feed Showcase**:
   - Prominently showcases `@saimangadigital` with direct links to their Instagram portfolio.

---

### 🛡️ Admin Backoffice Dashboard (`/admin/`)
1. **Executive Dashboard (`/admin/index.php`)**:
   - Real-time KPI cards: Lifetime Revenue, Total Orders, Active Production Queue, and New Quotation Inquiries.
   - Recent orders and instant status indicators.
2. **Catalog Management (`/admin/products.php`, `/admin/product-form.php`)**:
   - Full CRUD: Add, edit, and delete signage and print products.
   - Switch between **Fixed pricing** and **Custom Per Sq.Ft** calculation models.
   - Image upload or remote CDN image support.
   - Feature products on the homepage.
3. **Order & Production Queue Manager (`/admin/orders.php`, `/admin/order-detail.php`)**:
   - Filter orders by status (*Pending, In Design, Printing, Ready, Dispatched, Delivered*).
   - Change production status and payment status in 1 click.
   - Assign courier tracking / waybill numbers.
   - Download uploaded customer artwork files.
   - Direct button to chat with the customer on WhatsApp.
4. **Custom Quotation Inquiries (`/admin/quotes.php`)**:
   - Review incoming architectural signage briefs submitted by clients through the website.
   - Direct 1-click WhatsApp quote responder.
5. **Category Manager (`/admin/categories.php`)**:
   - Organize sign boards, roll-up standees, flex printing, LED displays, and corporate stationery.
6. **Store Settings (`/admin/settings.php`)**:
   - Edit phone numbers, official WhatsApp desk, store address, Instagram handle, GST rate, shipping fees, and UPI details.

---

## 🚀 Quick Start (Running Locally)

### Option A: Using Built-in PHP Server (Fastest, 0 Dependencies)
Make sure PHP is installed (or use the included XAMPP PHP):

```powershell
# Open terminal inside the project directory:
cd C:\Users\nishc\Desktop\SaiMangaDigital

# Launch PHP server:
& "C:\xampp\php\php.exe" -S localhost:8000
```
Open your browser and navigate to:
- **Storefront Website:** [http://localhost:8000](http://localhost:8000)
- **Admin Panel:** [http://localhost:8000/admin/login.php](http://localhost:8000/admin/login.php)

> **Default Admin Credentials:**
> - **Username:** `admin`
> - **Password:** `admin123`
> *(A convenient "Auto-Fill" button is also present on the login screen!)*

---

### Option B: Running in XAMPP (Apache & MySQL)
1. Copy or link this folder into `C:\xampp\htdocs\SaiMangaDigital`.
2. Start **Apache** and **MySQL** in XAMPP Control Panel.
3. Open [http://localhost/phpmyadmin](http://localhost/phpmyadmin) and import `database/schema.sql`.
4. Update `config/database.php` if you wish to use MySQL (`$driver = 'mysql'`). If left default, it runs immediately on SQLite without any setup needed!
5. Access via: `http://localhost/SaiMangaDigital`

---

## 📁 Directory Structure

```
SaiMangaDigital/
├── config/
│   ├── database.php          # Unified PDO connection (SQLite + MySQL)
│   ├── init.php              # Bootstrap, session & settings loader
│   └── seed_data.php         # Initial rich demo data (products, categories, admin)
├── database/
│   ├── saimanga.sqlite       # Local auto-created SQLite database
│   └── schema.sql            # Full MySQL schema export
├── includes/
│   ├── header.php            # Global header, announcement bar, nav
│   ├── footer.php            # Footer, Instagram links, floating WhatsApp
│   ├── functions.php         # Helpers, cart engine, formatters
│   └── admin_layout.php      # Reusable admin sidebar & topbar layout
├── assets/
│   ├── css/
│   │   ├── style.css         # Modern storefront styling & responsive grid
│   │   └── admin.css         # Backoffice admin dashboard design
│   ├── js/
│   │   ├── main.js           # Live calculator, toasts, cart interactivity
│   │   └── admin.js          # Admin search filters & status triggers
│   └── images/
│       ├── logo.svg          # Modern Sai Manga Digital logo
│       └── logo-light.svg    # Inverted logo for dark surfaces
├── uploads/
│   ├── artwork/              # Uploaded customer print design files
│   └── products/             # Uploaded product catalog photos
├── api/
│   ├── cart.php              # AJAX cart actions
│   └── calculate.php         # Live price calculation API
├── admin/
│   ├── index.php             # Admin Dashboard (KPIs, recent orders & quotes)
│   ├── login.php             # Admin authentication
│   ├── logout.php            # Sign out
│   ├── products.php          # Product catalog manager
│   ├── product-form.php      # Add / Edit product
│   ├── categories.php        # Manage categories
│   ├── orders.php            # Order pipeline manager
│   ├── order-detail.php      # Detailed order & status updater
│   ├── quotes.php            # Custom quotation inquiries
│   └── settings.php          # Store contact, WhatsApp & UPI configurations
├── index.php                 # Homepage (Hero, categories, calculator, Instagram feed)
├── shop.php                  # Filterable product catalog
├── product.php               # Product detail & custom dimension configurator
├── cart.php                  # Shopping cart
├── checkout.php              # Delivery, pickup & payment selection
├── order-success.php         # Order confirmation with UPI QR & WhatsApp ping
├── track-order.php           # Real-time visual production progress tracker
├── calculator.php            # Standalone Sqrft Price Estimator
├── about.php                 # 30+ years legacy & factory history
├── contact.php               # Secunderabad map & quote request form
└── invoice.php               # Official printable / PDF tax invoice
```

---

## 🏢 Business Identity & Credentials

* **Company:** Sai Manga Digital
* **Established:** 1994 (30+ Years Legacy)
* **Proprietor / Managing Director:** Marri Prasad Naidu
* **Google Maps Location:** [https://maps.app.goo.gl/cNSaRii6R44K9t4c8](https://maps.app.goo.gl/cNSaRii6R44K9t4c8)
* **Google Rating:** 4.8 ★ / 5.0 (68+ Verified Client Reviews)
* **Address:** Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza (Beside Manyavar Showroom, Opp. Minerva Complex), Sarojini Devi (S.D.) Road, Secunderabad, Telangana - 500003
* **Business Hours:** Monday – Saturday: 9:30 AM to 9:00 PM (Sunday Closed)
* **Contact Phones:** +91 8047663573 (Sales Desk) / +91 98490 12345 (Direct / WhatsApp)
* **Official WhatsApp Desk:** +91 8047663573
* **Instagram:** [@saimangadigital](https://www.instagram.com/saimangadigital)
* **Brand Colors:**
  - Royal Indigo Blue: `#342784` (Face & Block Typography)
  - Scarlet Red: `#D92C1C` (Iconic Double Triangle Accents in "MANGA")


