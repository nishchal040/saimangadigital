<?php
require_once dirname(__DIR__) . '/config/init.php';
requireAdminAuth();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$isEdit = ($id > 0);
$pageTitle = $isEdit ? 'Edit Product' : 'Add New Product';
$activePage = $isEdit ? 'products' : 'product_add';
$error = '';

// Load product if editing
$product = [
    'name' => '',
    'slug' => '',
    'category_id' => 1,
    'short_desc' => '',
    'description' => '',
    'base_price' => '0.00',
    'discount_price' => '',
    'pricing_type' => 'fixed',
    'unit' => 'piece',
    'min_quantity' => 1,
    'min_sqft' => '1.00',
    'default_width' => '1.00',
    'default_height' => '1.00',
    'sku' => '',
    'image' => '',
    'material_options' => '',
    'finish_options' => '',
    'is_featured' => 0,
    'is_active' => 1
];

if ($isEdit) {
    $stmt = $db->prepare("SELECT * FROM products WHERE id = ?");
    $stmt->execute([$id]);
    $existing = $stmt->fetch();
    if ($existing) {
        $product = array_merge($product, $existing);
    } else {
        header('Location: ' . BASE_URL . '/admin/products.php');
        exit;
    }
}

// Fetch categories
$categories = $db->query("SELECT * FROM categories ORDER BY display_order ASC")->fetchAll();

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $slug = sanitize($_POST['slug'] ?? '');
    if (empty($slug)) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
    }
    $categoryId = (int)($_POST['category_id'] ?? 1);
    $shortDesc = sanitize($_POST['short_desc'] ?? '');
    $description = $_POST['description'] ?? '';
    $basePrice = (float)($_POST['base_price'] ?? 0);
    $discountPrice = !empty($_POST['discount_price']) ? (float)$_POST['discount_price'] : null;
    $pricingType = sanitize($_POST['pricing_type'] ?? 'fixed');
    $unit = sanitize($_POST['unit'] ?? 'piece');
    $sku = sanitize($_POST['sku'] ?? '');
    $defaultWidth = (float)($_POST['default_width'] ?? 1.0);
    $defaultHeight = (float)($_POST['default_height'] ?? 1.0);
    $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    $image = sanitize($_POST['image_url'] ?? $product['image']);

    // Handle File Upload if provided
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        $origName = $_FILES['product_image']['name'];
        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'svg'])) {
            $newName = 'prod_' . time() . '_' . rand(100, 999) . '.' . $ext;
            $target = APP_ROOT . '/uploads/products/' . $newName;
            if (move_uploaded_file($_FILES['product_image']['tmp_name'], $target)) {
                $image = BASE_URL . '/uploads/products/' . $newName;
            }
        }
    }

    if (empty($name) || $basePrice <= 0 || empty($image)) {
        $error = 'Please provide product name, base price, and an image.';
    } else {
        if ($isEdit) {
            $updateStmt = $db->prepare("
                UPDATE products SET
                    category_id = ?, name = ?, slug = ?, short_desc = ?, description = ?,
                    base_price = ?, discount_price = ?, pricing_type = ?, unit = ?,
                    default_width = ?, default_height = ?, sku = ?, image = ?,
                    is_featured = ?, is_active = ?
                WHERE id = ?
            ");
            $updateStmt->execute([
                $categoryId, $name, $slug, $shortDesc, $description,
                $basePrice, $discountPrice, $pricingType, $unit,
                $defaultWidth, $defaultHeight, $sku, $image,
                $isFeatured, $isActive, $id
            ]);
            setFlash('success', 'Product updated successfully.');
        } else {
            $insertStmt = $db->prepare("
                INSERT INTO products (
                    category_id, name, slug, short_desc, description,
                    base_price, discount_price, pricing_type, unit,
                    default_width, default_height, sku, image,
                    is_featured, is_active
                ) VALUES (
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?
                )
            ");
            $insertStmt->execute([
                $categoryId, $name, $slug, $shortDesc, $description,
                $basePrice, $discountPrice, $pricingType, $unit,
                $defaultWidth, $defaultHeight, $sku, $image,
                $isFeatured, $isActive
            ]);
            setFlash('success', 'New product created successfully.');
        }

        header('Location: ' . BASE_URL . '/admin/products.php');
        exit;
    }
}

include APP_ROOT . '/includes/admin_layout.php';
?>

<div class="admin-card" style="max-width: 900px; margin: 0 auto;">
  <div class="admin-card-header">
    <h3 class="admin-card-title"><?= $isEdit ? 'Edit Product: ' . htmlspecialchars($product['name']) : 'Create New Product' ?></h3>
    <a href="<?= BASE_URL ?>/admin/products.php" class="btn btn-outline btn-sm">&larr; Back to Catalog</a>
  </div>

  <div class="admin-card-body">
    <?php if (!empty($error)): ?>
      <div style="background: #fee2e2; border-left: 4px solid var(--danger); padding: 14px 18px; border-radius: var(--radius-sm); margin-bottom: 20px; color: #b91c1c; font-weight: 600;">
        <i class="fas fa-exclamation-circle me-1"></i> <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <form action="" method="POST" enctype="multipart/form-data">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Product Title *</label>
          <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($product['name']) ?>" required style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">URL Slug (auto-generated if empty)</label>
          <input type="text" name="slug" class="form-control" value="<?= htmlspecialchars($product['slug']) ?>" placeholder="e.g. 3d-acrylic-led-board" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Category *</label>
          <select name="category_id" class="form-select" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
            <?php foreach ($categories as $cat): ?>
              <option value="<?= $cat['id'] ?>" <?= $product['category_id'] == $cat['id'] ? 'selected' : '' ?>>
                <?= htmlspecialchars($cat['name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">SKU Code</label>
          <input type="text" name="sku" class="form-control" value="<?= htmlspecialchars($product['sku']) ?>" placeholder="e.g. SMD-SIGN-01" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Pricing Model *</label>
          <select name="pricing_type" class="form-select" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
            <option value="fixed" <?= $product['pricing_type'] === 'fixed' ? 'selected' : '' ?>>Fixed Price (Per Piece/Pack)</option>
            <option value="per_sqft" <?= $product['pricing_type'] === 'per_sqft' ? 'selected' : '' ?>>Custom Sqr.Ft Calculation (Width x Height)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Unit Label</label>
          <input type="text" name="unit" class="form-control" value="<?= htmlspecialchars($product['unit']) ?>" placeholder="sqft, piece, pack, set" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Base Regular Price (₹) *</label>
          <input type="number" name="base_price" step="0.5" class="form-control" value="<?= htmlspecialchars($product['base_price']) ?>" required style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Offer / Discount Price (₹)</label>
          <input type="number" name="discount_price" step="0.5" class="form-control" value="<?= htmlspecialchars($product['discount_price'] ?? '') ?>" placeholder="Leave blank if no discount" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Default Width (Feet)</label>
          <input type="number" name="default_width" step="0.5" class="form-control" value="<?= htmlspecialchars($product['default_width'] ?? '1.0') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Default Height (Feet)</label>
          <input type="number" name="default_height" step="0.5" class="form-control" value="<?= htmlspecialchars($product['default_height'] ?? '1.0') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Product Image URL or Upload</label>
        <input type="text" name="image_url" class="form-control" value="<?= htmlspecialchars($product['image']) ?>" placeholder="https://images.unsplash.com/... or paste image URL" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border); margin-bottom: 8px;">
        <input type="file" name="product_image" class="form-control" style="background: #ffffff; color: var(--secondary); border: 1px dashed var(--admin-border);">
        <?php if (!empty($product['image'])): ?>
          <div style="margin-top: 10px;">
            <img src="<?= htmlspecialchars($product['image']) ?>" alt="Preview" style="height: 90px; border-radius: 8px; border: 1px solid var(--admin-border);">
          </div>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Short Teaser / Subtitle</label>
        <input type="text" name="short_desc" class="form-control" value="<?= htmlspecialchars($product['short_desc'] ?? '') ?>" placeholder="Brief 1-line product feature" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
      </div>

      <div class="form-group">
        <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Full Rich Description (HTML supported)</label>
        <textarea name="description" rows="5" class="form-control" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border); font-family: monospace; font-size: 0.9rem;"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
      </div>

      <div style="display: flex; gap: 24px; margin-bottom: 24px;">
        <label style="display: flex; align-items: center; gap: 8px; font-size: 0.9rem; font-weight: 600; cursor: pointer;">
          <input type="checkbox" name="is_featured" value="1" <?= $product['is_featured'] ? 'checked' : '' ?> style="accent-color: var(--primary); transform: scale(1.2);">
          <span>Feature on Homepage Best Sellers</span>
        </label>
        <label style="display: flex; align-items: center; gap: 8px; font-size: 0.9rem; font-weight: 600; cursor: pointer;">
          <input type="checkbox" name="is_active" value="1" <?= $product['is_active'] ? 'checked' : '' ?> style="accent-color: var(--primary); transform: scale(1.2);">
          <span>Active &amp; Published in Shop</span>
        </label>
      </div>

      <div style="display: flex; gap: 14px;">
        <button type="submit" class="btn btn-primary btn-lg">
          <i class="fas fa-save me-1"></i> <?= $isEdit ? 'Save Changes' : 'Create Product' ?>
        </button>
        <a href="<?= BASE_URL ?>/admin/products.php" class="btn btn-secondary btn-lg">Cancel</a>
      </div>
    </form>
  </div>
</div>

  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>

