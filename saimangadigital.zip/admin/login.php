<?php
require_once dirname(__DIR__) . '/config/init.php';

$pageTitle = 'Admin Sign In | Sai Manga Digital';
$error = '';

if (isAdminLoggedIn()) {
    header('Location: ' . BASE_URL . '/admin/index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        $stmt = $db->prepare("SELECT * FROM admins WHERE username = ? OR email = ?");
        $stmt->execute([$username, $username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_user'] = $admin['username'];
            $_SESSION['admin_name'] = $admin['full_name'];
            $_SESSION['admin_role'] = $admin['role'];

            // Update last login
            $update = $db->prepare("UPDATE admins SET last_login = CURRENT_TIMESTAMP WHERE id = ?");
            $update->execute([$admin['id']]);

            header('Location: ' . BASE_URL . '/admin/index.php');
            exit;
        } else {
            $error = 'Invalid username/email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/favicon.png">
  <link rel="shortcut icon" href="<?= BASE_URL ?>/assets/images/favicon.ico">
  <link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>/assets/images/logo.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  
  <style>
    body {
      background: radial-gradient(circle at 10% 20%, #191047 0%, #0c0824 90%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
      font-family: 'Plus Jakarta Sans', sans-serif;
    }
    .login-card {
      background: #ffffff;
      border-radius: 16px;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.45);
      width: 100%;
      max-width: 440px;
      padding: 40px;
      position: relative;
    }
    .brand-header {
      text-align: center;
      margin-bottom: 28px;
    }
    .brand-header img {
      height: 52px;
      width: auto;
      max-width: 220px;
      object-fit: contain;
      margin: 0 auto 14px;
      display: block;
    }
    .brand-header h2 {
      font-size: 1.4rem;
      font-weight: 800;
      color: #0f172a;
      margin: 0 0 4px;
    }
    .brand-header p {
      font-size: 0.85rem;
      color: #64748b;
      margin: 0;
    }
    .demo-pill {
      background: #eef0fa;
      border: 1px solid #c7d2fe;
      border-radius: 8px;
      padding: 10px 14px;
      font-size: 0.8rem;
      color: #342784;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .demo-pill button {
      background: #342784;
      color: #ffffff;
      border: none;
      padding: 3px 8px;
      border-radius: 4px;
      font-size: 0.75rem;
      cursor: pointer;
      font-weight: 700;
    }
  </style>
</head>
<body>

<div class="login-card">
  <div class="brand-header">
    <img src="<?= BASE_URL ?>/assets/images/logo.svg" alt="Sai Manga Digital">
    <h2>Admin Staff Portal</h2>
    <p>Sign in to manage orders, catalog &amp; fabrication pipeline</p>
  </div>

  <div class="demo-pill">
    <div>
      <strong>Demo Admin:</strong> <code>admin</code> / <code>admin123</code>
    </div>
    <button type="button" onclick="fillDemo()">Auto-Fill</button>
  </div>

  <?php if (!empty($error)): ?>
    <div style="background: #fee2e2; border-left: 4px solid #ef4444; padding: 12px 16px; border-radius: 6px; margin-bottom: 20px; color: #b91c1c; font-size: 0.85rem; font-weight: 600;">
      <i class="fas fa-exclamation-circle me-1"></i> <?= htmlspecialchars($error) ?>
    </div>
  <?php endif; ?>

  <form action="" method="POST">
    <div class="form-group" style="margin-bottom: 18px;">
      <label class="form-label" style="color: #0f172a; font-size: 0.85rem;">Username or Email</label>
      <div style="position: relative;">
        <input type="text" name="username" id="usernameInput" class="form-control" placeholder="admin" required style="background: #f8fafc; color: #0f172a; border: 1.5px solid #e2e8f0; padding-left: 38px;">
        <i class="fas fa-user" style="position: absolute; left: 14px; top: 14px; color: #94a3b8; font-size: 0.9rem;"></i>
      </div>
    </div>

    <div class="form-group" style="margin-bottom: 24px;">
      <label class="form-label" style="color: #0f172a; font-size: 0.85rem;">Password</label>
      <div style="position: relative;">
        <input type="password" name="password" id="passwordInput" class="form-control" placeholder="••••••••" required style="background: #f8fafc; color: #0f172a; border: 1.5px solid #e2e8f0; padding-left: 38px;">
        <i class="fas fa-lock" style="position: absolute; left: 14px; top: 14px; color: #94a3b8; font-size: 0.9rem;"></i>
      </div>
    </div>

    <button type="submit" class="btn btn-primary btn-lg" style="width: 100%; justify-content: center; font-size: 1rem; padding: 12px;">
      <i class="fas fa-sign-in-alt me-2"></i> Log In to Dashboard
    </button>
  </form>

  <div style="text-align: center; margin-top: 24px; padding-top: 16px; border-top: 1px solid #f1f5f9;">
    <a href="<?= BASE_URL ?>/index.php" style="font-size: 0.85rem; color: #64748b; font-weight: 600;">
      &larr; Return to Storefront
    </a>
  </div>
</div>

<script>
function fillDemo() {
    document.getElementById('usernameInput').value = 'admin';
    document.getElementById('passwordInput').value = 'admin123';
}
</script>

</body>
</html>

