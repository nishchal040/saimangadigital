<?php
require_once dirname(__DIR__) . '/config/init.php';
requireAdminAuth();

$pageTitle = 'Dashboard Overview';
$activePage = 'dashboard';

// Compute KPI Metrics
$totalSales = (float)$db->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE order_status != 'cancelled'")->fetchColumn();
$totalOrders = (int)$db->query("SELECT COUNT(*) FROM orders")->fetchColumn();
$activeProduction = (int)$db->query("SELECT COUNT(*) FROM orders WHERE order_status IN ('pending', 'in_design', 'printing', 'ready')")->fetchColumn();
$pendingQuotes = (int)$db->query("SELECT COUNT(*) FROM quotes WHERE status = 'new'")->fetchColumn();

// Recent Orders
$recentOrders = $db->query("
    SELECT * FROM orders 
    ORDER BY id DESC 
    LIMIT 6
")->fetchAll();

// Recent Quotes
$recentQuotes = $db->query("
    SELECT * FROM quotes 
    ORDER BY id DESC 
    LIMIT 5
")->fetchAll();

include APP_ROOT . '/includes/admin_layout.php';
?>

<!-- KPI Stats Grid -->
<div class="admin-stats-grid">
  <!-- Total Revenue -->
  <div class="stat-card">
    <div class="stat-card-info">
      <h4>Total Revenue</h4>
      <div class="stat-card-value"><?= formatPrice($totalSales) ?></div>
      <div class="stat-card-sub"><i class="fas fa-arrow-up"></i> Lifetime Gross Sales</div>
    </div>
    <div class="stat-card-icon icon-emerald">
      <i class="fas fa-rupee-sign"></i>
    </div>
  </div>

  <!-- Total Orders -->
  <div class="stat-card">
    <div class="stat-card-info">
      <h4>Total Orders</h4>
      <div class="stat-card-value"><?= $totalOrders ?></div>
      <div class="stat-card-sub"><i class="fas fa-shopping-bag"></i> All Time Placed</div>
    </div>
    <div class="stat-card-icon icon-blue">
      <i class="fas fa-receipt"></i>
    </div>
  </div>

  <!-- In Production -->
  <div class="stat-card">
    <div class="stat-card-info">
      <h4>In Production</h4>
      <div class="stat-card-value"><?= $activeProduction ?></div>
      <div class="stat-card-sub" style="color: #f59e0b;"><i class="fas fa-cogs"></i> Active Workshop Queue</div>
    </div>
    <div class="stat-card-icon icon-amber">
      <i class="fas fa-print"></i>
    </div>
  </div>

  <!-- New Quotes -->
  <div class="stat-card">
    <div class="stat-card-info">
      <h4>New Quotes</h4>
      <div class="stat-card-value"><?= $pendingQuotes ?></div>
      <div class="stat-card-sub" style="color: #8b5cf6;"><i class="fas fa-bell"></i> Inquiries Needing Review</div>
    </div>
    <div class="stat-card-icon icon-purple">
      <i class="fas fa-file-invoice"></i>
    </div>
  </div>
</div>

<!-- Quick Action Shortcuts Bar -->
<div style="display: flex; gap: 14px; margin-bottom: 28px; flex-wrap: wrap;">
  <a href="<?= BASE_URL ?>/admin/product-form.php" class="btn btn-primary btn-sm">
    <i class="fas fa-plus-circle"></i> Add New Product
  </a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=printing" class="btn btn-outline btn-sm">
    <i class="fas fa-print"></i> View In-Printing Orders
  </a>
  <a href="<?= BASE_URL ?>/admin/quotes.php" class="btn btn-outline btn-sm">
    <i class="fas fa-comments-dollar"></i> Review Custom Quotes (<?= $pendingQuotes ?>)
  </a>
  <a href="<?= BASE_URL ?>/calculator.php" target="_blank" class="btn btn-outline btn-sm">
    <i class="fas fa-calculator"></i> Test Live Sqrft Estimator
  </a>
</div>

<!-- Recent Orders Table Card -->
<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title"><i class="fas fa-history text-primary me-2"></i> Recent Customer Orders</h3>
    <a href="<?= BASE_URL ?>/admin/orders.php" style="font-size: 0.85rem; font-weight: 700; color: var(--primary);">
      View All Orders &rarr;
    </a>
  </div>
  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Order #</th>
          <th>Customer</th>
          <th>Delivery / Pickup</th>
          <th>Amount</th>
          <th>Payment</th>
          <th>Production Status</th>
          <th>Date</th>
          <th style="text-align: right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($recentOrders)): ?>
          <tr><td colspan="8" style="text-align: center; padding: 30px; color: var(--admin-text-muted);">No orders found.</td></tr>
        <?php else: ?>
          <?php foreach ($recentOrders as $o): ?>
          <tr>
            <td>
              <strong style="color: var(--secondary); font-family: monospace; font-size: 0.95rem;">
                <a href="<?= BASE_URL ?>/admin/order-detail.php?id=<?= $o['id'] ?>"><?= htmlspecialchars($o['order_number']) ?></a>
              </strong>
            </td>
            <td>
              <div style="font-weight: 700; color: var(--secondary);"><?= htmlspecialchars($o['customer_name']) ?></div>
              <div style="font-size: 0.78rem; color: var(--admin-text-muted);"><?= htmlspecialchars($o['customer_phone']) ?></div>
            </td>
            <td>
              <?php if ($o['delivery_type'] === 'pickup'): ?>
                <span class="badge bg-secondary"><i class="fas fa-store"></i> Store Pickup</span>
              <?php else: ?>
                <span class="badge bg-info"><i class="fas fa-truck"></i> Delivery</span>
              <?php endif; ?>
            </td>
            <td>
              <strong style="color: var(--secondary); font-size: 0.95rem;"><?= formatPrice($o['total_amount']) ?></strong>
            </td>
            <td>
              <?= getPaymentStatusBadge($o['payment_status']) ?>
            </td>
            <td>
              <?= getOrderStatusBadge($o['order_status']) ?>
            </td>
            <td style="font-size: 0.82rem; color: var(--admin-text-muted);">
              <?= timeAgo($o['created_at']) ?>
            </td>
            <td style="text-align: right;">
              <a href="<?= BASE_URL ?>/admin/order-detail.php?id=<?= $o['id'] ?>" class="btn btn-outline btn-sm" title="View & Manage">
                <i class="fas fa-eye"></i> Manage
              </a>
              <a href="<?= BASE_URL ?>/invoice.php?order=<?= urlencode($o['order_number']) ?>" target="_blank" class="btn btn-secondary btn-sm" title="Print Invoice">
                <i class="fas fa-print"></i>
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Recent Custom Quotations Card -->
<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title"><i class="fas fa-comment-dots text-primary me-2"></i> Recent Custom Quote Requests</h3>
    <a href="<?= BASE_URL ?>/admin/quotes.php" style="font-size: 0.85rem; font-weight: 700; color: var(--primary);">
      View All Inquiries &rarr;
    </a>
  </div>
  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Quote #</th>
          <th>Client &amp; Company</th>
          <th>Service Required</th>
          <th>Dimensions</th>
          <th>Qty</th>
          <th>Status</th>
          <th>Date</th>
          <th style="text-align: right;">WhatsApp Contact</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($recentQuotes)): ?>
          <tr><td colspan="8" style="text-align: center; padding: 30px; color: var(--admin-text-muted);">No quotation requests.</td></tr>
        <?php else: ?>
          <?php foreach ($recentQuotes as $q): ?>
          <tr>
            <td>
              <strong style="color: var(--secondary); font-family: monospace;"><?= htmlspecialchars($q['quote_number']) ?></strong>
            </td>
            <td>
              <div style="font-weight: 700;"><?= htmlspecialchars($q['customer_name']) ?></div>
              <?php if (!empty($q['company_name'])): ?>
                <div style="font-size: 0.78rem; color: var(--admin-text-muted);"><?= htmlspecialchars($q['company_name']) ?></div>
              <?php endif; ?>
            </td>
            <td>
              <span style="font-weight: 600; color: var(--secondary);"><?= htmlspecialchars($q['service_needed']) ?></span>
            </td>
            <td style="font-size: 0.85rem; color: var(--admin-text-muted);">
              <?= htmlspecialchars($q['dimensions'] ?: 'Not specified') ?>
            </td>
            <td><?= $q['quantity'] ?></td>
            <td>
              <?php
                $statusColors = [
                  'new' => 'bg-danger text-white',
                  'in_review' => 'bg-warning text-dark',
                  'quoted' => 'bg-info text-white',
                  'closed' => 'bg-success text-white'
                ];
                $bgClass = $statusColors[$q['status']] ?? 'bg-secondary';
              ?>
              <span class="badge <?= $bgClass ?>"><?= strtoupper(htmlspecialchars($q['status'])) ?></span>
            </td>
            <td style="font-size: 0.82rem; color: var(--admin-text-muted);">
              <?= timeAgo($q['created_at']) ?>
            </td>
            <td style="text-align: right;">
              <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $q['customer_phone']) ?>?text=<?= urlencode("Hello " . $q['customer_name'] . ", this is Sai Manga Digital regarding your quotation request #" . $q['quote_number'] . " for " . $q['service_needed'] . ".") ?>" target="_blank" class="btn btn-whatsapp btn-sm">
                <i class="fab fa-whatsapp"></i> Chat
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>

