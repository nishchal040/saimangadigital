<?php
require_once dirname(__DIR__) . '/config/init.php';
requireAdminAuth();

$pageTitle = 'Category Management';
$activePage = 'categories';
$error = '';

// Handle Add / Edit Category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_category'])) {
    $catId = (int)($_POST['category_id'] ?? 0);
    $name = sanitize($_POST['name'] ?? '');
    $slug = sanitize($_POST['slug'] ?? '');
    if (empty($slug)) {
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name)));
    }
    $description = sanitize($_POST['description'] ?? '');
    $image = sanitize($_POST['image'] ?? '');
    $icon = sanitize($_POST['icon'] ?? 'fas fa-star');
    $displayOrder = (int)($_POST['display_order'] ?? 0);

    if (empty($name)) {
        $error = 'Category name is required.';
    } else {
        if ($catId > 0) {
            $update = $db->prepare("UPDATE categories SET name = ?, slug = ?, description = ?, image = ?, icon = ?, display_order = ? WHERE id = ?");
            $update->execute([$name, $slug, $description, $image, $icon, $displayOrder, $catId]);
            setFlash('success', 'Category updated successfully.');
        } else {
            $insert = $db->prepare("INSERT INTO categories (name, slug, description, image, icon, display_order) VALUES (?, ?, ?, ?, ?, ?)");
            $insert->execute([$name, $slug, $description, $image, $icon, $displayOrder]);
            setFlash('success', 'Category created successfully.');
        }
        header('Location: ' . BASE_URL . '/admin/categories.php');
        exit;
    }
}

// Handle Delete Category
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $db->prepare("DELETE FROM categories WHERE id = ?")->execute([$delId]);
    setFlash('warning', 'Category deleted.');
    header('Location: ' . BASE_URL . '/admin/categories.php');
    exit;
}

$categories = $db->query("
    SELECT c.*, COUNT(p.id) as product_count 
    FROM categories c 
    LEFT JOIN products p ON c.id = p.category_id 
    GROUP BY c.id 
    ORDER BY c.display_order ASC
")->fetchAll();

include APP_ROOT . '/includes/admin_layout.php';
?>

<div style="display: grid; grid-template-columns: 1fr 380px; gap: 32px; align-items: start;">
  
  <!-- Categories Table -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title"><i class="fas fa-th-large text-primary me-2"></i> Current Product Categories</h3>
    </div>
    <div class="table-responsive">
      <table class="admin-table">
        <thead>
          <tr>
            <th style="width: 50px;">Icon</th>
            <th>Category Name</th>
            <th>Slug</th>
            <th>Products</th>
            <th>Order</th>
            <th style="text-align: right;">Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($categories as $cat): ?>
          <tr>
            <td>
              <div style="width: 38px; height: 38px; border-radius: 8px; background: #eff6ff; color: var(--primary); display: flex; align-items: center; justify-content: center; font-size: 1.1rem;">
                <i class="<?= htmlspecialchars($cat['icon'] ?: 'fas fa-star') ?>"></i>
              </div>
            </td>
            <td>
              <strong style="color: var(--secondary); font-size: 0.95rem;"><?= htmlspecialchars($cat['name']) ?></strong>
              <div style="font-size: 0.78rem; color: var(--admin-text-muted); display: -webkit-box; -webkit-line-clamp: 1; -webkit-box-orient: vertical; overflow: hidden;">
                <?= htmlspecialchars($cat['description'] ?: '') ?>
              </div>
            </td>
            <td style="font-family: monospace; font-size: 0.85rem; color: var(--admin-text-muted);">
              <?= htmlspecialchars($cat['slug']) ?>
            </td>
            <td>
              <span class="badge bg-secondary"><?= $cat['product_count'] ?> products</span>
            </td>
            <td><?= $cat['display_order'] ?></td>
            <td style="text-align: right;">
              <a href="<?= BASE_URL ?>/admin/categories.php?delete=<?= $cat['id'] ?>" onclick="return confirm('Delete this category? Products inside may be deleted or unassigned.');" class="btn btn-secondary btn-sm" style="color: #ef4444;" title="Delete">
                <i class="fas fa-trash-alt"></i>
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Add New Category Form -->
  <div class="admin-card">
    <div class="admin-card-header">
      <h3 class="admin-card-title"><i class="fas fa-plus text-primary me-2"></i> Add New Category</h3>
    </div>
    <div class="admin-card-body">
      <?php if (!empty($error)): ?>
        <div style="background: #fee2e2; border-left: 4px solid var(--danger); padding: 12px; border-radius: var(--radius-sm); margin-bottom: 16px; color: #b91c1c; font-size: 0.85rem;">
          <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form action="" method="POST">
        <input type="hidden" name="save_category" value="1">

        <div class="form-group" style="margin-bottom: 14px;">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Category Name *</label>
          <input type="text" name="name" class="form-control" placeholder="e.g. Neon Light Signs" required style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>

        <div class="form-group" style="margin-bottom: 14px;">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Slug (optional)</label>
          <input type="text" name="slug" class="form-control" placeholder="neon-light-signs" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>

        <div class="form-group" style="margin-bottom: 14px;">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">FontAwesome Icon Class</label>
          <input type="text" name="icon" class="form-control" value="fas fa-star" placeholder="e.g. fas fa-bullhorn" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>

        <div class="form-group" style="margin-bottom: 14px;">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Banner Image URL</label>
          <input type="text" name="image" class="form-control" placeholder="https://..." style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>

        <div class="form-group" style="margin-bottom: 14px;">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Display Order Number</label>
          <input type="number" name="display_order" class="form-control" value="1" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>

        <div class="form-group" style="margin-bottom: 20px;">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Short Description</label>
          <textarea name="description" rows="3" class="form-control" placeholder="Brief summary of products in this category" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);"></textarea>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">
          <i class="fas fa-save me-1"></i> Save Category
        </button>
      </form>
    </div>
  </div>

</div>

  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>

