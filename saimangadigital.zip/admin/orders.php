<?php
require_once dirname(__DIR__) . '/config/init.php';
requireAdminAuth();

$pageTitle = 'Orders & Production Queue';
$activePage = 'orders';

$statusFilter = isset($_GET['status']) ? trim($_GET['status']) : '';

// Handle Quick Status Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_order_status'])) {
    $orderId = (int)$_POST['order_id'];
    $newStatus = sanitize($_POST['new_status']);
    $db->prepare("UPDATE orders SET order_status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$newStatus, $orderId]);
    setFlash('success', 'Order status updated.');
    header('Location: ' . BASE_URL . '/admin/orders.php' . (!empty($statusFilter) ? '?status=' . urlencode($statusFilter) : ''));
    exit;
}

// Build SQL
$whereSql = "1=1";
$params = [];
if (!empty($statusFilter)) {
    $whereSql .= " AND order_status = ?";
    $params[] = $statusFilter;
}

$stmt = $db->prepare("
    SELECT o.*, COUNT(oi.id) as item_count 
    FROM orders o 
    LEFT JOIN order_items oi ON o.id = oi.order_id 
    WHERE {$whereSql} 
    GROUP BY o.id 
    ORDER BY o.id DESC
");
$stmt->execute($params);
$orders = $stmt->fetchAll();

include APP_ROOT . '/includes/admin_layout.php';
?>

<!-- Status Filter Tabs -->
<div style="display: flex; gap: 8px; margin-bottom: 24px; overflow-x: auto; padding-bottom: 6px;">
  <a href="<?= BASE_URL ?>/admin/orders.php" class="btn <?= empty($statusFilter) ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    All Orders
  </a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=pending" class="btn <?= $statusFilter === 'pending' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    Pending
  </a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=in_design" class="btn <?= $statusFilter === 'in_design' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    In Design
  </a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=printing" class="btn <?= $statusFilter === 'printing' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    Printing / Laser CNC
  </a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=ready" class="btn <?= $statusFilter === 'ready' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    Ready for Dispatch
  </a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=dispatched" class="btn <?= $statusFilter === 'dispatched' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    Dispatched
  </a>
  <a href="<?= BASE_URL ?>/admin/orders.php?status=delivered" class="btn <?= $statusFilter === 'delivered' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    Delivered
  </a>
</div>

<!-- Search Input -->
<div style="margin-bottom: 20px; max-width: 400px;">
  <input type="text" id="adminTableSearch" class="form-control" placeholder="Search orders by customer, phone, order #..." style="background: #ffffff; color: var(--secondary); border: 1px solid var(--admin-border);">
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title">Order Records (<?= count($orders) ?>)</h3>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Order #</th>
          <th>Customer Info</th>
          <th>Mode</th>
          <th>Items</th>
          <th>Total</th>
          <th>Payment</th>
          <th>Production Status</th>
          <th>Date</th>
          <th style="text-align: right;">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($orders)): ?>
          <tr><td colspan="9" style="text-align: center; padding: 40px; color: var(--admin-text-muted);">No orders found for this status filter.</td></tr>
        <?php else: ?>
          <?php foreach ($orders as $o): ?>
          <tr>
            <td>
              <strong style="color: var(--secondary); font-family: monospace; font-size: 0.95rem;">
                <a href="<?= BASE_URL ?>/admin/order-detail.php?id=<?= $o['id'] ?>"><?= htmlspecialchars($o['order_number']) ?></a>
              </strong>
            </td>
            <td>
              <div style="font-weight: 700; color: var(--secondary);"><?= htmlspecialchars($o['customer_name']) ?></div>
              <div style="font-size: 0.78rem; color: var(--admin-text-muted);"><?= htmlspecialchars($o['customer_phone']) ?></div>
            </td>
            <td>
              <?php if ($o['delivery_type'] === 'pickup'): ?>
                <span class="badge bg-secondary"><i class="fas fa-store"></i> Store Pickup</span>
              <?php else: ?>
                <span class="badge bg-info"><i class="fas fa-truck"></i> Delivery</span>
              <?php endif; ?>
            </td>
            <td>
              <span style="font-weight: 600;"><?= $o['item_count'] ?> item(s)</span>
            </td>
            <td>
              <strong style="color: var(--secondary); font-size: 0.95rem;"><?= formatPrice($o['total_amount']) ?></strong>
            </td>
            <td>
              <?= getPaymentStatusBadge($o['payment_status']) ?>
            </td>
            <td>
              <!-- Quick Status Change Form -->
              <form action="" method="POST" style="margin: 0;">
                <input type="hidden" name="update_order_status" value="1">
                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                <select name="new_status" class="form-select auto-submit-status" style="font-size: 0.78rem; padding: 4px 24px 4px 8px; width: auto; border-radius: 6px; border: 1px solid var(--admin-border); background: #ffffff; color: var(--secondary);">
                  <option value="pending" <?= $o['order_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                  <option value="in_design" <?= $o['order_status'] === 'in_design' ? 'selected' : '' ?>>In Design</option>
                  <option value="printing" <?= $o['order_status'] === 'printing' ? 'selected' : '' ?>>Printing</option>
                  <option value="ready" <?= $o['order_status'] === 'ready' ? 'selected' : '' ?>>Ready</option>
                  <option value="dispatched" <?= $o['order_status'] === 'dispatched' ? 'selected' : '' ?>>Dispatched</option>
                  <option value="delivered" <?= $o['order_status'] === 'delivered' ? 'selected' : '' ?>>Delivered</option>
                  <option value="cancelled" <?= $o['order_status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                </select>
              </form>
            </td>
            <td style="font-size: 0.82rem; color: var(--admin-text-muted);">
              <?= date('d M, h:i A', strtotime($o['created_at'])) ?>
            </td>
            <td style="text-align: right;">
              <a href="<?= BASE_URL ?>/admin/order-detail.php?id=<?= $o['id'] ?>" class="btn btn-outline btn-sm" title="View Full Order">
                <i class="fas fa-eye"></i> Details
              </a>
              <a href="<?= BASE_URL ?>/invoice.php?order=<?= urlencode($o['order_number']) ?>" target="_blank" class="btn btn-secondary btn-sm" title="Print Invoice">
                <i class="fas fa-print"></i>
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>

