<?php
require_once dirname(__DIR__) . '/config/init.php';
requireAdminAuth();

$pageTitle = 'Products Catalog Management';
$activePage = 'products';

// Handle Delete
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $delStmt = $db->prepare("DELETE FROM products WHERE id = ?");
    $delStmt->execute([$delId]);
    setFlash('success', 'Product has been deleted successfully.');
    header('Location: ' . BASE_URL . '/admin/products.php');
    exit;
}

// Handle Toggle Featured
if (isset($_GET['toggle_featured'])) {
    $featId = (int)$_GET['toggle_featured'];
    $db->prepare("UPDATE products SET is_featured = (1 - is_featured) WHERE id = ?")->execute([$featId]);
    header('Location: ' . BASE_URL . '/admin/products.php');
    exit;
}

// Fetch products with category names
$products = $db->query("
    SELECT p.*, c.name as category_name 
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    ORDER BY p.id DESC
")->fetchAll();

include APP_ROOT . '/includes/admin_layout.php';
?>

<!-- Action Bar -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 14px;">
  <div style="display: flex; align-items: center; gap: 12px; flex: 1; max-width: 400px;">
    <input type="text" id="adminTableSearch" class="form-control" placeholder="Search products by title, SKU, or category..." style="background: #ffffff; color: var(--secondary); border: 1px solid var(--admin-border); padding: 10px 16px;">
  </div>
  <div>
    <a href="<?= BASE_URL ?>/admin/product-form.php" class="btn btn-primary">
      <i class="fas fa-plus-circle me-1"></i> Add New Product
    </a>
  </div>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title">All Products &amp; Services (<?= count($products) ?>)</h3>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th style="width: 70px;">Image</th>
          <th>Product Name &amp; SKU</th>
          <th>Category</th>
          <th>Pricing Model</th>
          <th>Base Price</th>
          <th>Discount Price</th>
          <th>Featured</th>
          <th style="text-align: right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach ($products as $p): ?>
        <tr>
          <td>
            <div style="width: 52px; height: 52px; border-radius: 8px; overflow: hidden; background: #f1f5f9; border: 1px solid var(--admin-border);">
              <img src="<?= htmlspecialchars($p['image']) ?>" alt="Product" style="width: 100%; height: 100%; object-fit: cover;">
            </div>
          </td>
          <td>
            <strong style="color: var(--secondary); font-size: 0.95rem;"><?= htmlspecialchars($p['name']) ?></strong>
            <div style="font-size: 0.78rem; color: var(--admin-text-muted); font-family: monospace;">SKU: <?= htmlspecialchars($p['sku'] ?: 'N/A') ?></div>
          </td>
          <td>
            <span class="badge bg-secondary"><?= htmlspecialchars($p['category_name']) ?></span>
          </td>
          <td>
            <?php if ($p['pricing_type'] === 'per_sqft'): ?>
              <span class="badge bg-info"><i class="fas fa-ruler-combined"></i> Per Sq.Ft</span>
            <?php else: ?>
              <span class="badge bg-primary"><i class="fas fa-box"></i> Per <?= htmlspecialchars($p['unit']) ?></span>
            <?php endif; ?>
          </td>
          <td>
            <strong style="color: var(--secondary);"><?= formatPrice($p['base_price']) ?></strong>
          </td>
          <td>
            <?= !empty($p['discount_price']) ? '<span style="color: #10b981; font-weight: 700;">' . formatPrice($p['discount_price']) . '</span>' : '-' ?>
          </td>
          <td>
            <a href="<?= BASE_URL ?>/admin/products.php?toggle_featured=<?= $p['id'] ?>" title="Toggle Featured State">
              <?php if ($p['is_featured']): ?>
                <span class="badge bg-success"><i class="fas fa-check"></i> Featured</span>
              <?php else: ?>
                <span class="badge bg-secondary">No</span>
              <?php endif; ?>
            </a>
          </td>
          <td style="text-align: right;">
            <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($p['slug']) ?>" target="_blank" class="btn btn-outline btn-sm" title="Preview on Store">
              <i class="fas fa-external-link-alt"></i>
            </a>
            <a href="<?= BASE_URL ?>/admin/product-form.php?id=<?= $p['id'] ?>" class="btn btn-primary btn-sm" title="Edit Product">
              <i class="fas fa-edit"></i> Edit
            </a>
            <a href="<?= BASE_URL ?>/admin/products.php?delete=<?= $p['id'] ?>" onclick="return confirm('Are you sure you want to delete this product?');" class="btn btn-secondary btn-sm" style="color: #ef4444;" title="Delete Product">
              <i class="fas fa-trash-alt"></i>
            </a>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>

