<?php
require_once dirname(__DIR__) . '/config/init.php';
requireAdminAuth();

$orderId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($orderId <= 0) {
    header('Location: ' . BASE_URL . '/admin/orders.php');
    exit;
}

// Handle Order Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_order'])) {
    $orderStatus = sanitize($_POST['order_status']);
    $paymentStatus = sanitize($_POST['payment_status']);
    $trackingNumber = sanitize($_POST['tracking_number'] ?? '');
    
    $updateStmt = $db->prepare("
        UPDATE orders SET
            order_status = ?, payment_status = ?, tracking_number = ?, updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
    ");
    $updateStmt->execute([$orderStatus, $paymentStatus, $trackingNumber, $orderId]);
    setFlash('success', 'Order updated successfully.');
    header('Location: ' . BASE_URL . '/admin/order-detail.php?id=' . $orderId);
    exit;
}

// Fetch order
$stmt = $db->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$orderId]);
$order = $stmt->fetch();

if (!$order) {
    header('Location: ' . BASE_URL . '/admin/orders.php');
    exit;
}

// Fetch items
$itemStmt = $db->prepare("SELECT * FROM order_items WHERE order_id = ?");
$itemStmt->execute([$orderId]);
$items = $itemStmt->fetchAll();

$pageTitle = 'Order: ' . $order['order_number'];
$activePage = 'orders';

include APP_ROOT . '/includes/admin_layout.php';
?>

<!-- Top Action Header -->
<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; flex-wrap: wrap; gap: 14px;">
  <div>
    <a href="<?= BASE_URL ?>/admin/orders.php" style="font-size: 0.85rem; font-weight: 600; color: var(--primary); display: inline-flex; align-items: center; gap: 6px; margin-bottom: 6px;">
      &larr; Back to Orders List
    </a>
    <h2 style="font-size: 1.6rem; font-weight: 800; color: var(--secondary); margin: 0;">
      Order #<?= htmlspecialchars($order['order_number']) ?>
    </h2>
  </div>

  <div style="display: flex; gap: 12px;">
    <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $order['customer_phone']) ?>?text=<?= urlencode("Hello " . $order['customer_name'] . ", this is Sai Manga Digital regarding your order #" . $order['order_number'] . ".") ?>" target="_blank" class="btn btn-whatsapp btn-sm">
      <i class="fab fa-whatsapp me-1"></i> WhatsApp Customer
    </a>
    <a href="<?= BASE_URL ?>/invoice.php?order=<?= urlencode($order['order_number']) ?>" target="_blank" class="btn btn-secondary btn-sm">
      <i class="fas fa-print me-1"></i> Print Invoice
    </a>
  </div>
</div>

<div style="display: grid; grid-template-columns: 1fr 360px; gap: 32px; align-items: start;">
  
  <!-- Left: Ordered Products & Details -->
  <div>
    <!-- Order Items Card -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title"><i class="fas fa-boxes text-primary me-2"></i> Fabrication Job Items (<?= count($items) ?>)</h3>
      </div>
      <div class="admin-card-body" style="padding: 0;">
        <table class="admin-table">
          <thead>
            <tr>
              <th>Item / Specification</th>
              <th style="text-align: center;">Size &amp; Sqrft</th>
              <th style="text-align: center;">Qty</th>
              <th style="text-align: right;">Unit Rate</th>
              <th style="text-align: right;">Total</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($items as $item): ?>
            <tr>
              <td>
                <strong style="color: var(--secondary); font-size: 0.95rem;"><?= htmlspecialchars($item['product_name']) ?></strong>
                <div style="font-size: 0.82rem; color: var(--admin-text-muted); margin-top: 4px;">
                  <?php if (!empty($item['material_selected'])): ?>
                    <span><strong>Material:</strong> <?= htmlspecialchars($item['material_selected']) ?></span><br>
                  <?php endif; ?>
                  <?php if (!empty($item['finish_selected'])): ?>
                    <span><strong>Finish:</strong> <?= htmlspecialchars($item['finish_selected']) ?></span><br>
                  <?php endif; ?>
                </div>
                <?php if (!empty($item['custom_notes'])): ?>
                  <div style="font-size: 0.8rem; color: #1e40af; background: #eff6ff; padding: 6px 10px; border-radius: 6px; margin-top: 6px;">
                    <i class="fas fa-comment-alt me-1"></i> <?= htmlspecialchars($item['custom_notes']) ?>
                  </div>
                <?php endif; ?>
              </td>
              <td style="text-align: center; font-size: 0.88rem;">
                <?php if ($item['pricing_type'] === 'per_sqft' && $item['width'] > 0): ?>
                  <strong><?= $item['width'] ?> &times; <?= $item['height'] ?> ft</strong><br>
                  <span style="font-size: 0.78rem; color: var(--admin-text-muted);"><?= number_format($item['total_sqft'], 2) ?> sq.ft</span>
                <?php else: ?>
                  <span style="color: var(--admin-text-muted);">Standard</span>
                <?php endif; ?>
              </td>
              <td style="text-align: center; font-weight: 700;">
                <?= $item['quantity'] ?>
              </td>
              <td style="text-align: right;">
                <?= formatPrice($item['unit_price']) ?>
              </td>
              <td style="text-align: right; font-weight: 800; color: var(--secondary);">
                <?= formatPrice($item['item_total']) ?>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>

    <!-- Customer & Shipping Card -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title"><i class="fas fa-address-card text-primary me-2"></i> Client &amp; Delivery Destination</h3>
      </div>
      <div class="admin-card-body">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
          <div>
            <h4 style="font-size: 0.82rem; text-transform: uppercase; color: var(--admin-text-muted); margin-bottom: 6px;">Customer Details</h4>
            <div style="font-size: 1.05rem; font-weight: 700; color: var(--secondary);"><?= htmlspecialchars($order['customer_name']) ?></div>
            <div style="font-size: 0.9rem; color: var(--admin-text-muted); margin-top: 4px;"><i class="fas fa-phone-alt me-1"></i> <?= htmlspecialchars($order['customer_phone']) ?></div>
            <div style="font-size: 0.9rem; color: var(--admin-text-muted);"><i class="fas fa-envelope me-1"></i> <?= htmlspecialchars($order['customer_email']) ?></div>
          </div>

          <div>
            <h4 style="font-size: 0.82rem; text-transform: uppercase; color: var(--admin-text-muted); margin-bottom: 6px;">Fulfillment Mode</h4>
            <?php if ($order['delivery_type'] === 'pickup'): ?>
              <div style="color: #15803d; font-weight: 700;"><i class="fas fa-store me-1"></i> Store Collection / Pickup</div>
              <div style="font-size: 0.85rem; color: var(--admin-text-muted); margin-top: 4px;">Madhuban Plaza, S.D. Road Secunderabad</div>
            <?php else: ?>
              <div style="color: var(--secondary); font-weight: 700;"><i class="fas fa-truck me-1"></i> Delivery Address</div>
              <div style="font-size: 0.88rem; color: var(--admin-text-muted); margin-top: 4px; line-height: 1.5;">
                <?= nl2br(htmlspecialchars($order['address'] . ', ' . $order['city'] . ' - ' . $order['pincode'] . ', ' . $order['state'])) ?>
              </div>
            <?php endif; ?>
          </div>
        </div>

        <?php if (!empty($order['notes'])): ?>
          <div style="margin-top: 20px; padding: 14px; background: #fffbeb; border: 1px solid #fef3c7; border-radius: 8px;">
            <strong style="color: #b45309; font-size: 0.85rem;"><i class="fas fa-sticky-note me-1"></i> Special Client Instructions:</strong>
            <p style="margin: 4px 0 0; font-size: 0.88rem; color: #92400e;"><?= htmlspecialchars($order['notes']) ?></p>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Right: Status Control Panel & Financial Summary -->
  <div>
    <!-- Status Updater Card -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title"><i class="fas fa-sliders-h text-primary me-2"></i> Update Order Status</h3>
      </div>
      <div class="admin-card-body">
        <form action="" method="POST">
          <input type="hidden" name="update_order" value="1">

          <div class="form-group" style="margin-bottom: 16px;">
            <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Production / Fabrication Status</label>
            <select name="order_status" class="form-select" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
              <option value="pending" <?= $order['order_status'] === 'pending' ? 'selected' : '' ?>>Pending Review</option>
              <option value="in_design" <?= $order['order_status'] === 'in_design' ? 'selected' : '' ?>>In Design Proofing</option>
              <option value="printing" <?= $order['order_status'] === 'printing' ? 'selected' : '' ?>>Printing / Laser CNC</option>
              <option value="ready" <?= $order['order_status'] === 'ready' ? 'selected' : '' ?>>Ready for Dispatch/Pickup</option>
              <option value="dispatched" <?= $order['order_status'] === 'dispatched' ? 'selected' : '' ?>>Dispatched / In Transit</option>
              <option value="delivered" <?= $order['order_status'] === 'delivered' ? 'selected' : '' ?>>Delivered / Completed</option>
              <option value="cancelled" <?= $order['order_status'] === 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
            </select>
          </div>

          <div class="form-group" style="margin-bottom: 16px;">
            <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Payment Status</label>
            <select name="payment_status" class="form-select" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
              <option value="pending" <?= $order['payment_status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
              <option value="paid" <?= $order['payment_status'] === 'paid' ? 'selected' : '' ?>>Paid (Verified)</option>
              <option value="failed" <?= $order['payment_status'] === 'failed' ? 'selected' : '' ?>>Failed / Refunded</option>
            </select>
          </div>

          <div class="form-group" style="margin-bottom: 20px;">
            <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Courier Waybill / Tracking #</label>
            <input type="text" name="tracking_number" class="form-control" value="<?= htmlspecialchars($order['tracking_number'] ?? '') ?>" placeholder="e.g. DTDC-HYD-99812" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
          </div>

          <button type="submit" class="btn btn-primary" style="width: 100%; justify-content: center;">
            <i class="fas fa-check-circle me-1"></i> Update Order
          </button>
        </form>
      </div>
    </div>

    <!-- Financial Card -->
    <div class="admin-card">
      <div class="admin-card-header">
        <h3 class="admin-card-title"><i class="fas fa-file-invoice-dollar text-primary me-2"></i> Financial Summary</h3>
      </div>
      <div class="admin-card-body" style="font-size: 0.92rem;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; color: var(--admin-text-muted);">
          <span>Items Subtotal:</span>
          <strong style="color: var(--secondary);"><?= formatPrice($order['subtotal']) ?></strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; color: var(--admin-text-muted);">
          <span>GST (18%):</span>
          <strong style="color: var(--secondary);"><?= formatPrice($order['tax_amount']) ?></strong>
        </div>
        <div style="display: flex; justify-content: space-between; margin-bottom: 10px; color: var(--admin-text-muted);">
          <span>Shipping Fee:</span>
          <strong style="color: var(--secondary);"><?= $order['shipping_fee'] == 0 ? 'FREE' : formatPrice($order['shipping_fee']) ?></strong>
        </div>
        <div style="display: flex; justify-content: space-between; padding-top: 14px; border-top: 2px dashed var(--admin-border); font-size: 1.15rem; color: var(--secondary);">
          <strong>Total Order Amount:</strong>
          <strong style="color: var(--primary); font-size: 1.4rem;"><?= formatPrice($order['total_amount']) ?></strong>
        </div>
        <div style="margin-top: 12px; font-size: 0.8rem; color: var(--admin-text-muted);">
          Payment Mode: <strong style="color: var(--secondary);"><?= strtoupper($order['payment_method']) ?></strong>
        </div>
      </div>
    </div>
  </div>

</div>

  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>

