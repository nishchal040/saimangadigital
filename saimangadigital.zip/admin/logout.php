<?php
require_once dirname(__DIR__) . '/config/init.php';

unset($_SESSION['admin_id']);
unset($_SESSION['admin_user']);
unset($_SESSION['admin_name']);
unset($_SESSION['admin_role']);

setFlash('info', 'You have been logged out successfully.');
header('Location: ' . BASE_URL . '/admin/login.php');
exit;

