<?php
require_once dirname(__DIR__) . '/config/init.php';
requireAdminAuth();

$pageTitle = 'Store Configuration & Settings';
$activePage = 'settings';

// Handle Settings Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    $keys = [
        'site_name', 'site_tagline', 'proprietor', 'phone', 'mobile', 'whatsapp', 'email',
        'address', 'google_maps_url', 'business_hours', 'google_rating', 'google_reviews_count',
        'instagram', 'announcement_bar',
        'currency_symbol', 'tax_rate_percent', 'free_shipping_threshold',
        'shipping_flat_fee', 'upi_id', 'upi_name'
    ];

    $updateStmt = $db->prepare("
        INSERT INTO settings (key_name, value, group_name) 
        VALUES (?, ?, 'general') 
        ON CONFLICT(key_name) DO UPDATE SET value = excluded.value, updated_at = CURRENT_TIMESTAMP
    ");

    foreach ($keys as $k) {
        if (isset($_POST[$k])) {
            $val = trim($_POST[$k]);
            $updateStmt->execute([$k, $val]);
        }
    }

    setFlash('success', 'Store settings updated successfully.');
    header('Location: ' . BASE_URL . '/admin/settings.php');
    exit;
}

$s = getSettings();
include APP_ROOT . '/includes/admin_layout.php';
?>

<div class="admin-card" style="max-width: 900px; margin: 0 auto;">
  <div class="admin-card-header">
    <h3 class="admin-card-title"><i class="fas fa-sliders-h text-primary me-2"></i> Sai Manga Digital Store Configuration</h3>
  </div>

  <div class="admin-card-body">
    <form action="" method="POST">
      <input type="hidden" name="save_settings" value="1">

      <h4 style="font-size: 1rem; font-weight: 800; color: var(--secondary); margin-bottom: 16px; padding-bottom: 8px; border-bottom: 1px solid var(--admin-border);">
        1. Brand &amp; Store Identity
      </h4>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Business / Store Name</label>
          <input type="text" name="site_name" class="form-control" value="<?= htmlspecialchars($s['site_name'] ?? 'Sai Manga Digital') ?>" required style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Brand Tagline</label>
          <input type="text" name="site_tagline" class="form-control" value="<?= htmlspecialchars($s['site_tagline'] ?? '') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Top Announcement Bar Banner Text</label>
        <input type="text" name="announcement_bar" class="form-control" value="<?= htmlspecialchars($s['announcement_bar'] ?? '') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
      </div>

      <h4 style="font-size: 1rem; font-weight: 800; color: var(--secondary); margin: 28px 0 16px; padding-bottom: 8px; border-bottom: 1px solid var(--admin-border);">
        2. Direct Contact &amp; Social Links
      </h4>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Primary Phone (Secunderabad)</label>
          <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($s['phone'] ?? '+91 8047663573') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Mobile / Dispatch Cell</label>
          <input type="text" name="mobile" class="form-control" value="<?= htmlspecialchars($s['mobile'] ?? '+91 98490 12345') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">WhatsApp Number (without + or spaces, e.g. 918047663573)</label>
          <input type="text" name="whatsapp" class="form-control" value="<?= htmlspecialchars($s['whatsapp'] ?? '918047663573') ?>" required style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Official Email</label>
          <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($s['email'] ?? 'sales@saimangadigital.com') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Official Email</label>
          <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($s['email'] ?? 'sales@saimangadigital.com') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Proprietor / Founder</label>
          <input type="text" name="proprietor" class="form-control" value="<?= htmlspecialchars($s['proprietor'] ?? 'Marri Prasad Naidu') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Operating Hours</label>
          <input type="text" name="business_hours" class="form-control" value="<?= htmlspecialchars($s['business_hours'] ?? 'Monday - Saturday: 9:30 AM to 9:00 PM (Sunday Closed)') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Google Rating Score &amp; Review Count</label>
          <div style="display: flex; gap: 10px;">
            <input type="text" name="google_rating" class="form-control" placeholder="4.8" value="<?= htmlspecialchars($s['google_rating'] ?? '4.8') ?>" style="width: 80px; background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
            <input type="text" name="google_reviews_count" class="form-control" placeholder="68" value="<?= htmlspecialchars($s['google_reviews_count'] ?? '68') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
          </div>
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Instagram Profile Link</label>
          <input type="url" name="instagram" class="form-control" value="<?= htmlspecialchars($s['instagram'] ?? 'https://www.instagram.com/saimangadigital') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Google Maps URL (Official Listing)</label>
          <input type="url" name="google_maps_url" class="form-control" value="<?= htmlspecialchars($s['google_maps_url'] ?? 'https://maps.app.goo.gl/cNSaRii6R44K9t4c8') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-group">
        <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Physical Facility &amp; Workshop Address</label>
        <textarea name="address" rows="3" class="form-control" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);"><?= htmlspecialchars($s['address'] ?? '') ?></textarea>
      </div>

      <h4 style="font-size: 1rem; font-weight: 800; color: var(--secondary); margin: 28px 0 16px; padding-bottom: 8px; border-bottom: 1px solid var(--admin-border);">
        3. E-Commerce, Tax &amp; UPI Payment Gateway
      </h4>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">GST Tax Rate (%)</label>
          <input type="number" name="tax_rate_percent" class="form-control" value="<?= htmlspecialchars($s['tax_rate_percent'] ?? '18') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Flat Shipping Fee (₹)</label>
          <input type="number" name="shipping_flat_fee" class="form-control" value="<?= htmlspecialchars($s['shipping_flat_fee'] ?? '150') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Free Shipping Minimum Cart Value (₹)</label>
          <input type="number" name="free_shipping_threshold" class="form-control" value="<?= htmlspecialchars($s['free_shipping_threshold'] ?? '2999') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
        <div class="form-group">
          <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">UPI Merchant VPA / ID</label>
          <input type="text" name="upi_id" class="form-control" value="<?= htmlspecialchars($s['upi_id'] ?? 'saimanga@upi') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--admin-border);">
        </div>
      </div>

      <button type="submit" class="btn btn-primary btn-lg" style="margin-top: 10px;">
        <i class="fas fa-save me-1"></i> Save Store Configuration
      </button>
    </form>
  </div>
</div>

  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>

