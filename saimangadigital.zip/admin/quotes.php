<?php
require_once dirname(__DIR__) . '/config/init.php';
requireAdminAuth();

$pageTitle = 'Custom Quotation Inquiries';
$activePage = 'quotes';

$statusFilter = isset($_GET['status']) ? trim($_GET['status']) : '';

// Handle Status Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_quote_status'])) {
    $quoteId = (int)$_POST['quote_id'];
    $newStatus = sanitize($_POST['new_status']);
    $db->prepare("UPDATE quotes SET status = ? WHERE id = ?")->execute([$newStatus, $quoteId]);
    setFlash('success', 'Quotation status updated.');
    header('Location: ' . BASE_URL . '/admin/quotes.php' . (!empty($statusFilter) ? '?status=' . urlencode($statusFilter) : ''));
    exit;
}

// Build SQL
$whereSql = "1=1";
$params = [];
if (!empty($statusFilter)) {
    $whereSql .= " AND status = ?";
    $params[] = $statusFilter;
}

$stmt = $db->prepare("SELECT * FROM quotes WHERE {$whereSql} ORDER BY id DESC");
$stmt->execute($params);
$quotes = $stmt->fetchAll();

include APP_ROOT . '/includes/admin_layout.php';
?>

<!-- Filter Tabs -->
<div style="display: flex; gap: 8px; margin-bottom: 24px; overflow-x: auto; padding-bottom: 6px;">
  <a href="<?= BASE_URL ?>/admin/quotes.php" class="btn <?= empty($statusFilter) ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    All Quotes
  </a>
  <a href="<?= BASE_URL ?>/admin/quotes.php?status=new" class="btn <?= $statusFilter === 'new' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    New (Unread)
  </a>
  <a href="<?= BASE_URL ?>/admin/quotes.php?status=in_review" class="btn <?= $statusFilter === 'in_review' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    In Review
  </a>
  <a href="<?= BASE_URL ?>/admin/quotes.php?status=quoted" class="btn <?= $statusFilter === 'quoted' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    Quoted
  </a>
  <a href="<?= BASE_URL ?>/admin/quotes.php?status=closed" class="btn <?= $statusFilter === 'closed' ? 'btn-primary' : 'btn-outline' ?> btn-sm">
    Closed
  </a>
</div>

<div class="admin-card">
  <div class="admin-card-header">
    <h3 class="admin-card-title">Quotation Requests (<?= count($quotes) ?>)</h3>
  </div>

  <div class="table-responsive">
    <table class="admin-table">
      <thead>
        <tr>
          <th>Quote #</th>
          <th>Client &amp; Contact</th>
          <th>Service Required</th>
          <th>Dimensions &amp; Qty</th>
          <th>Message Brief</th>
          <th>Status</th>
          <th>Date</th>
          <th style="text-align: right;">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($quotes)): ?>
          <tr><td colspan="8" style="text-align: center; padding: 40px; color: var(--admin-text-muted);">No quotation requests found.</td></tr>
        <?php else: ?>
          <?php foreach ($quotes as $q): ?>
          <tr>
            <td>
              <strong style="color: var(--secondary); font-family: monospace; font-size: 0.95rem;"><?= htmlspecialchars($q['quote_number']) ?></strong>
            </td>
            <td>
              <div style="font-weight: 700; color: var(--secondary);"><?= htmlspecialchars($q['customer_name']) ?></div>
              <?php if (!empty($q['company_name'])): ?>
                <div style="font-size: 0.8rem; color: #1e40af; font-weight: 600;"><?= htmlspecialchars($q['company_name']) ?></div>
              <?php endif; ?>
              <div style="font-size: 0.78rem; color: var(--admin-text-muted);"><i class="fas fa-phone-alt me-1"></i> <?= htmlspecialchars($q['customer_phone']) ?></div>
            </td>
            <td>
              <strong style="color: var(--secondary);"><?= htmlspecialchars($q['service_needed']) ?></strong>
            </td>
            <td style="font-size: 0.85rem; color: var(--admin-text-muted);">
              <div><?= htmlspecialchars($q['dimensions'] ?: 'Custom') ?></div>
              <div>Qty: <strong><?= $q['quantity'] ?></strong></div>
            </td>
            <td style="font-size: 0.85rem; color: var(--admin-text-main); max-width: 240px;">
              <div style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                <?= htmlspecialchars($q['message']) ?>
              </div>
              <?php if (!empty($q['artwork_file'])): ?>
                <div style="margin-top: 4px;">
                  <a href="<?= BASE_URL ?>/uploads/artwork/<?= htmlspecialchars($q['artwork_file']) ?>" target="_blank" class="badge bg-primary" style="font-size: 0.72rem;">
                    <i class="fas fa-paperclip"></i> View Attached File
                  </a>
                </div>
              <?php endif; ?>
            </td>
            <td>
              <form action="" method="POST" style="margin: 0;">
                <input type="hidden" name="update_quote_status" value="1">
                <input type="hidden" name="quote_id" value="<?= $q['id'] ?>">
                <select name="new_status" class="form-select auto-submit-status" style="font-size: 0.78rem; padding: 4px 22px 4px 8px; width: auto; border-radius: 6px; border: 1px solid var(--admin-border); background: #ffffff; color: var(--secondary);">
                  <option value="new" <?= $q['status'] === 'new' ? 'selected' : '' ?>>New</option>
                  <option value="in_review" <?= $q['status'] === 'in_review' ? 'selected' : '' ?>>In Review</option>
                  <option value="quoted" <?= $q['status'] === 'quoted' ? 'selected' : '' ?>>Quoted</option>
                  <option value="closed" <?= $q['status'] === 'closed' ? 'selected' : '' ?>>Closed</option>
                </select>
              </form>
            </td>
            <td style="font-size: 0.82rem; color: var(--admin-text-muted);">
              <?= timeAgo($q['created_at']) ?>
            </td>
            <td style="text-align: right;">
              <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $q['customer_phone']) ?>?text=<?= urlencode("Hello " . $q['customer_name'] . ", this is Sai Manga Digital regarding your quotation request #" . $q['quote_number'] . " for " . $q['service_needed'] . ". We reviewed your specifications and would like to share our best estimate.") ?>" target="_blank" class="btn btn-whatsapp btn-sm">
                <i class="fab fa-whatsapp me-1"></i> Quote
              </a>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

  </main>
</div>
<script src="<?= BASE_URL ?>/assets/js/admin.js"></script>
</body>
</html>

