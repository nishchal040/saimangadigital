<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Shipping & Delivery Policy | Sai Manga Digital';
$phone = getSetting('phone', '+91 8047663573');
$address = getSetting('address', 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, S.D. Road, Secunderabad - 500003');

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: #FFFFFF; padding: 6px 18px; border-radius: var(--radius-pill); font-size: 0.82rem; font-weight: 700; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <i class="fas fa-truck text-primary"></i> Logistics &amp; Dispatch Standards
    </div>
    <h1 class="page-hero-title all-caps-title">Shipping &amp; Delivery Policy</h1>
    <p class="page-hero-desc">Fast, safe dispatch options from our Secunderabad manufacturing workshop to your doorstep.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 920px;">
    
    <!-- 3 Delivery Channels Grid -->
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 24px; margin-bottom: 40px;">
      <div style="background: var(--card-bg); border-radius: 18px; padding: 28px; text-align: center;">
        <div style="width: 52px; height: 52px; border-radius: 50%; background: #DCFCE7; color: #15803D; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin: 0 auto 16px;">
          <i class="fas fa-store"></i>
        </div>
        <h4 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 8px;">Free Studio Pickup</h4>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0; line-height: 1.6;">
          Collect directly from Madhuban Plaza, S.D. Road Secunderabad. Inspect your finished signboards on the test bench.
        </p>
      </div>

      <div style="background: var(--card-bg); border-radius: 18px; padding: 28px; text-align: center;">
        <div style="width: 52px; height: 52px; border-radius: 50%; background: #EFF6FF; color: var(--brand-blue); display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin: 0 auto 16px;">
          <i class="fas fa-shipping-fast"></i>
        </div>
        <h4 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 8px;">Hyderabad Local Express</h4>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0; line-height: 1.6;">
          Dedicated delivery van and courier dispatch across Secunderabad, Begumpet, Hitec City, Banjara Hills, and Kukatpally.
        </p>
      </div>

      <div style="background: var(--card-bg); border-radius: 18px; padding: 28px; text-align: center;">
        <div style="width: 52px; height: 52px; border-radius: 50%; background: #FEF3C7; color: #D97706; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; margin: 0 auto 16px;">
          <i class="fas fa-box"></i>
        </div>
        <h4 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 8px;">All-India Safe Logistics</h4>
        <p style="font-size: 0.85rem; color: var(--text-muted); margin: 0; line-height: 1.6;">
          Wooden crate protection with verified cargo logistics (VRL, Navata, DTDC) across Telangana, Andhra Pradesh, and India.
        </p>
      </div>
    </div>

    <!-- Policy Content Card -->
    <div style="background: var(--card-bg); border-radius: var(--radius-card); padding: 40px; font-size: 0.95rem; color: var(--text-muted); line-height: 1.8;">
      
      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin-bottom: 12px;">1. Production &amp; Dispatch Timelines</h3>
      <ul style="margin-left: 24px; margin-bottom: 20px;">
        <li><strong>Star Flex &amp; Vinyl Banners:</strong> Same-day dispatch for orders placed before 2:00 PM. Standard dispatch within 24 hours.</li>
        <li><strong>Roll-Up Standees:</strong> Same-day or next-day dispatch. Ready-to-use cassettes with carry bags.</li>
        <li><strong>3D Acrylic LED Channel Letter Boards:</strong> 2 to 4 working days, allowing for laser cutting, automated edge bending, wiring, and 24-hour illuminated stress testing.</li>
        <li><strong>Custom Neon Art Signs:</strong> 2 to 3 working days from artwork confirmation.</li>
      </ul>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin-bottom: 12px;">2. Protective Industrial Packaging</h3>
      <p>
        Because acrylic letter faces, mirrors, and silicone neon tubes can be delicate during transit, Sai Manga Digital enforces rigorous packaging standards:
      </p>
      <ul style="margin-left: 24px; margin-bottom: 20px;">
        <li>Multi-layer shock-absorbent bubble cushioning and thermocol protection.</li>
        <li>Sturdy corrugated outer cartons and rigid core corner guards.</li>
        <li>Reinforced wooden crates for outstation delivery of 3D channel letters and lightboxes.</li>
      </ul>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin-bottom: 12px;">3. Order Tracking</h3>
      <p>
        Once your order has been completed and dispatched, you will receive an SMS and WhatsApp alert with your consignment tracking number. You can track real-time fulfillment status at any time on our website using our <a href="<?= BASE_URL ?>/track-order.php" style="color: var(--brand-blue); font-weight: 700;">Order Tracking Portal</a>.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin-bottom: 12px;">4. In-Store Workshop Pickup Details</h3>
      <p>
        If you select <strong>Self Pickup</strong> at checkout, there are zero shipping fees. Your order will be staged at our front counter:
      </p>
      <div style="background: #FFFFFF; border-radius: 12px; padding: 16px 20px; border: 1px solid var(--border-subtle); margin-top: 10px;">
        <strong style="color: #111111;">Sai Manga Digital</strong><br>
        <?= nl2br(htmlspecialchars($address)) ?><br>
        <span style="font-size: 0.82rem; color: #15803D; font-weight: 700;"><i class="fas fa-clock me-1"></i> Pickup Hours: Monday – Saturday: 9:30 AM to 9:00 PM</span>
      </div>

    </div>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

