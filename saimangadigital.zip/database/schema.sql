-- =======================================================
-- Sai Manga Digital - E-Commerce Database Schema (MySQL)
-- Premium Signage, Digital Printing & Display Solutions
-- Secunderabad, Telangana
-- =======================================================

CREATE DATABASE IF NOT EXISTS `saimanga_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `saimanga_db`;

-- Admins Table
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(50) NOT NULL UNIQUE,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(100) NOT NULL,
  `role` VARCHAR(20) DEFAULT 'admin',
  `last_login` DATETIME NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Settings Table
CREATE TABLE IF NOT EXISTS `settings` (
  `key_name` VARCHAR(50) PRIMARY KEY,
  `value` TEXT NOT NULL,
  `group_name` VARCHAR(50) DEFAULT 'general',
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Categories Table
CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT NULL,
  `image` TEXT NULL,
  `icon` VARCHAR(50) NULL,
  `display_order` INT DEFAULT 0,
  `is_active` INT DEFAULT 1,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Products Table
CREATE TABLE IF NOT EXISTS `products` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `name` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(150) NOT NULL UNIQUE,
  `short_desc` VARCHAR(255) NULL,
  `description` TEXT NULL,
  `base_price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `discount_price` DECIMAL(10,2) NULL,
  `pricing_type` VARCHAR(20) DEFAULT 'fixed',
  `unit` VARCHAR(30) DEFAULT 'piece',
  `min_quantity` INT DEFAULT 1,
  `min_sqft` DECIMAL(8,2) DEFAULT 1.00,
  `default_width` DECIMAL(8,2) DEFAULT 1.00,
  `default_height` DECIMAL(8,2) DEFAULT 1.00,
  `sku` VARCHAR(50) NULL,
  `image` TEXT NOT NULL,
  `gallery` TEXT NULL,
  `material_options` TEXT NULL,
  `finish_options` TEXT NULL,
  `is_featured` INT DEFAULT 0,
  `is_active` INT DEFAULT 1,
  `rating` DECIMAL(3,1) DEFAULT 4.9,
  `review_count` INT DEFAULT 24,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Orders Table
CREATE TABLE IF NOT EXISTS `orders` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_number` VARCHAR(30) NOT NULL UNIQUE,
  `customer_name` VARCHAR(100) NOT NULL,
  `customer_email` VARCHAR(100) NOT NULL,
  `customer_phone` VARCHAR(20) NOT NULL,
  `delivery_type` VARCHAR(20) DEFAULT 'delivery',
  `address` TEXT NULL,
  `city` VARCHAR(100) NULL,
  `state` VARCHAR(100) DEFAULT 'Telangana',
  `pincode` VARCHAR(20) NULL,
  `notes` TEXT NULL,
  `artwork_file` TEXT NULL,
  `subtotal` DECIMAL(10,2) NOT NULL,
  `tax_amount` DECIMAL(10,2) DEFAULT 0.00,
  `shipping_fee` DECIMAL(10,2) DEFAULT 0.00,
  `discount_amount` DECIMAL(10,2) DEFAULT 0.00,
  `total_amount` DECIMAL(10,2) NOT NULL,
  `payment_method` VARCHAR(30) DEFAULT 'upi',
  `payment_status` VARCHAR(20) DEFAULT 'pending',
  `order_status` VARCHAR(30) DEFAULT 'pending',
  `tracking_number` VARCHAR(100) NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Order Items Table
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `order_id` INT NOT NULL,
  `product_id` INT NULL,
  `product_name` VARCHAR(150) NOT NULL,
  `product_image` TEXT NULL,
  `pricing_type` VARCHAR(20) DEFAULT 'fixed',
  `unit_price` DECIMAL(10,2) NOT NULL,
  `quantity` INT NOT NULL DEFAULT 1,
  `width` DECIMAL(8,2) NULL,
  `height` DECIMAL(8,2) NULL,
  `total_sqft` DECIMAL(8,2) NULL,
  `material_selected` VARCHAR(100) NULL,
  `finish_selected` VARCHAR(100) NULL,
  `item_total` DECIMAL(10,2) NOT NULL,
  `custom_notes` TEXT NULL,
  FOREIGN KEY (`order_id`) REFERENCES `orders`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Quotes Table
CREATE TABLE IF NOT EXISTS `quotes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `quote_number` VARCHAR(30) NOT NULL UNIQUE,
  `customer_name` VARCHAR(100) NOT NULL,
  `customer_phone` VARCHAR(20) NOT NULL,
  `customer_email` VARCHAR(100) NOT NULL,
  `company_name` VARCHAR(100) NULL,
  `service_needed` VARCHAR(100) NOT NULL,
  `dimensions` VARCHAR(100) NULL,
  `quantity` INT DEFAULT 1,
  `message` TEXT NOT NULL,
  `artwork_file` TEXT NULL,
  `status` VARCHAR(20) DEFAULT 'new',
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

