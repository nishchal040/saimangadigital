<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Terms & Conditions | Sai Manga Digital';
$siteName = getSetting('site_name', 'Sai Manga Digital');
$email = getSetting('email', 'sales@saimangadigital.com');
$phone = getSetting('phone', '+91 8047663573');

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <h1 class="page-hero-title all-caps-title">Terms &amp; Conditions</h1>
    <p class="page-hero-desc">Standard terms of business, custom fabrication agreements, and order policies.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 900px;">
    <div class="resp-card" style="font-size: 0.95rem; color: var(--text-muted); line-height: 1.8;">
      
      <p style="font-size: 0.85rem; color: var(--text-light); margin-bottom: 24px;">
        Last updated: <?= date('F d, Y') ?> &bull; Governed under the laws of Telangana, India.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">1. Agreement to Terms</h3>
      <p>
        By accessing the website of <strong><?= htmlspecialchars($siteName) ?></strong> (saimangadigital.com), placing an online order, utilizing the live sqrft estimator, or approving a quotation, you agree to be legally bound by these Terms and Conditions.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">2. Custom Manufacturing &amp; Proof Approval</h3>
      <p>
        Most products provided by Sai Manga Digital—including 3D Acrylic LED channel letters, custom neon signs, star flex prints, etched brass plates, and roll-up standees—are made-to-order based on client-provided specifications.
      </p>
      <ul style="margin-left: 24px; margin-bottom: 16px;">
        <li><strong>Client Proof Approval:</strong> Before production commences, a digital layout proof is provided via WhatsApp or email. The client is strictly responsible for reviewing and approving all typography, spellings, contact numbers, layout orientation, and dimensions.</li>
        <li><strong>Post-Approval Errors:</strong> Once a proof is approved in writing, Sai Manga Digital is not liable for typographical errors or layout oversights originally present in the client's approved artwork.</li>
      </ul>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">3. Quotations &amp; Price Validity</h3>
      <p>
        Because wholesale prices of raw acrylic sheets, aluminium profiles, LED modules, and solvent inks fluctuate with market indices, custom architectural quotations provided on request remain valid for <strong>15 calendar days</strong> from the date of issue.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">4. Payment Terms</h3>
      <p>
        Full payment or an agreed minimum advance (typically 50% for high-value fabricated channel boards) is required prior to laser cutting and material procurement. Final settlement is due upon completion or prior to dispatch/installation. We accept UPI (Google Pay, PhonePe, Paytm), IMPS/NEFT, debit/credit cards, and direct in-store payments at our Madhuban Plaza counter.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">5. Site Clearance &amp; On-Site Installation</h3>
      <p>
        When on-site installation in Hyderabad or Secunderabad is contracted, the client is responsible for ensuring necessary building permissions, landlord approvals, and access to a working 220V AC electrical power source at the mounting elevation.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">6. Governing Law &amp; Jurisdiction</h3>
      <p>
        These terms and any contracts formed under them shall be governed by and construed in accordance with the laws of India. Any legal disputes arising out of transactions with Sai Manga Digital shall be subject to the exclusive jurisdiction of the competent courts in <strong>Secunderabad / Hyderabad, Telangana</strong>.
      </p>

    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

