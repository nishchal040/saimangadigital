<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Catalog & Products | Sai Manga Digital Signage Secunderabad';

// Get query parameters
$categorySlug = isset($_GET['category']) ? trim($_GET['category']) : '';
$searchQuery = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort = isset($_GET['sort']) ? trim($_GET['sort']) : 'featured';
$pricingType = isset($_GET['pricing_type']) ? trim($_GET['pricing_type']) : '';

// Build SQL
$whereClauses = ["p.is_active = 1"];
$params = [];

if (!empty($categorySlug)) {
    $whereClauses[] = "c.slug = ?";
    $params[] = $categorySlug;
}

if (!empty($searchQuery)) {
    $whereClauses[] = "(p.name LIKE ? OR p.short_desc LIKE ? OR p.description LIKE ?)";
    $like = '%' . $searchQuery . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

if (!empty($pricingType)) {
    $whereClauses[] = "p.pricing_type = ?";
    $params[] = $pricingType;
}

$orderBy = "p.is_featured DESC, p.id DESC";
if ($sort === 'price_asc') {
    $orderBy = "p.base_price ASC";
} elseif ($sort === 'price_desc') {
    $orderBy = "p.base_price DESC";
} elseif ($sort === 'rating') {
    $orderBy = "p.rating DESC";
}

$whereSql = implode(' AND ', $whereClauses);
$sql = "
    SELECT p.*, c.name as category_name, c.slug as category_slug 
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    WHERE {$whereSql} 
    ORDER BY {$orderBy}
";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

// Fetch all active categories for sidebar
$allCategories = $db->query("
    SELECT c.*, COUNT(p.id) as product_count 
    FROM categories c 
    LEFT JOIN products p ON c.id = p.category_id AND p.is_active = 1 
    WHERE c.is_active = 1 
    GROUP BY c.id 
    ORDER BY c.display_order ASC
")->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<!-- Minimalist Clean Header Banner -->
<div class="page-hero-banner">
  <div class="container">
    <div style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 8px;">
      <a href="<?= BASE_URL ?>/index.php" style="color: var(--text-muted);">Home</a> / 
      <span style="color: #111111; font-weight: 600;">Shop Catalog</span>
      <?php if (!empty($categorySlug)): ?>
        / <span style="color: var(--brand-blue); font-weight: 700;"><?= htmlspecialchars(ucwords(str_replace('-', ' ', $categorySlug))) ?></span>
      <?php endif; ?>
    </div>

    <h1 class="page-hero-title all-caps-title">
      <?= !empty($categorySlug) ? htmlspecialchars(ucwords(str_replace('-', ' ', $categorySlug))) : 'Signage &amp; Fabrication Catalog' ?>
    </h1>
    <p class="page-hero-desc">
      Showing <?= count($products) ?> available 3D LED letters, architectural signs, standees &amp; large-format materials.
    </p>

    <div style="margin-top: 20px;">
      <a href="<?= BASE_URL ?>/calculator.php" class="pill-btn pill-btn-primary pill-btn-sm">
        <i class="fas fa-calculator me-1"></i> Live Sqrft Price Estimator
      </a>
    </div>
  </div>
</div>

<!-- Main Shop Content with Sidebar -->
<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container">

    <!-- Mobile Filter Toggle Button -->
    <button type="button" class="mobile-filter-btn" onclick="document.getElementById('shopFilterSidebar').classList.toggle('active')">
      <i class="fas fa-sliders-h"></i> Filter Signage &amp; Categories (<?= count($products) ?> items)
    </button>

    <div class="resp-grid-sidebar">
      
      <!-- Filters Sidebar in Soft Grey -->
      <aside class="shop-filter-sidebar" id="shopFilterSidebar" style="background: var(--card-bg); border-radius: var(--radius-card); padding: 28px 24px; position: sticky; top: 100px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 22px; padding-bottom: 12px; border-bottom: 1px solid var(--border-subtle);">
          <strong style="font-size: 1.05rem; color: #111111; font-family: 'Outfit', sans-serif;"><i class="fas fa-sliders-h text-primary me-2"></i> Filters</strong>
          <a href="<?= BASE_URL ?>/shop.php" style="font-size: 0.82rem; color: var(--brand-red); font-weight: 700;">Reset</a>
        </div>

        <!-- Category Filter -->
        <div style="margin-bottom: 26px;">
          <h4 style="font-size: 0.82rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin-bottom: 12px; font-weight: 700;">Categories</h4>
          <ul style="list-style: none; display: flex; flex-direction: column; gap: 8px;">
            <li>
              <a href="<?= BASE_URL ?>/shop.php" style="display: flex; justify-content: space-between; align-items: center; padding: 6px 10px; border-radius: 8px; font-size: 0.88rem; font-weight: <?= empty($categorySlug) ? '700' : '500' ?>; color: <?= empty($categorySlug) ? 'var(--brand-blue)' : '#111111' ?>; background: <?= empty($categorySlug) ? 'var(--brand-blue-subtle)' : 'transparent' ?>;">
                <span>All Categories</span>
                <span style="font-size: 0.75rem; color: var(--text-muted);"><?= count($products) ?></span>
              </a>
            </li>
            <?php foreach ($allCategories as $cat): ?>
            <li>
              <a href="<?= BASE_URL ?>/shop.php?category=<?= urlencode($cat['slug']) ?>" style="display: flex; justify-content: space-between; align-items: center; padding: 6px 10px; border-radius: 8px; font-size: 0.88rem; font-weight: <?= $categorySlug === $cat['slug'] ? '700' : '500' ?>; color: <?= $categorySlug === $cat['slug'] ? 'var(--brand-blue)' : '#333333' ?>; background: <?= $categorySlug === $cat['slug'] ? 'var(--brand-blue-subtle)' : 'transparent' ?>;">
                <span><?= htmlspecialchars($cat['name']) ?></span>
                <span style="font-size: 0.75rem; color: var(--text-muted);"><?= $cat['product_count'] ?></span>
              </a>
            </li>
            <?php endforeach; ?>
          </ul>
        </div>

        <!-- Pricing Type Filter -->
        <div style="margin-bottom: 26px;">
          <h4 style="font-size: 0.82rem; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-muted); margin-bottom: 12px; font-weight: 700;">Pricing Type</h4>
          <div style="display: flex; flex-direction: column; gap: 8px; font-size: 0.88rem;">
            <a href="<?= BASE_URL ?>/shop.php?pricing_type=per_sqft<?= !empty($categorySlug) ? '&category=' . urlencode($categorySlug) : '' ?>" style="color: <?= $pricingType === 'per_sqft' ? 'var(--brand-blue)' : '#333333' ?>; font-weight: <?= $pricingType === 'per_sqft' ? '700' : '500' ?>;">
              <i class="fas fa-ruler-combined me-2 text-primary"></i> Custom Sq.Ft Pricing
            </a>
            <a href="<?= BASE_URL ?>/shop.php?pricing_type=fixed<?= !empty($categorySlug) ? '&category=' . urlencode($categorySlug) : '' ?>" style="color: <?= $pricingType === 'fixed' ? 'var(--brand-blue)' : '#333333' ?>; font-weight: <?= $pricingType === 'fixed' ? '700' : '500' ?>;">
              <i class="fas fa-box me-2 text-primary"></i> Fixed Price Products
            </a>
          </div>
        </div>

        <!-- Custom Sizing WhatsApp Desk -->
        <div style="background: #FFFFFF; border-radius: 16px; padding: 18px; text-align: center; box-shadow: 0 4px 12px rgba(0,0,0,0.04);">
          <i class="fab fa-whatsapp" style="font-size: 1.8rem; color: #10B981; margin-bottom: 8px;"></i>
          <h5 style="font-size: 0.95rem; font-weight: 700; color: #111111; margin-bottom: 4px;">Custom Size or Bulk?</h5>
          <p style="font-size: 0.8rem; color: var(--text-muted); margin-bottom: 12px;">Talk directly with our Secunderabad production desk.</p>
          <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', getSetting('whatsapp', '918047663573')) ?>" target="_blank" class="pill-btn pill-btn-primary pill-btn-sm" style="width: 100%;">
            WhatsApp Desk
          </a>
        </div>
      </aside>

      <!-- Products Listing Area -->
      <main>
        <!-- Sort & Control Bar -->
        <div style="background: var(--card-bg); border-radius: 16px; padding: 14px 22px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 28px; flex-wrap: wrap; gap: 14px;">
          <div style="font-size: 0.9rem; color: var(--text-muted);">
            Showing <strong style="color: #111111;"><?= count($products) ?></strong> products
            <?php if (!empty($searchQuery)): ?>
              for "<strong><?= htmlspecialchars($searchQuery) ?></strong>"
            <?php endif; ?>
          </div>

          <!-- Sort Select -->
          <form action="<?= BASE_URL ?>/shop.php" method="GET" style="display: flex; align-items: center; gap: 10px;">
            <?php if (!empty($categorySlug)): ?><input type="hidden" name="category" value="<?= htmlspecialchars($categorySlug) ?>"><?php endif; ?>
            <?php if (!empty($searchQuery)): ?><input type="hidden" name="search" value="<?= htmlspecialchars($searchQuery) ?>"><?php endif; ?>
            <label for="sortSelect" style="font-size: 0.82rem; color: var(--text-muted); font-weight: 700; text-transform: uppercase;">Sort By:</label>
            <select name="sort" id="sortSelect" onchange="this.form.submit()" class="sim-input-box" style="height: 38px; padding: 0 14px; font-size: 0.85rem; width: auto;">
              <option value="featured" <?= $sort === 'featured' ? 'selected' : '' ?>>Featured</option>
              <option value="price_asc" <?= $sort === 'price_asc' ? 'selected' : '' ?>>Price: Low to High</option>
              <option value="price_desc" <?= $sort === 'price_desc' ? 'selected' : '' ?>>Price: High to Low</option>
              <option value="rating" <?= $sort === 'rating' ? 'selected' : '' ?>>Customer Rating</option>
            </select>
          </form>
        </div>

        <?php if (empty($products)): ?>
          <div style="background: var(--card-bg); border-radius: var(--radius-card); padding: 60px 20px; text-align: center;">
            <i class="fas fa-search" style="font-size: 2.8rem; color: var(--text-light); margin-bottom: 16px;"></i>
            <h3 style="font-size: 1.3rem; font-weight: 700; color: #111111;">No Products Found</h3>
            <p style="color: var(--text-muted); max-width: 440px; margin: 8px auto 20px;">We couldn't find any products matching your selected criteria. Try resetting filters or request a custom quote.</p>
            <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-primary">Clear Filters</a>
          </div>
        <?php else: ?>
          <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 24px;">
            <?php foreach ($products as $product): ?>
              <div class="product-card-minimal">
                <div class="product-card-thumb">
                  <span class="product-badge-pill">
                    <?= $product['pricing_type'] === 'per_sqft' ? 'Per Sq.Ft' : 'Per Unit' ?>
                  </span>
                  <?php $inWishlist = isInWishlist($product['id']); ?>
                  <a href="<?= BASE_URL ?>/wishlist.php?action=<?= $inWishlist ? 'remove' : 'add' ?>&id=<?= $product['id'] ?>&redirect=<?= urlencode($_SERVER['REQUEST_URI'] ?? '/shop.php') ?>" 
                     class="wishlist-thumb-btn <?= $inWishlist ? 'active' : '' ?>" 
                     title="<?= $inWishlist ? 'Remove from Wishlist' : 'Save to Wishlist' ?>">
                    <i class="<?= $inWishlist ? 'fas' : 'far' ?> fa-heart"></i>
                  </a>
                  <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" loading="lazy">
                </div>

                <div class="product-card-body">
                  <div>
                    <div class="product-cat-tag"><?= htmlspecialchars($product['category_name']) ?></div>
                    <h3 class="product-card-title">
                      <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($product['slug']) ?>">
                        <?= htmlspecialchars($product['name']) ?>
                      </a>
                    </h3>
                  </div>

                  <div>
                    <div class="product-pricing-row">
                      <span class="product-price-current">
                        &#8377;<?= number_format($product['discount_price'] ?? $product['base_price'], 2) ?>
                      </span>
                      <?php if (!empty($product['discount_price']) && $product['discount_price'] < $product['base_price']): ?>
                        <span class="product-price-old">
                          &#8377;<?= number_format($product['base_price'], 2) ?>
                        </span>
                      <?php endif; ?>
                      <span class="product-price-unit">/ <?= htmlspecialchars($product['unit']) ?></span>
                    </div>

                    <div class="product-actions-row">
                      <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($product['slug']) ?>" class="pill-btn pill-btn-primary pill-btn-sm" style="flex: 1;">
                        Configure
                      </a>
                      <?php if ($product['pricing_type'] === 'per_sqft'): ?>
                        <a href="<?= BASE_URL ?>/calculator.php?product=<?= $product['id'] ?>" class="pill-btn pill-btn-outline pill-btn-sm" title="Calculate Sq.Ft">
                          <i class="fas fa-calculator"></i>
                        </a>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </main>

    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
