<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Privacy Policy | Sai Manga Digital';
$siteName = getSetting('site_name', 'Sai Manga Digital');
$email = getSetting('email', 'sales@saimangadigital.com');
$phone = getSetting('phone', '+91 8047663573');
$address = getSetting('address', 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, S.D. Road, Secunderabad - 500003');

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <h1 class="page-hero-title all-caps-title">Privacy Policy</h1>
    <p class="page-hero-desc">Your privacy is fundamental to our business. Learn how we handle your personal data and digital artwork.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 900px;">
    <div class="resp-card" style="font-size: 0.95rem; color: var(--text-muted); line-height: 1.8;">
      
      <p style="font-size: 0.85rem; color: var(--text-light); margin-bottom: 24px;">
        Last updated: <?= date('F d, Y') ?> &bull; Effective for all clients of Sai Manga Digital.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">1. Introduction &amp; Scope</h3>
      <p>
        <strong><?= htmlspecialchars($siteName) ?></strong> ("we", "us", or "our"), operated at Madhuban Plaza, S.D. Road, Secunderabad, is committed to safeguarding the personal and commercial privacy of visitors, customers, and corporate partners who use our website and fabrication services. This Privacy Policy outlines the types of data we collect, why we collect it, and how your information is protected in compliance with the Information Technology Act, 2000 and related rules.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">2. Information We Collect</h3>
      <p>When you interact with our website, request a fabrication quote, or place an order, we may collect the following information:</p>
      <ul style="margin-left: 24px; margin-bottom: 16px;">
        <li><strong>Contact Details:</strong> Full name, business email address, telephone/mobile number, company name, and delivery address.</li>
        <li><strong>Client Artwork &amp; Proprietary Assets:</strong> Logos, vector design files (.CDR, .AI, .PDF), structural elevation drawings, architectural blueprints, and site photographs uploaded for printing and signboard fabrication.</li>
        <li><strong>Transaction Information:</strong> Order numbers, product specifications, custom dimensions, billing records, and payment mode (UPI, Netbanking, Cash/Store payment). Note: We do not store sensitive credit/debit card PINs or CVV numbers on our servers.</li>
      </ul>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">3. Intellectual Property Protection of Uploaded Artwork</h3>
      <p>
        We treat all client artwork, trademarks, commercial brand assets, and proprietary design files with strict confidentiality. Your artwork files are utilized exclusively for the production, proofing, and fabrication of your ordered products. We do not sell, license, publish, or share your proprietary logos or designs with third parties without your prior consent.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">4. How We Use Your Data</h3>
      <ul style="margin-left: 24px; margin-bottom: 16px;">
        <li>To process, fabricate, and deliver your customized signage and large-format print orders.</li>
        <li>To communicate real-time design proofs, order progress updates, dispatch tracking, and invoices.</li>
        <li>To coordinate on-site installation and delivery schedules in Hyderabad and Secunderabad.</li>
        <li>To provide customer support and respond to quotation queries.</li>
      </ul>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">5. Data Retention &amp; Security</h3>
      <p>
        We implement industry-standard technical measures, secure session management, and restricted server access to protect your personal information against unauthorized disclosure. Digital artwork files are retained on our production archives for re-ordering convenience and can be permanently deleted upon client request.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 10px;">6. Contacting the Grievance Officer</h3>
      <p>
        If you have any questions regarding this Privacy Policy, your personal data, or wish to request data removal, please contact:
      </p>
      <div style="background: #FFFFFF; border-radius: 12px; padding: 18px 24px; margin-top: 14px; border: 1px solid var(--border-subtle);">
        <strong style="color: #111111; display: block; margin-bottom: 4px;"><?= htmlspecialchars($siteName) ?> &bull; Attn: Marri Prasad Naidu</strong>
        <span>Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, S.D. Road, Secunderabad, Telangana - 500003</span><br>
        <span>Email: <a href="mailto:<?= htmlspecialchars($email) ?>" style="color: var(--brand-blue);"><?= htmlspecialchars($email) ?></a> &bull; Phone: <?= htmlspecialchars($phone) ?></span>
      </div>

    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

