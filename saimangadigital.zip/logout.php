<?php
require_once __DIR__ . '/config/init.php';

unset($_SESSION['customer_id']);
unset($_SESSION['customer_name']);
unset($_SESSION['customer_email']);

setFlash('info', 'You have been logged out successfully.');
header('Location: ' . BASE_URL . '/index.php');
exit;

