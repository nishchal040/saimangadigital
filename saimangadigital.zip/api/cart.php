<?php
require_once dirname(__DIR__) . '/config/init.php';

header('Content-Type: application/json');

$action = $_REQUEST['action'] ?? '';

if ($action === 'get') {
    $cart = getCart();
    $totals = getCartTotals();
    echo json_encode([
        'status' => 'success',
        'count' => getCartCount(),
        'items' => array_values($cart),
        'totals' => $totals
    ]);
    exit;
}

if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $cartKey = addToCart($data);
    echo json_encode([
        'status' => 'success',
        'message' => 'Item added to cart',
        'cart_key' => $cartKey,
        'count' => getCartCount(),
        'totals' => getCartTotals()
    ]);
    exit;
}

if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $cartKey = $data['cart_key'] ?? '';
    $qty = (int)($data['quantity'] ?? 1);
    $ok = updateCartQuantity($cartKey, $qty);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'count' => getCartCount(),
        'totals' => getCartTotals()
    ]);
    exit;
}

if ($action === 'remove' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $cartKey = $data['cart_key'] ?? '';
    $ok = removeFromCart($cartKey);
    echo json_encode([
        'status' => $ok ? 'success' : 'error',
        'count' => getCartCount(),
        'totals' => getCartTotals()
    ]);
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Invalid action']);

