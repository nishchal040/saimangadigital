<?php
require_once dirname(__DIR__) . '/config/init.php';

header('Content-Type: application/json');

$width = (float)($_GET['width'] ?? 0);
$height = (float)($_GET['height'] ?? 0);
$qty = max(1, (int)($_GET['quantity'] ?? 1));
$rate = (float)($_GET['rate'] ?? 0);
$unit = $_GET['unit'] ?? 'feet';

if ($unit === 'inches') {
    $width = $width / 12;
    $height = $height / 12;
}

$sqft = $width * $height;
$totalSqft = $sqft * $qty;
$total = $totalSqft * $rate;

echo json_encode([
    'status' => 'success',
    'sqft' => round($sqft, 2),
    'total_sqft' => round($totalSqft, 2),
    'rate' => $rate,
    'total' => round($total, 2),
    'formatted_total' => formatPrice($total)
]);

