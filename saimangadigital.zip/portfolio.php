<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Installation Portfolio & Signage Gallery | Sai Manga Digital';
$whatsapp = getSetting('whatsapp', '918047663573');
$instagramUrl = getSetting('instagram', 'https://www.instagram.com/saimangadigital');

$portfolioProjects = [
    [
        'title' => 'Titanium Gold Front-Lit 3D Acrylic Elevation',
        'category' => '3D Signboards',
        'client' => 'Varma Jewellers • MG Road, Secunderabad',
        'image' => BASE_URL . '/assets/images/collection-sign-letters.jpg',
        'desc' => '3D fabricated cast acrylic letters with Korean Samsung daylight LED modules and titanium gold SS returns for exterior elevation.'
    ],
    [
        'title' => 'Square Double-Sided Illuminated Projection Lightbox',
        'category' => 'Blade Lightboxes',
        'client' => 'Cafe Royale • Banjara Hills, Hyderabad',
        'image' => BASE_URL . '/assets/images/collection-blade-sign.jpg',
        'desc' => 'Double-sided extruded aluminum projecting blade sign with high-lumen waterproof LED internal illumination.'
    ],
    [
        'title' => 'Custom Cursive Neon LED Glow Sign',
        'category' => 'Neon Flex Art',
        'client' => 'Studio 99 Salon &amp; Spa • Jubilee Hills',
        'image' => BASE_URL . '/assets/images/collection-neon.jpg',
        'desc' => '12V high-brightness silicone neon flex art mounted on 5mm contoured laser-cut acrylic backplate with remote dimmer.'
    ],
    [
        'title' => 'Executive Chemical-Etched SS &amp; Brass Nameplate',
        'category' => 'Corporate Plaques',
        'client' => 'Naidu &amp; Associates Legal • SD Road Secunderabad',
        'image' => BASE_URL . '/assets/images/about-craftsmanship.jpg',
        'desc' => 'High-grade 304 stainless steel and brass engraved corporate plaque with baked enamel lettering and acrylic spacers.'
    ],
    [
        'title' => 'Luxury Aluminium Exhibition Roll-Up Standees',
        'category' => 'Exhibition Displays',
        'client' => 'PharmaTech India Expo • HITEX Hyderabad',
        'image' => BASE_URL . '/assets/images/collection-standee.jpg',
        'desc' => '6x3 ft retractable heavy aluminium cassette banner stands with 1440 DPI high-definition non-tearable greyback film.'
    ],
    [
        'title' => 'High-Speed Large-Format Star Frontlit Flex Banner',
        'category' => 'Flex Printing',
        'client' => 'Apollo Clinic Elevation • Secunderabad',
        'image' => BASE_URL . '/assets/images/hero-printing-3d.jpg',
        'desc' => '340gsm heavy star frontlit flex banner with hemmed borders, rope pockets, and anti-rust brass grommets.'
    ]
];

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: #FFFFFF; padding: 6px 18px; border-radius: var(--radius-pill); font-size: 0.82rem; font-weight: 700; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <i class="fab fa-instagram" style="color: #E1306C;"></i> Featured Real-World Installations
    </div>
    <h1 class="page-hero-title all-caps-title">Project Installation Gallery</h1>
    <p class="page-hero-desc">Explore over 15,000+ completed commercial signboards, neon art, and large format prints across Telangana.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container">
    
    <!-- Top Bar with Instagram CTA -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 36px; flex-wrap: wrap; gap: 16px;">
      <div>
        <h2 style="font-size: 1.4rem; font-weight: 800; color: #111111; margin: 0;">Completed Fabrication Projects</h2>
        <p style="font-size: 0.9rem; color: var(--text-muted); margin: 4px 0 0;">Handcrafted at Madhuban Plaza by Marri Prasad Naidu's engineering team.</p>
      </div>

      <a href="<?= $instagramUrl ?>" target="_blank" class="pill-btn pill-btn-primary pill-btn-sm" style="background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%);">
        <i class="fab fa-instagram me-1"></i> Follow @saimangadigital For Daily Reels
      </a>
    </div>

    <!-- Gallery Grid -->
    <div class="products-grid-3">
      <?php foreach ($portfolioProjects as $project): ?>
        <div class="portfolio-card" style="background: var(--card-bg); border-radius: var(--radius-card); overflow: hidden; display: flex; flex-direction: column; box-shadow: var(--shadow-card); transition: transform 0.25s ease;" onmouseover="this.style.transform='translateY(-4px)'" onmouseout="this.style.transform='translateY(0)'">
          <div style="height: 240px; overflow: hidden; background: #FFFFFF; position: relative;">
            <span style="position: absolute; top: 14px; left: 14px; background: #111111; color: #FFFFFF; font-size: 0.72rem; font-weight: 800; padding: 4px 12px; border-radius: 999px; text-transform: uppercase;">
              <?= htmlspecialchars($project['category']) ?>
            </span>
            <img src="<?= htmlspecialchars($project['image']) ?>" alt="<?= htmlspecialchars($project['title']) ?>" style="width: 100%; height: 100%; object-fit: contain; padding: 12px;">
          </div>

          <div style="padding: 24px; display: flex; flex-direction: column; flex: 1; justify-content: space-between;">
            <div>
              <div style="font-size: 0.78rem; font-weight: 700; color: var(--brand-blue); margin-bottom: 6px;">
                <i class="fas fa-map-marker-alt me-1"></i> <?= htmlspecialchars($project['client']) ?>
              </div>
              <h3 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 10px; line-height: 1.35;">
                <?= htmlspecialchars($project['title']) ?>
              </h3>
              <p style="font-size: 0.88rem; color: var(--text-muted); line-height: 1.6; margin-bottom: 18px;">
                <?= htmlspecialchars($project['desc']) ?>
              </p>
            </div>

            <div style="display: flex; gap: 10px;">
              <a href="<?= BASE_URL ?>/contact.php#quoteForm" class="pill-btn pill-btn-primary pill-btn-sm" style="flex: 1; justify-content: center; text-align: center; font-size: 0.78rem; padding: 8px 12px;">
                Enquire Similar
              </a>
              <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsapp) ?>?text=Hello%20Sai%20Manga%20Digital,%20I%20am%20interested%20in%20a%20project%20like:%20<?= urlencode($project['title']) ?>" target="_blank" class="pill-btn pill-btn-outline pill-btn-sm" title="Discuss on WhatsApp" style="flex-shrink: 0; padding: 8px 14px;">
                <i class="fab fa-whatsapp"></i>
              </a>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

