<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'About Us | 30+ Years of Signage Mastery | Sai Manga Digital';
$proprietor = getSetting('proprietor', 'Marri Prasad Naidu');
$mapsUrl = getSetting('google_maps_url', 'https://maps.app.goo.gl/cNSaRii6R44K9t4c8');
$address = getSetting('address', 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, S.D. Road, Secunderabad - 500003');
$rating = getSetting('google_rating', '4.8');
$reviewsCount = getSetting('google_reviews_count', '68');

include __DIR__ . '/includes/header.php';
?>

<!-- Minimalist Clean Header Banner -->
<div class="page-hero-banner">
  <div class="container">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: #FFFFFF; padding: 6px 18px; border-radius: var(--radius-pill); font-size: 0.82rem; font-weight: 700; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <i class="fas fa-certificate" style="color: #F59E0B;"></i> Established 1994 &bull; Secunderabad, Telangana
    </div>
    <h1 class="page-hero-title all-caps-title">
      30+ Years of Signage Mastery
    </h1>
    <p class="page-hero-desc">
      From traditional screen printing in 1994 to architectural 3D LED illumination and Japanese large-format printing today, Sai Manga Digital sets the industry benchmark.
    </p>
  </div>
</div>

<!-- Story Section -->
<section style="padding: 60px 0 80px; background: #FFFFFF;">
  <div class="container">
    <div class="about-minimal-grid">
      <div class="about-text-content">
        <h2 style="font-size: 2.4rem; font-weight: 900; margin-bottom: 20px;">Built on Trust, Precision &amp; Heritage</h2>
        <p>
          Founded in 1994 by <strong><?= htmlspecialchars($proprietor) ?></strong> at Madhuban Plaza on Sarojini Devi (S.D.) Road in Secunderabad, <strong>Sai Manga Digital</strong> began with a clear mission: to provide Hyderabad and Secunderabad businesses with dependable, eye-catching visual branding that stands the test of time.
        </p>
        <p>
          Over the past three decades, we have fabricated more than 15,000 exterior signboards, glow signs, roll-up standees, and millions of square feet of flex printing for major retail chains, hospitals, educational institutions, jewellery houses, and corporate offices across South India.
        </p>

        <div class="about-stats-pills">
          <span class="about-stat-pill"><i class="fas fa-check-circle text-success"></i> 100% In-House Production</span>
          <span class="about-stat-pill"><i class="fas fa-cube text-primary"></i> 15,000+ Installations</span>
          <span class="about-stat-pill"><i class="fab fa-google" style="color: #4285F4;"></i> <?= htmlspecialchars($rating) ?> ★ Google Rating</span>
        </div>

        <div class="hero-cta-row" style="margin-top: 28px; margin-bottom: 0;">
          <a href="<?= htmlspecialchars($mapsUrl) ?>" target="_blank" class="pill-btn pill-btn-primary">
            <i class="fab fa-google me-1"></i> Visit On Google Maps
          </a>
          <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-outline">
            Browse Products
          </a>
        </div>
      </div>

      <div class="about-3d-visual-box">
        <img src="<?= BASE_URL ?>/assets/images/about-craftsmanship.jpg" alt="Sai Manga Digital Precision Signage Craftsmanship">
      </div>
    </div>
  </div>
</section>

<!-- Timeline Milestones in Clean Soft Grey Cards -->
<section style="padding: 70px 0 80px; background: var(--card-bg);">
  <div class="container">
    <div style="text-align: center; max-width: 650px; margin: 0 auto 50px;">
      <h2 style="font-size: 2.2rem; font-weight: 800; color: #111111; margin-bottom: 10px;">Three Decades of Innovation</h2>
      <p style="color: var(--text-muted); font-size: 1rem;">Key milestones that established Sai Manga Digital as Secunderabad's most trusted signage brand.</p>
    </div>

    <div style="max-width: 780px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px;">
      <div style="background: #FFFFFF; border-radius: 18px; padding: 24px 28px; display: flex; gap: 20px; align-items: flex-start; box-shadow: var(--shadow-card);">
        <div style="width: 54px; height: 54px; border-radius: 50%; background: var(--brand-blue); color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0; font-family: 'Outfit', sans-serif;">
          1994
        </div>
        <div>
          <h4 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 6px;">Establishment at Madhuban Plaza</h4>
          <p style="font-size: 0.92rem; color: var(--text-muted); margin: 0; line-height: 1.6;">Founded commercial operations at Madhuban Plaza on S.D. Road, providing screen printing, brass nameplates, and enamel glow signs.</p>
        </div>
      </div>

      <div style="background: #FFFFFF; border-radius: 18px; padding: 24px 28px; display: flex; gap: 20px; align-items: flex-start; box-shadow: var(--shadow-card);">
        <div style="width: 54px; height: 54px; border-radius: 50%; background: #0EA5E9; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0; font-family: 'Outfit', sans-serif;">
          2006
        </div>
        <div>
          <h4 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 6px;">Large-Format Solvent &amp; Flex Expansion</h4>
          <p style="font-size: 0.92rem; color: var(--text-muted); margin: 0; line-height: 1.6;">Introduced heavy-duty Japanese solvent printing machinery for high-output Star Flex banners, hoardings, and roll-up standees.</p>
        </div>
      </div>

      <div style="background: #FFFFFF; border-radius: 18px; padding: 24px 28px; display: flex; gap: 20px; align-items: flex-start; box-shadow: var(--shadow-card);">
        <div style="width: 54px; height: 54px; border-radius: 50%; background: #8B5CF6; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0; font-family: 'Outfit', sans-serif;">
          2016
        </div>
        <div>
          <h4 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 6px;">Architectural 3D LED &amp; Laser Cutting Unit</h4>
          <p style="font-size: 0.92rem; color: var(--text-muted); margin: 0; line-height: 1.6;">Installed high-speed CNC router tables, fiber laser cutters, and automated acrylic letter benders for illuminated 3D channel letters.</p>
        </div>
      </div>

      <div style="background: #FFFFFF; border-radius: 18px; padding: 24px 28px; display: flex; gap: 20px; align-items: flex-start; box-shadow: var(--shadow-card);">
        <div style="width: 54px; height: 54px; border-radius: 50%; background: #10B981; color: #FFFFFF; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0; font-family: 'Outfit', sans-serif;">
          2026
        </div>
        <div>
          <h4 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 6px;">Minimalist 3D Digital Platform &amp; Live Estimators</h4>
          <p style="font-size: 0.92rem; color: var(--text-muted); margin: 0; line-height: 1.6;">Redesigned our platform with real-time sqrft price calculators, 3D neon simulator, and direct digital quotations.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Direct Factory Quotation Strip -->
<div class="container">
  <div class="newsletter-dark-strip">
    <div class="newsletter-title-text">
      Request Direct Architectural Quotation
    </div>
    <form action="<?= BASE_URL ?>/contact.php#quoteForm" method="GET" class="newsletter-pill-form">
      <input type="text" name="phone_quote" placeholder="Enter your phone or email..." required>
      <button type="submit">GET QUOTE</button>
    </form>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
