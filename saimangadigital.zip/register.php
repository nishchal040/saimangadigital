<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Create Customer Account | Sai Manga Digital';
$error = '';
$redirect = sanitize($_GET['redirect'] ?? BASE_URL . '/account.php');

if (isCustomerLoggedIn()) {
    header('Location: ' . $redirect);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $phone = sanitize($_POST['phone'] ?? '');
    $company = sanitize($_POST['company'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $address = sanitize($_POST['address'] ?? '');
    $city = sanitize($_POST['city'] ?? 'Secunderabad');
    $pincode = sanitize($_POST['pincode'] ?? '');

    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        $error = 'Please fill in your name, email, phone number, and password.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please provide a valid email address.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters in length.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match. Please re-enter.';
    } else {
        // Check if email already registered
        $stmt = $db->prepare("SELECT id FROM customers WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = 'This email address is already registered. Please log in instead.';
        } else {
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            try {
                $ins = $db->prepare("
                    INSERT INTO customers (name, email, phone, company, password_hash, address, city, pincode)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $ins->execute([$name, $email, $phone, $company, $passwordHash, $address, $city, $pincode]);
                $newId = (int)$db->lastInsertId();

                $_SESSION['customer_id'] = $newId;
                $_SESSION['customer_name'] = $name;
                $_SESSION['customer_email'] = $email;

                setFlash('success', 'Your account has been created successfully! Welcome to Sai Manga Digital.');
                header('Location: ' . $redirect);
                exit;
            } catch (Exception $e) {
                $error = 'Registration failed: ' . $e->getMessage();
            }
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <h1 class="page-hero-title all-caps-title">Create Account</h1>
    <p class="page-hero-desc">Register for quick checkout, instant order tracking, and trade discount rates.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 620px;">
    <div class="resp-card" style="box-shadow: var(--shadow-card);">
      
      <?php if (!empty($error)): ?>
        <div style="background: #FEE2E2; border-left: 4px solid #EF4444; padding: 14px 18px; border-radius: 8px; margin-bottom: 24px; color: #B91C1C; font-weight: 600; font-size: 0.9rem;">
          <i class="fas fa-exclamation-circle me-1"></i> <?= htmlspecialchars($error) ?>
        </div>
      <?php endif; ?>

      <form action="" method="POST">
        <input type="hidden" name="redirect" value="<?= htmlspecialchars($redirect) ?>">

        <div class="form-grid-2" style="margin-bottom: 16px;">
          <div>
            <label class="clean-label">Full Name *</label>
            <input type="text" name="name" class="clean-input" placeholder="e.g. Anand Varma" value="<?= htmlspecialchars($_POST['name'] ?? '') ?>" required>
          </div>
          <div>
            <label class="clean-label">Mobile Number *</label>
            <input type="tel" name="phone" class="clean-input" placeholder="e.g. 98490 12345" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required>
          </div>
        </div>

        <div class="form-grid-2" style="margin-bottom: 16px;">
          <div>
            <label class="clean-label">Email Address *</label>
            <input type="email" name="email" class="clean-input" placeholder="e.g. anand@company.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
          </div>
          <div>
            <label class="clean-label">Company / Brand (Optional)</label>
            <input type="text" name="company" class="clean-input" placeholder="e.g. Varma Enterprises" value="<?= htmlspecialchars($_POST['company'] ?? '') ?>">
          </div>
        </div>

        <div class="form-grid-2" style="margin-bottom: 16px;">
          <div>
            <label class="clean-label">Password * (Min 6 chars)</label>
            <input type="password" name="password" class="clean-input" placeholder="Create password" required>
          </div>
          <div>
            <label class="clean-label">Confirm Password *</label>
            <input type="password" name="confirm_password" class="clean-input" placeholder="Re-enter password" required>
          </div>
        </div>

        <div style="margin-bottom: 16px;">
          <label class="clean-label">Delivery Street Address</label>
          <input type="text" name="address" class="clean-input" placeholder="Shop/Office No, Street, Landmark" value="<?= htmlspecialchars($_POST['address'] ?? '') ?>">
        </div>

        <div class="form-grid-2" style="margin-bottom: 24px;">
          <div>
            <label class="clean-label">City</label>
            <input type="text" name="city" class="clean-input" value="Secunderabad">
          </div>
          <div>
            <label class="clean-label">Pincode</label>
            <input type="text" name="pincode" class="clean-input" placeholder="500003" value="<?= htmlspecialchars($_POST['pincode'] ?? '') ?>">
          </div>
        </div>

        <button type="submit" class="pill-btn pill-btn-primary pill-btn-lg" style="width: 100%; margin-bottom: 20px;">
          Create My Account &rarr;
        </button>

        <div style="text-align: center; font-size: 0.9rem; color: var(--text-muted); padding-top: 18px; border-top: 1px solid var(--border-subtle);">
          Already have an account? 
          <a href="<?= BASE_URL ?>/login.php?redirect=<?= urlencode($redirect) ?>" style="color: var(--brand-blue); font-weight: 700;">
            Sign In here
          </a>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

