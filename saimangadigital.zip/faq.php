<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Frequently Asked Questions (FAQ) | Sai Manga Digital';
$phone = getSetting('phone', '+91 8047663573');
$whatsapp = getSetting('whatsapp', '918047663573');

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: #FFFFFF; padding: 6px 18px; border-radius: var(--radius-pill); font-size: 0.82rem; font-weight: 700; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <i class="fas fa-question-circle" style="color: var(--brand-blue);"></i> Help &amp; Knowledge Base
    </div>
    <h1 class="page-hero-title all-caps-title">Frequently Asked Questions</h1>
    <p class="page-hero-desc">Find quick answers to common questions about signage fabrication, file formats, and delivery.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 960px;">
    
    <!-- Quick Search or Help Strip -->
    <div style="background: var(--card-bg); border-radius: 18px; padding: 24px 30px; margin-bottom: 36px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 16px;">
      <div>
        <h3 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 4px;">Have a specific custom project inquiry?</h3>
        <p style="font-size: 0.88rem; color: var(--text-muted); margin: 0;">Speak directly with our fabrication engineers at Madhuban Plaza.</p>
      </div>
      <div style="display: flex; gap: 10px;">
        <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsapp) ?>" target="_blank" class="pill-btn pill-btn-primary pill-btn-sm">
          <i class="fab fa-whatsapp me-1"></i> WhatsApp Desk
        </a>
        <a href="<?= BASE_URL ?>/calculator.php" class="pill-btn pill-btn-outline pill-btn-sm">
          <i class="fas fa-calculator me-1"></i> Live Estimator
        </a>
      </div>
    </div>

    <!-- FAQ Accordion Items -->
    <div style="display: flex; flex-direction: column; gap: 20px;">
      
      <!-- Section 1: Sizing & Sqrft Calculation -->
      <div class="faq-card">
        <h3 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
          <span style="width: 28px; height: 28px; border-radius: 50%; background: var(--brand-blue); color: #fff; font-size: 0.85rem; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;">1</span>
          How do I calculate the square footage of my signboard or flex banner?
        </h3>
        <p class="faq-card-answer">
          Square feet is calculated simply by multiplying <strong>Width (in feet) &times; Height (in feet)</strong>. For example, a shopfront board measuring 10 feet wide by 3 feet high equals <strong>30 square feet</strong>. If you have dimensions in inches, divide the total square inches by 144. You can also use our <a href="<?= BASE_URL ?>/calculator.php" style="color: var(--brand-blue); font-weight: 700;">Live Sqrft Estimator</a> to calculate immediate costs in both feet and inches.
        </p>
      </div>

      <!-- Section 2: File Formats -->
      <div class="faq-card">
        <h3 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
          <span style="width: 28px; height: 28px; border-radius: 50%; background: var(--brand-blue); color: #fff; font-size: 0.85rem; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;">2</span>
          What file formats do you accept for high-resolution printing &amp; CNC cutting?
        </h3>
        <p class="faq-card-answer">
          For large-format Star Flex and vinyl printing, we recommend high-resolution <strong>PDF, TIFF, or JPEG files at 150 to 300 DPI in CMYK color mode</strong>. For 3D acrylic laser cutting and CNC channel letters, vector formats such as <strong>CorelDraw (.CDR), Adobe Illustrator (.AI), or vector PDF</strong> with all fonts converted to curves/outlines give the sharpest finish. View our <a href="<?= BASE_URL ?>/file-guidelines.php" style="color: var(--brand-blue); font-weight: 700;">File Preparation Guidelines</a> for exact specifications.
        </p>
      </div>

      <!-- Section 3: Proofing -->
      <div class="faq-card">
        <h3 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
          <span style="width: 28px; height: 28px; border-radius: 50%; background: var(--brand-blue); color: #fff; font-size: 0.85rem; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;">3</span>
          Will I receive a proof before production begins?
        </h3>
        <p class="faq-card-answer">
          <strong>Yes, absolutely.</strong> No job goes to our Japanese plotters or laser cutters without your written or WhatsApp approval. Once you place an order or quote request, our pre-press team inspects resolution, bleed, and color calibration, sending you a 1:1 scale digital proof.
        </p>
      </div>

      <!-- Section 4: Production Turnaround -->
      <div class="faq-card">
        <h3 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
          <span style="width: 28px; height: 28px; border-radius: 50%; background: var(--brand-blue); color: #fff; font-size: 0.85rem; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;">4</span>
          How fast can my order be completed and dispatched?
        </h3>
        <p class="faq-card-answer">
          Standard Star Flex banners and roll-up pull standees can be produced on the <strong>same day</strong> (within 4 to 6 hours for emergency orders). Architectural 3D Acrylic LED channel letter boards and custom neon flex signs typically require <strong>48 to 72 hours</strong> for precision laser cutting, letter bending, wiring Samsung LED modules, and quality testing.
        </p>
      </div>

      <!-- Section 5: Pickup & Installation -->
      <div class="faq-card">
        <h3 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
          <span style="width: 28px; height: 28px; border-radius: 50%; background: var(--brand-blue); color: #fff; font-size: 0.85rem; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;">5</span>
          Can I collect my order directly from your Secunderabad workshop?
        </h3>
        <p class="faq-card-answer">
          <strong>Yes, self-pickup is 100% free!</strong> You can collect your ready signs directly from our flagship workshop at <strong>Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, S.D. Road, Secunderabad</strong>. We also provide on-site installation crews with structural MS framework across Hyderabad and Secunderabad.
        </p>
      </div>

      <!-- Section 6: Warranty -->
      <div class="faq-card">
        <h3 style="font-size: 1.15rem; font-weight: 800; color: #111111; margin-bottom: 10px; display: flex; align-items: center; gap: 10px;">
          <span style="width: 28px; height: 28px; border-radius: 50%; background: var(--brand-blue); color: #fff; font-size: 0.85rem; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0;">6</span>
          What warranty is provided on LED modules and power supplies?
        </h3>
        <p class="faq-card-answer">
          All our illuminated 3D channel letters and lightboxes feature genuine IP67/IP68 waterproof LED modules (Samsung / Osram grade) and high-efficiency Mean Well power supply units backed by an official <strong>1 to 2-year warranty</strong> against component failure.
        </p>
      </div>

    </div>

    <!-- Direct Contact CTA -->
    <div style="margin-top: 48px; text-align: center;">
      <p style="color: var(--text-muted); font-size: 0.95rem; margin-bottom: 16px;">Still have questions that are not answered here?</p>
      <a href="<?= BASE_URL ?>/contact.php" class="pill-btn pill-btn-primary pill-btn-lg">
        Contact Our Customer Desk &rarr;
      </a>
    </div>

  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

