<?php
require_once __DIR__ . '/config/init.php';

$slug = isset($_GET['slug']) ? trim($_GET['slug']) : '';
if (empty($slug)) {
    header('Location: ' . BASE_URL . '/shop.php');
    exit;
}

// Fetch Product
$stmt = $db->prepare("
    SELECT p.*, c.name as category_name, c.slug as category_slug 
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    WHERE p.slug = ? AND p.is_active = 1
");
$stmt->execute([$slug]);
$product = $stmt->fetch();

if (!$product) {
    header('Location: ' . BASE_URL . '/shop.php');
    exit;
}

$pageTitle = htmlspecialchars($product['name']) . ' | Sai Manga Digital';

// Decode options
$materials = !empty($product['material_options']) ? json_decode($product['material_options'], true) : [];
$finishes = !empty($product['finish_options']) ? json_decode($product['finish_options'], true) : [];
$gallery = !empty($product['gallery']) ? json_decode($product['gallery'], true) : [$product['image']];

// Handle Add to Cart submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_to_cart') {
    $qty = max(1, (int)($_POST['quantity'] ?? 1));
    $width = (float)($_POST['width'] ?? $product['default_width']);
    $height = (float)($_POST['height'] ?? $product['default_height']);
    $materialName = sanitize($_POST['material'] ?? 'Standard');
    $finishName = sanitize($_POST['finish'] ?? 'Standard');
    $customNotes = sanitize($_POST['custom_notes'] ?? '');

    // Compute unit price with material modifier
    $basePrice = (!empty($product['discount_price']) && $product['discount_price'] > 0) ? (float)$product['discount_price'] : (float)$product['base_price'];
    $materialMod = 0.00;
    if (!empty($materials)) {
        foreach ($materials as $m) {
            if ($m['name'] === $materialName) {
                $materialMod = (float)($m['price_mod'] ?? 0.00);
                break;
            }
        }
    }
    $effectiveUnitPrice = $basePrice + $materialMod;

    // Artwork upload handling
    $artworkFileName = '';
    if (isset($_FILES['artwork_file']) && $_FILES['artwork_file']['error'] === UPLOAD_ERR_OK) {
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf', 'cdr', 'ai', 'psd', 'zip'];
        $origName = $_FILES['artwork_file']['name'];
        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        if (in_array($ext, $allowedExtensions)) {
            $newName = 'art_' . time() . '_' . rand(100, 999) . '.' . $ext;
            $uploadTarget = APP_ROOT . '/uploads/artwork/' . $newName;
            if (move_uploaded_file($_FILES['artwork_file']['tmp_name'], $uploadTarget)) {
                $artworkFileName = $newName;
            }
        }
    }

    $totalSqft = ($product['pricing_type'] === 'per_sqft') ? ($width * $height) : 0.00;

    addToCart([
        'product_id' => $product['id'],
        'name' => $product['name'],
        'image' => $product['image'],
        'pricing_type' => $product['pricing_type'],
        'unit_price' => $effectiveUnitPrice,
        'quantity' => $qty,
        'width' => $width,
        'height' => $height,
        'total_sqft' => $totalSqft,
        'material' => $materialName,
        'finish' => $finishName,
        'custom_notes' => $customNotes,
        'artwork_file' => $artworkFileName
    ]);

    setFlash('success', 'Added ' . htmlspecialchars($product['name']) . ' to your shopping cart!');

    if (isset($_POST['buy_now'])) {
        header('Location: ' . BASE_URL . '/checkout.php');
        exit;
    } else {
        header('Location: ' . BASE_URL . '/cart.php');
        exit;
    }
}

// Fetch related products
$relatedProducts = $db->prepare("
    SELECT * FROM products 
    WHERE category_id = ? AND id != ? AND is_active = 1 
    ORDER BY id DESC LIMIT 3
");
$relatedProducts->execute([$product['category_id'], $product['id']]);
$related = $relatedProducts->fetchAll();

include __DIR__ . '/includes/header.php';
?>

<!-- Breadcrumb -->
<div style="background: #ffffff; border-bottom: 1px solid var(--border-color); padding: 14px 0;">
  <div class="container">
    <nav style="font-size: 0.85rem; color: var(--text-muted);">
      <a href="<?= BASE_URL ?>/index.php" style="color: var(--text-muted);">Home</a> / 
      <a href="<?= BASE_URL ?>/shop.php" style="color: var(--text-muted);">Shop</a> / 
      <a href="<?= BASE_URL ?>/shop.php?category=<?= urlencode($product['category_slug']) ?>" style="color: var(--text-muted);"><?= htmlspecialchars($product['category_name']) ?></a> / 
      <span style="color: var(--secondary); font-weight: 600;"><?= htmlspecialchars($product['name']) ?></span>
    </nav>
  </div>
</div>

<!-- Product Main Details Section -->
<section class="section-padding">
  <div class="container">
    <div class="resp-grid-two-col">
      
      <!-- Gallery Column -->
      <div>
        <div class="pdp-main-img-box" style="background: #ffffff; border-radius: var(--radius-lg); border: 1px solid var(--border-color); overflow: hidden; box-shadow: var(--shadow-md); margin-bottom: 16px; height: clamp(280px, 42vw, 460px);">
          <img id="mainProductImage" src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>" style="width: 100%; height: 100%; object-fit: cover; transition: transform 0.3s ease;">
        </div>

        <?php if (!empty($gallery) && count($gallery) > 1): ?>
        <div style="display: flex; gap: 12px; overflow-x: auto; padding-bottom: 6px;">
          <?php foreach ($gallery as $thumb): ?>
          <button type="button" onclick="document.getElementById('mainProductImage').src = '<?= htmlspecialchars($thumb) ?>'" style="width: 80px; height: 80px; border-radius: var(--radius-sm); border: 2px solid var(--border-color); overflow: hidden; cursor: pointer; padding: 0; background: none; flex-shrink: 0;">
            <img src="<?= htmlspecialchars($thumb) ?>" alt="Thumb" style="width: 100%; height: 100%; object-fit: cover;">
          </button>
          <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Highlights Box -->
        <div style="background: #ffffff; border-radius: var(--radius-md); border: 1px solid var(--border-color); padding: 20px; margin-top: 24px;">
          <h4 style="font-size: 0.95rem; font-weight: 700; color: var(--secondary); margin-bottom: 12px;">Quality Guarantee from Sai Manga Digital:</h4>
          <ul style="list-style: none; display: flex; flex-direction: column; gap: 8px; font-size: 0.88rem; color: var(--text-muted);">
            <li><i class="fas fa-check-circle text-success me-2"></i> Heavy-grade cast acrylic &amp; genuine branded PVC materials</li>
            <li><i class="fas fa-check-circle text-success me-2"></i> Free graphic design check &amp; print file proofing</li>
            <li><i class="fas fa-check-circle text-success me-2"></i> Fast pickup available at Madhuban Plaza, S.D. Road Secunderabad</li>
            <li><i class="fas fa-check-circle text-success me-2"></i> Safe courier dispatch across Telangana &amp; India</li>
          </ul>
        </div>
      </div>

      <!-- Configurator / Purchase Column -->
      <div style="background: #ffffff; border-radius: var(--radius-lg); border: 1px solid var(--border-color); padding: 32px; box-shadow: var(--shadow-md);">
        <div style="font-size: 0.82rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--primary); margin-bottom: 6px;">
          <?= htmlspecialchars($product['category_name']) ?> • SKU: <?= htmlspecialchars($product['sku']) ?>
        </div>
        
        <h1 style="font-size: 1.85rem; font-weight: 800; color: var(--secondary); line-height: 1.25; margin-bottom: 12px;">
          <?= htmlspecialchars($product['name']) ?>
        </h1>

        <!-- Rating & Reviews -->
        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px; font-size: 0.9rem;">
          <div class="stars" style="color: #f59e0b;">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
          </div>
          <span style="font-weight: 700; color: var(--secondary);"><?= number_format($product['rating'], 1) ?> / 5.0</span>
          <span style="color: var(--text-muted);">(<?= $product['review_count'] ?> verified orders)</span>
        </div>

        <!-- Price Display -->
        <div style="background: #f8fafc; border: 1px solid var(--border-color); border-radius: var(--radius-md); padding: 18px; margin-bottom: 24px; display: flex; align-items: baseline; justify-content: space-between;">
          <div>
            <div style="font-size: 0.8rem; text-transform: uppercase; color: var(--text-muted); font-weight: 600;">
              <?= $product['pricing_type'] === 'per_sqft' ? 'Base Rate (Per Square Foot)' : 'Price Per Unit' ?>
            </div>
            <div style="display: flex; align-items: baseline; gap: 10px; margin-top: 2px;">
              <?php if (!empty($product['discount_price']) && $product['discount_price'] < $product['base_price']): ?>
                <span id="displayUnitPrice" style="font-size: 2rem; font-weight: 900; color: var(--primary);" data-base-price="<?= $product['discount_price'] ?>">
                  <?= formatPrice($product['discount_price']) ?>
                </span>
                <span style="font-size: 1.1rem; color: var(--text-light); text-decoration: line-through;">
                  <?= formatPrice($product['base_price']) ?>
                </span>
              <?php else: ?>
                <span id="displayUnitPrice" style="font-size: 2rem; font-weight: 900; color: var(--primary);" data-base-price="<?= $product['base_price'] ?>">
                  <?= formatPrice($product['base_price']) ?>
                </span>
              <?php endif; ?>
              <span style="font-size: 0.9rem; color: var(--text-muted); font-weight: 600;">/ <?= htmlspecialchars($product['unit']) ?></span>
            </div>
          </div>

          <?php if (!empty($product['discount_price']) && $product['discount_price'] < $product['base_price']): ?>
            <?php 
              $discountPercent = round((($product['base_price'] - $product['discount_price']) / $product['base_price']) * 100);
            ?>
            <span class="badge bg-success" style="font-size: 0.85rem; padding: 6px 12px;">
              Save <?= $discountPercent ?>% OFF
            </span>
          <?php endif; ?>
        </div>

        <!-- Customizer Form -->
        <form action="" method="POST" enctype="multipart/form-data" id="productConfigForm">
          <input type="hidden" name="action" value="add_to_cart">
          <input type="hidden" id="prodPricingType" value="<?= $product['pricing_type'] ?>">

          <!-- Custom Sizing for Per Sqft Products -->
          <?php if ($product['pricing_type'] === 'per_sqft'): ?>
          <div style="background: #f1f5f9; border-radius: var(--radius-md); padding: 18px; margin-bottom: 20px;">
            <div style="font-weight: 700; font-size: 0.92rem; color: var(--secondary); margin-bottom: 12px; display: flex; align-items: center; justify-content: space-between;">
              <span><i class="fas fa-ruler-combined text-primary me-2"></i> Custom Signage Dimensions</span>
              <span style="font-size: 0.78rem; color: var(--text-muted);">(In Feet)</span>
            </div>

            <div class="form-row">
              <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label" style="color: var(--secondary); font-size: 0.82rem;">Width (Feet)</label>
                <input type="number" name="width" id="pdpWidth" class="form-control" value="<?= htmlspecialchars($product['default_width']) ?>" step="0.5" min="0.5" required style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
              </div>
              <div class="form-group" style="margin-bottom: 0;">
                <label class="form-label" style="color: var(--secondary); font-size: 0.82rem;">Height (Feet)</label>
                <input type="number" name="height" id="pdpHeight" class="form-control" value="<?= htmlspecialchars($product['default_height']) ?>" step="0.5" min="0.5" required style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
              </div>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 12px; padding-top: 10px; border-top: 1px solid #e2e8f0; font-size: 0.85rem;">
              <span>Calculated Area:</span>
              <strong id="pdpTotalSqftDisplay" style="color: var(--primary);">0.00 sq.ft</strong>
            </div>
          </div>
          <?php endif; ?>

          <!-- Material / Substrate Options -->
          <?php if (!empty($materials)): ?>
          <div class="form-group">
            <label class="form-label" style="color: var(--secondary); font-size: 0.88rem;">Select Material / Thickness Specification</label>
            <select name="material" id="pdpMaterial" class="form-select" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
              <?php foreach ($materials as $mat): ?>
                <option value="<?= htmlspecialchars($mat['name']) ?>" data-mod="<?= (float)($mat['price_mod'] ?? 0) ?>">
                  <?= htmlspecialchars($mat['name']) ?> <?= $mat['price_mod'] > 0 ? '(+' . formatPrice($mat['price_mod']) . ')' : '' ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
          <?php endif; ?>

          <!-- Finishing Options -->
          <?php if (!empty($finishes)): ?>
          <div class="form-group">
            <label class="form-label" style="color: var(--secondary); font-size: 0.88rem;">Finishing / Mounting Option</label>
            <select name="finish" class="form-select" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
              <?php foreach ($finishes as $fin): ?>
                <option value="<?= htmlspecialchars($fin) ?>"><?= htmlspecialchars($fin) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <?php endif; ?>

          <!-- Quantity Selector -->
          <div class="form-group">
            <label class="form-label" style="color: var(--secondary); font-size: 0.88rem;">Quantity</label>
            <div style="display: flex; align-items: center; gap: 12px;">
              <div class="qty-control-wrapper" style="display: flex; align-items: center; border: 1.5px solid var(--border-color); border-radius: var(--radius-md); overflow: hidden; width: 140px;">
                <button type="button" class="qty-minus" style="width: 40px; height: 42px; border: none; background: #f8fafc; font-size: 1.1rem; cursor: pointer;">-</button>
                <input type="number" name="quantity" id="pdpQty" class="qty-input" value="1" min="1" style="width: 60px; height: 42px; border: none; text-align: center; font-weight: 700; font-size: 1rem; color: var(--secondary);">
                <button type="button" class="qty-plus" style="width: 40px; height: 42px; border: none; background: #f8fafc; font-size: 1.1rem; cursor: pointer;">+</button>
              </div>
              <span style="font-size: 0.85rem; color: var(--text-muted);"><?= htmlspecialchars($product['unit']) ?>(s)</span>
            </div>
          </div>

          <!-- Artwork Upload -->
          <div class="form-group" style="background: #f8fafc; border: 1.5px dashed var(--border-color); border-radius: var(--radius-md); padding: 16px;">
            <label class="form-label" style="color: var(--secondary); font-size: 0.85rem; display: flex; align-items: center; gap: 6px;">
              <i class="fas fa-cloud-upload-alt text-primary"></i> Upload Your Design Artwork (Optional)
            </label>
            <input type="file" name="artwork_file" class="form-control" style="background: #ffffff; color: var(--secondary); font-size: 0.82rem; border: 1px solid var(--border-color);">
            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 6px;">
              Formats: PDF, CDR, AI, PSD, JPG, PNG (Max 50MB). Don't have artwork? We provide graphic design assistance!
            </div>
          </div>

          <!-- Custom Instructions -->
          <div class="form-group">
            <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Custom Text / Instructions / Color Preferences</label>
            <textarea name="custom_notes" rows="2" class="form-control" placeholder="e.g. Please put text in white glow with golden borders. Call me before printing." style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);"></textarea>
          </div>

          <!-- Live Total Calculation Bar -->
          <div style="background: linear-gradient(135deg, #191047 0%, #342784 100%); color: #ffffff; border-radius: var(--radius-md); padding: 18px 24px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px;">
            <div>
              <div style="font-size: 0.78rem; text-transform: uppercase; color: #bfdbfe; font-weight: 700;">Calculated Item Total</div>
              <div id="pdpLiveGrandTotal" style="font-size: 1.9rem; font-weight: 900; line-height: 1.2;">₹ 0.00</div>
            </div>
            <div style="text-align: right; font-size: 0.78rem; color: #e2e8f0;">
              <div>Free Pickup in Secunderabad</div>
              <div>GST calculated at checkout</div>
            </div>
          </div>

          <!-- Action Buttons -->
          <div style="display: flex; flex-direction: column; gap: 12px;">
            <div class="form-grid-2" style="gap: 12px;">
              <button type="submit" name="add_to_cart" class="btn btn-primary btn-lg" style="justify-content: center; width: 100%;">
                <i class="fas fa-shopping-bag"></i> Add to Cart
              </button>
              <button type="submit" name="buy_now" class="btn btn-secondary btn-lg" style="justify-content: center; width: 100%;">
                <i class="fas fa-bolt"></i> Buy Now
              </button>
            </div>

            <!-- Instant WhatsApp Order Pre-filled button -->
            <button type="button" id="btnWhatsappOrder" class="btn btn-whatsapp btn-lg" style="width: 100%; justify-content: center;">
              <i class="fab fa-whatsapp"></i> Instant WhatsApp Order / Enquiry
            </button>

            <!-- Save to Wishlist Toggle -->
            <?php $inWishlist = isInWishlist($product['id']); ?>
            <a href="<?= BASE_URL ?>/wishlist.php?action=<?= $inWishlist ? 'remove' : 'add' ?>&id=<?= $product['id'] ?>&redirect=<?= urlencode($_SERVER['REQUEST_URI'] ?? ('/product.php?slug=' . $product['slug'])) ?>" 
               class="btn btn-outline" style="width: 100%; justify-content: center; gap: 8px; color: <?= $inWishlist ? '#DC2626' : 'var(--secondary)' ?>; border-color: <?= $inWishlist ? '#FCA5A5' : 'var(--border-color)' ?>; background: <?= $inWishlist ? '#FEF2F2' : '#FFFFFF' ?>; font-weight: 600;">
              <i class="<?= $inWishlist ? 'fas' : 'far' ?> fa-heart" style="<?= $inWishlist ? 'color: #DC2626;' : '' ?>"></i>
              <?= $inWishlist ? 'Saved in Wishlist (Click to Remove)' : 'Save to Wishlist' ?>
            </a>
          </div>
        </form>
      </div>

    </div>

    <!-- Product Description & Specifications Tabs -->
    <div style="margin-top: 60px; background: #ffffff; border-radius: var(--radius-lg); border: 1px solid var(--border-color); padding: 36px; box-shadow: var(--shadow-sm);">
      <h3 style="font-size: 1.4rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px; padding-bottom: 12px; border-bottom: 2px solid #f1f5f9;">
        Product Overview &amp; Specifications
      </h3>
      <div style="color: var(--text-main); font-size: 1rem; line-height: 1.8;">
        <?= $product['description'] ?: '<p>High precision digital print solution produced with Japanese color technology and premium materials at Sai Manga Digital, Secunderabad.</p>' ?>
      </div>
    </div>

    <!-- Related Products -->
    <?php if (!empty($related)): ?>
    <div style="margin-top: 70px;">
      <h3 style="font-size: 1.6rem; font-weight: 800; color: var(--secondary); margin-bottom: 24px;">
        Related Signage &amp; Prints
      </h3>
      <div class="products-grid">
        <?php foreach ($related as $rel): ?>
        <div class="product-card">
          <div class="product-thumb">
            <img src="<?= htmlspecialchars($rel['image']) ?>" alt="<?= htmlspecialchars($rel['name']) ?>" loading="lazy">
          </div>
          <div class="product-content">
            <h4 class="product-title">
              <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($rel['slug']) ?>"><?= htmlspecialchars($rel['name']) ?></a>
            </h4>
            <div class="product-price-row">
              <span class="current-price"><?= formatPrice($rel['discount_price'] ?: $rel['base_price']) ?></span>
              <a href="<?= BASE_URL ?>/product.php?slug=<?= urlencode($rel['slug']) ?>" class="btn btn-outline btn-sm">View &rarr;</a>
            </div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

  </div>
</section>

<!-- PDP Real-time Calculation JS Script -->
<script>
document.addEventListener('DOMContentLoaded', () => {
    const pricingType = document.getElementById('prodPricingType')?.value;
    const basePriceEl = document.getElementById('displayUnitPrice');
    const basePrice = parseFloat(basePriceEl?.dataset?.basePrice || 0);
    const materialSelect = document.getElementById('pdpMaterial');
    const widthInput = document.getElementById('pdpWidth');
    const heightInput = document.getElementById('pdpHeight');
    const qtyInput = document.getElementById('pdpQty');
    const sqftDisplay = document.getElementById('pdpTotalSqftDisplay');
    const grandTotalDisplay = document.getElementById('pdpLiveGrandTotal');
    const btnWhatsapp = document.getElementById('btnWhatsappOrder');

    function updatePdpCalculation() {
        const selectedMat = materialSelect?.options[materialSelect.selectedIndex];
        const matMod = parseFloat(selectedMat?.dataset?.mod || 0);
        const currentUnitPrice = basePrice + matMod;
        const qty = parseInt(qtyInput?.value) || 1;

        let total = 0;
        let sqft = 0;

        if (pricingType === 'per_sqft') {
            const w = parseFloat(widthInput?.value) || 0;
            const h = parseFloat(heightInput?.value) || 0;
            sqft = (w * h);
            if (sqftDisplay) {
                sqftDisplay.innerText = sqft.toFixed(2) + ' sq.ft';
            }
            total = currentUnitPrice * sqft * qty;
        } else {
            total = currentUnitPrice * qty;
        }

        if (grandTotalDisplay) {
            grandTotalDisplay.innerText = '₹ ' + total.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }

        return { total, sqft, qty, currentUnitPrice };
    }

    [widthInput, heightInput, materialSelect, qtyInput].forEach(el => {
        if (el) {
            el.addEventListener('input', updatePdpCalculation);
            el.addEventListener('change', updatePdpCalculation);
        }
    });

    updatePdpCalculation();

    // WhatsApp Order Click handler
    if (btnWhatsapp) {
        btnWhatsapp.addEventListener('click', () => {
            const calc = updatePdpCalculation();
            const prodName = <?= json_encode($product['name']) ?>;
            const matName = materialSelect?.value || 'Standard';
            let message = `Hello Sai Manga Digital! I would like to order/inquire about:\n\n*Product:* ${prodName}\n*Quantity:* ${calc.qty}\n*Material:* ${matName}\n`;
            if (pricingType === 'per_sqft') {
                const w = widthInput?.value || 0;
                const h = heightInput?.value || 0;
                message += `*Dimensions:* ${w} ft x ${h} ft (${calc.sqft.toFixed(2)} sq.ft)\n`;
            }
            message += `*Estimated Total:* ₹ ${calc.total.toFixed(2)}\n\nPlease assist with the order and file checking.`;

            const phone = <?= json_encode(preg_replace('/[^0-9]/', '', getSetting('whatsapp', '918047663573'))) ?>;
            const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
            window.open(url, '_blank');
        });
    }
});
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>

