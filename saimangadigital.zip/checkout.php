<?php
require_once __DIR__ . '/config/init.php';

$cart = getCart();
if (empty($cart)) {
    header('Location: ' . BASE_URL . '/cart.php');
    exit;
}

$totals = getCartTotals();
$pageTitle = 'Secure Checkout | Sai Manga Digital';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $customerName = sanitize($_POST['customer_name'] ?? '');
    $customerEmail = sanitize($_POST['customer_email'] ?? '');
    $customerPhone = sanitize($_POST['customer_phone'] ?? '');
    $deliveryType = sanitize($_POST['delivery_type'] ?? 'delivery');
    $address = sanitize($_POST['address'] ?? '');
    $city = sanitize($_POST['city'] ?? 'Secunderabad');
    $state = sanitize($_POST['state'] ?? 'Telangana');
    $pincode = sanitize($_POST['pincode'] ?? '');
    $notes = sanitize($_POST['notes'] ?? '');
    $paymentMethod = sanitize($_POST['payment_method'] ?? 'upi');

    if (empty($customerName) || empty($customerPhone) || empty($customerEmail)) {
        $error = 'Please fill in your name, valid email, and contact phone number.';
    } elseif ($deliveryType === 'delivery' && (empty($address) || empty($pincode))) {
        $error = 'Please provide a valid delivery address and pincode.';
    } else {
        $orderNumber = generateOrderNumber();
        $subtotal = $totals['subtotal'];
        $taxAmount = $totals['tax'];
        $shippingFee = ($deliveryType === 'pickup') ? 0.00 : $totals['shipping'];
        $grandTotal = $subtotal + $taxAmount + $shippingFee;

        // Payment status
        $paymentStatus = ($paymentMethod === 'upi') ? 'pending' : 'pending';
        $orderStatus = 'pending';
        $customerId = getCustomerId();

        try {
            $db->beginTransaction();

            $orderStmt = $db->prepare("
                INSERT INTO orders (
                    order_number, customer_id, customer_name, customer_email, customer_phone, delivery_type,
                    address, city, state, pincode, notes, subtotal, tax_amount,
                    shipping_fee, discount_amount, total_amount, payment_method, payment_status,
                    order_status
                ) VALUES (
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?, ?,
                    ?, 0.00, ?, ?, ?,
                    ?
                )
            ");

            $orderStmt->execute([
                $orderNumber, $customerId, $customerName, $customerEmail, $customerPhone, $deliveryType,
                $address, $city, $state, $pincode, $notes, $subtotal, $taxAmount,
                $shippingFee, $grandTotal, $paymentMethod, $paymentStatus,
                $orderStatus
            ]);

            $orderId = (int)$db->lastInsertId();

            $itemStmt = $db->prepare("
                INSERT INTO order_items (
                    order_id, product_id, product_name, product_image, pricing_type, unit_price,
                    quantity, width, height, total_sqft, material_selected, finish_selected,
                    item_total, custom_notes
                ) VALUES (
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?,
                    ?, ?
                )
            ");

            foreach ($cart as $item) {
                $itemStmt->execute([
                    $orderId,
                    $item['product_id'],
                    $item['name'],
                    $item['image'],
                    $item['pricing_type'],
                    $item['unit_price'],
                    $item['quantity'],
                    $item['width'],
                    $item['height'],
                    $item['total_sqft'],
                    $item['material'],
                    $item['finish'],
                    $item['item_total'],
                    $item['custom_notes']
                ]);
            }

            $db->commit();

            // Clear session cart
            clearCart();

            // Redirect to success page
            header('Location: ' . BASE_URL . '/order-success.php?order=' . urlencode($orderNumber));
            exit;

        } catch (Exception $e) {
            $db->rollBack();
            $error = 'Failed to place order: ' . $e->getMessage();
        }
    }
}

include __DIR__ . '/includes/header.php';
?>

<!-- Checkout Header Banner -->
<div style="background: linear-gradient(135deg, #140E36 0%, #1A1344 60%, #342784 100%); color: #ffffff; padding: 48px 0;">
  <div class="container">
    <h1 style="font-size: 2rem; font-weight: 800; margin: 0;">Checkout &amp; Confirmation</h1>
    <p style="color: #94a3b8; margin-top: 6px; font-size: 0.95rem;">
      Provide your delivery details and choose your preferred payment method
    </p>
  </div>
</div>

<div class="section-padding" style="background-color: #f8fafc;">
  <div class="container">
    <?php if (!empty($error)): ?>
      <div style="background: #fee2e2; border-left: 4px solid var(--danger); padding: 16px 20px; border-radius: var(--radius-sm); margin-bottom: 24px; color: #b91c1c; font-weight: 600;">
        <i class="fas fa-exclamation-circle me-2"></i> <?= htmlspecialchars($error) ?>
      </div>
    <?php endif; ?>

    <form action="" method="POST" id="checkoutForm">
      <div class="resp-grid-main-side">
        
        <!-- Left: Customer Details & Shipping -->
        <div class="resp-card" style="background: #ffffff; border: 1px solid var(--border-color); box-shadow: var(--shadow-sm);">
          
          <!-- Contact Info -->
          <h3 style="font-size: 1.2rem; font-weight: 800; color: var(--secondary); margin-bottom: 18px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-user-circle text-primary"></i> 1. Contact Information
          </h3>

          <div class="form-row">
            <div class="form-group">
              <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Full Name / Company Name *</label>
              <input type="text" name="customer_name" class="form-control" placeholder="e.g. Rahul Sharma" required value="<?= htmlspecialchars($_POST['customer_name'] ?? '') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
            </div>
            <div class="form-group">
              <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Phone / WhatsApp Mobile *</label>
              <input type="tel" name="customer_phone" class="form-control" placeholder="e.g. 98480 12345" required value="<?= htmlspecialchars($_POST['customer_phone'] ?? '') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
            </div>
          </div>

          <div class="form-group">
            <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Email Address (For Order Updates &amp; Invoice) *</label>
            <input type="email" name="customer_email" class="form-control" placeholder="e.g. rahul@example.com" required value="<?= htmlspecialchars($_POST['customer_email'] ?? '') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
          </div>

          <!-- Delivery Mode -->
          <h3 style="font-size: 1.2rem; font-weight: 800; color: var(--secondary); margin: 30px 0 18px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-truck text-primary"></i> 2. Delivery or Store Pickup
          </h3>

          <div class="form-grid-2" style="margin-bottom: 20px;">
            <label style="display: flex; gap: 12px; align-items: center; padding: 16px; border: 2px solid var(--primary); border-radius: var(--radius-md); background: #eff6ff; cursor: pointer;">
              <input type="radio" name="delivery_type" value="delivery" checked onchange="toggleDeliveryFields(true)" style="accent-color: var(--primary); transform: scale(1.2);">
              <div>
                <strong style="color: var(--secondary); font-size: 0.95rem; display: block;">Doorstep Delivery</strong>
                <span style="font-size: 0.78rem; color: var(--text-muted);">Direct courier/van delivery to your address</span>
              </div>
            </label>

            <label style="display: flex; gap: 12px; align-items: center; padding: 16px; border: 1.5px solid var(--border-color); border-radius: var(--radius-md); background: #f8fafc; cursor: pointer;">
              <input type="radio" name="delivery_type" value="pickup" onchange="toggleDeliveryFields(false)" style="accent-color: var(--primary); transform: scale(1.2);">
              <div>
                <strong style="color: var(--secondary); font-size: 0.95rem; display: block;">Self Pickup (Free)</strong>
                <span style="font-size: 0.78rem; color: var(--text-muted);">Madhuban Plaza, S.D. Road Secunderabad</span>
              </div>
            </label>
          </div>

          <!-- In-Store Pickup Details Box -->
          <div id="storePickupInfoBox" style="display: none; background: #eef0fa; border: 1.5px solid #c7d2fe; border-radius: var(--radius-md); padding: 18px 20px; margin-bottom: 20px;">
            <div style="display: flex; gap: 12px; align-items: flex-start;">
              <i class="fas fa-store" style="color: var(--primary); font-size: 1.25rem; margin-top: 2px;"></i>
              <div style="flex: 1;">
                <strong style="color: var(--secondary); font-size: 0.95rem; display: block; margin-bottom: 4px;">Collect From Workshop:</strong>
                <p style="font-size: 0.88rem; color: var(--secondary); margin: 0; line-height: 1.5;">
                  <strong>Sai Manga Digital</strong><br>
                  Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, Beside Manyavar Showroom, S.D. Road, Secunderabad - 500003
                </p>
                <div style="margin-top: 6px; font-size: 0.8rem; color: #15803d; font-weight: 700;">
                  <i class="fas fa-clock me-1"></i> Ready for pickup within business hours (Mon-Sat 9:30 AM – 9:00 PM)
                </div>
                <div style="margin-top: 10px;">
                  <a href="https://maps.app.goo.gl/cNSaRii6R44K9t4c8" target="_blank" class="btn btn-sm btn-maps" style="font-size: 0.8rem; padding: 4px 12px;">
                    <i class="fab fa-google"></i> View Location on Google Maps
                  </a>
                </div>
              </div>
            </div>
          </div>

          <!-- Address Fields -->
          <div id="deliveryFieldsContainer">
            <div class="form-group">
              <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Street Address / Building / Landmark *</label>
              <textarea name="address" id="addressInput" rows="2" class="form-control" placeholder="House/Shop No, Street, Landmark" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
            </div>

            <div class="form-row">
              <div class="form-group">
                <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">City *</label>
                <input type="text" name="city" class="form-control" value="Secunderabad" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
              </div>
              <div class="form-group">
                <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">State *</label>
                <input type="text" name="state" class="form-control" value="Telangana" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
              </div>
            </div>

            <div class="form-group">
              <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Pincode *</label>
              <input type="text" name="pincode" id="pincodeInput" class="form-control" placeholder="e.g. 500003" value="<?= htmlspecialchars($_POST['pincode'] ?? '') ?>" style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);">
            </div>
          </div>

          <!-- Special Production Notes -->
          <div class="form-group" style="margin-top: 20px;">
            <label class="form-label" style="color: var(--secondary); font-size: 0.85rem;">Special Instructions for Production / Dispatch</label>
            <textarea name="notes" rows="2" class="form-control" placeholder="Any special packaging, dispatch deadline, or site mounting notes." style="background: #ffffff; color: var(--secondary); border: 1.5px solid var(--border-color);"><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
          </div>

          <!-- Payment Selection -->
          <h3 style="font-size: 1.2rem; font-weight: 800; color: var(--secondary); margin: 30px 0 18px; padding-bottom: 10px; border-bottom: 1px solid var(--border-color); display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-credit-card text-primary"></i> 3. Payment Method
          </h3>

          <div style="display: flex; flex-direction: column; gap: 12px;">
            <label style="display: flex; gap: 14px; align-items: center; padding: 16px; border: 1.5px solid var(--border-color); border-radius: var(--radius-md); background: #ffffff; cursor: pointer;">
              <input type="radio" name="payment_method" value="upi" checked style="accent-color: var(--primary); transform: scale(1.2);">
              <div style="flex: 1;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                  <strong style="color: var(--secondary); font-size: 0.95rem;">Instant UPI / QR Code (Google Pay, PhonePe, Paytm)</strong>
                  <span class="badge bg-success" style="font-size: 0.72rem;">Recommended</span>
                </div>
                <span style="font-size: 0.8rem; color: var(--text-muted);">Scan QR code to pay instantly from any UPI mobile app</span>
              </div>
            </label>

            <label style="display: flex; gap: 14px; align-items: center; padding: 16px; border: 1.5px solid var(--border-color); border-radius: var(--radius-md); background: #ffffff; cursor: pointer;">
              <input type="radio" name="payment_method" value="cod" style="accent-color: var(--primary); transform: scale(1.2);">
              <div>
                <strong style="color: var(--secondary); font-size: 0.95rem; display: block;">Cash on Delivery (COD) / Pay upon In-Store Collection</strong>
                <span style="font-size: 0.8rem; color: var(--text-muted);">Pay cash or UPI upon delivery or during pickup at our Secunderabad store</span>
              </div>
            </label>
          </div>

        </div>

        <!-- Right: Order Review Summary -->
        <div class="resp-card" style="background: #ffffff; border: 1px solid var(--border-color); box-shadow: var(--shadow-sm); position: sticky; top: 100px;">
          <h3 style="font-size: 1.2rem; font-weight: 800; color: var(--secondary); margin-bottom: 20px; padding-bottom: 12px; border-bottom: 1px solid var(--border-color);">
            Order Items (<?= count($cart) ?>)
          </h3>

          <div style="display: flex; flex-direction: column; gap: 14px; max-height: 280px; overflow-y: auto; padding-right: 6px; margin-bottom: 20px;">
            <?php foreach ($cart as $item): ?>
            <div style="display: flex; justify-content: space-between; gap: 12px; font-size: 0.88rem; padding-bottom: 12px; border-bottom: 1px solid var(--border-light);">
              <div>
                <strong style="color: var(--secondary);"><?= htmlspecialchars($item['name']) ?></strong>
                <div style="font-size: 0.78rem; color: var(--text-muted);">
                  Qty: <?= $item['quantity'] ?> 
                  <?= ($item['pricing_type'] === 'per_sqft') ? ' • ' . $item['width'] . 'x' . $item['height'] . 'ft' : '' ?>
                </div>
              </div>
              <strong style="color: var(--secondary); white-space: nowrap;"><?= formatPrice($item['item_total']) ?></strong>
            </div>
            <?php endforeach; ?>
          </div>

          <div style="display: flex; flex-direction: column; gap: 12px; font-size: 0.92rem; margin-bottom: 24px; padding-top: 14px; border-top: 1px solid var(--border-color);">
            <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
              <span>Subtotal</span>
              <strong style="color: var(--secondary);"><?= formatPrice($totals['subtotal']) ?></strong>
            </div>

            <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
              <span>GST (<?= $totals['tax_percent'] ?>%)</span>
              <strong style="color: var(--secondary);"><?= formatPrice($totals['tax']) ?></strong>
            </div>

            <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
              <span>Delivery Fee</span>
              <strong id="shippingDisplay" style="color: var(--secondary);">
                <?= $totals['shipping'] == 0 ? '<span class="badge bg-success">FREE</span>' : formatPrice($totals['shipping']) ?>
              </strong>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: baseline; padding-top: 14px; border-top: 2px dashed var(--border-color); font-size: 1.15rem; color: var(--secondary);">
              <strong>Total to Pay</strong>
              <strong style="font-size: 1.7rem; color: var(--primary);"><?= formatPrice($totals['grand_total']) ?></strong>
            </div>
          </div>

          <button type="submit" name="place_order" class="btn btn-primary btn-lg" style="width: 100%; justify-content: center; font-size: 1.1rem; padding: 14px;">
            <i class="fas fa-lock me-2"></i> Confirm &amp; Place Order
          </button>

          <p style="text-align: center; font-size: 0.78rem; color: var(--text-muted); margin-top: 14px;">
            By placing this order, you will receive real-time production updates via SMS/Email and WhatsApp from Sai Manga Digital.
          </p>
        </div>

      </div>
    </form>
  </div>
</div>

<script>
function toggleDeliveryFields(isDelivery) {
    const container = document.getElementById('deliveryFieldsContainer');
    const pickupBox = document.getElementById('storePickupInfoBox');
    const address = document.getElementById('addressInput');
    const pincode = document.getElementById('pincodeInput');
    const shippingDisplay = document.getElementById('shippingDisplay');

    if (isDelivery) {
        container.style.display = 'block';
        if (pickupBox) pickupBox.style.display = 'none';
        address.setAttribute('required', 'required');
        pincode.setAttribute('required', 'required');
        shippingDisplay.innerHTML = '<?= $totals['shipping'] == 0 ? '<span class="badge bg-success">FREE</span>' : formatPrice($totals['shipping']) ?>';
    } else {
        container.style.display = 'none';
        if (pickupBox) pickupBox.style.display = 'block';
        address.removeAttribute('required');
        pincode.removeAttribute('required');
        shippingDisplay.innerHTML = '<span class="badge bg-success">Store Pickup (FREE)</span>';
    }
}
</script>

<?php include __DIR__ . '/includes/footer.php'; ?>

