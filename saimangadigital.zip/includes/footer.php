<?php
$siteName = getSetting('site_name', 'Sai Manga Digital');
$phone = getSetting('phone', '+91 8047663573');
$mobile = getSetting('mobile', '+91 98490 12345');
$whatsapp = getSetting('whatsapp', '918047663573');
$email = getSetting('email', 'sales@saimangadigital.com');
$address = getSetting('address', 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, Beside Manyavar Showroom, S.D. Road, Secunderabad - 500003');
$instagram = getSetting('instagram', 'https://www.instagram.com/saimangadigital');
$mapsUrl = getSetting('google_maps_url', 'https://maps.app.goo.gl/cNSaRii6R44K9t4c8');
$proprietor = getSetting('proprietor', 'Marri Prasad Naidu');
$hours = getSetting('business_hours', 'Monday - Saturday: 9:30 AM to 9:00 PM (Sunday Closed)');
$rating = getSetting('google_rating', '4.8');
$reviewsCount = getSetting('google_reviews_count', '68');
?>

<!-- Minimalist Dark Footer (Matching Reference Design) -->
<footer class="site-footer-minimal">
  <div class="container">
    <div class="footer-top-row">
      <!-- White Brand Logo -->
      <a href="<?= BASE_URL ?>/index.php" class="footer-logo">
        <img src="<?= BASE_URL ?>/assets/images/logo-light.svg" alt="Sai Manga Digital">
      </a>

      <!-- Clean Horizontal Primary Links -->
      <ul class="footer-nav-inline">
        <li><a href="<?= BASE_URL ?>/index.php">Home</a></li>
        <li><a href="<?= BASE_URL ?>/shop.php">Shop</a></li>
        <li><a href="<?= BASE_URL ?>/calculator.php">Estimator</a></li>
        <li><a href="<?= BASE_URL ?>/portfolio.php">Gallery</a></li>
        <li><a href="<?= BASE_URL ?>/file-guidelines.php">Artwork Guide</a></li>
        <li><a href="<?= BASE_URL ?>/faq.php">FAQ</a></li>
        <li><a href="<?= BASE_URL ?>/about.php">About</a></li>
        <li><a href="<?= BASE_URL ?>/contact.php">Contact</a></li>
      </ul>
    </div>

    <!-- Secondary Customer & Legal Policies Row -->
    <div class="footer-secondary-row" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px; padding: 22px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.08);">
      <ul class="footer-nav-inline" style="font-size: 0.82rem; gap: 16px 22px; justify-content: center;">
        <li><a href="<?= BASE_URL ?>/account.php" style="color: #999999;"><i class="fas fa-user-circle me-1"></i> My Account</a></li>
        <li><a href="<?= BASE_URL ?>/wishlist.php" style="color: #999999;"><i class="fas fa-heart me-1"></i> Wishlist</a></li>
        <li><a href="<?= BASE_URL ?>/track-order.php" style="color: #999999;"><i class="fas fa-search-location me-1"></i> Track Order</a></li>
        <li><a href="<?= BASE_URL ?>/shipping-policy.php" style="color: #999999;">Shipping Policy</a></li>
        <li><a href="<?= BASE_URL ?>/refund-policy.php" style="color: #999999;">Refund &amp; Warranty</a></li>
        <li><a href="<?= BASE_URL ?>/privacy-policy.php" style="color: #999999;">Privacy Policy</a></li>
        <li><a href="<?= BASE_URL ?>/terms-conditions.php" style="color: #999999;">Terms of Service</a></li>
      </ul>

      <!-- Social & Verified Badges -->
      <div style="display: flex; align-items: center; gap: 18px; font-size: 0.88rem; flex-wrap: wrap; justify-content: center;">
        <a href="<?= htmlspecialchars($instagram) ?>" target="_blank" rel="noopener" style="color: #E1306C; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 6px;">
          <i class="fab fa-instagram" style="font-size: 1.1rem;"></i> @saimangadigital
        </a>
        <a href="<?= htmlspecialchars($mapsUrl) ?>" target="_blank" rel="noopener" style="color: #4285F4; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 6px;">
          <i class="fab fa-google" style="font-size: 1.1rem;"></i> <?= htmlspecialchars($rating) ?> &#9733; Google Maps (<?= htmlspecialchars($reviewsCount) ?>+ Reviews)
        </a>
      </div>
    </div>

    <!-- Bottom Metadata Row -->
    <div class="footer-bottom-row">
      <div>
        &copy; <?= date('Y') ?> <strong>Sai Manga Digital</strong>. Established 1994 by <?= htmlspecialchars($proprietor) ?>. All rights reserved.
      </div>
      <div>
        Flagship Studio &amp; Factory: Madhuban Plaza, S.D. Road, Secunderabad, Telangana - 500003 &bull; Direct Desk: <?= htmlspecialchars($phone) ?>
      </div>
    </div>
  </div>
</footer>

<!-- Toast Notifications Container -->
<div id="toastContainer" style="position: fixed; bottom: 24px; right: 24px; z-index: 99999; display: flex; flex-direction: column; gap: 10px;"></div>

<!-- Core Main Javascript -->
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>

</body>
</html>
