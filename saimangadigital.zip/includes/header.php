<?php
if (!defined('APP_ROOT')) {
    require_once dirname(__DIR__) . '/config/init.php';
}

$pageTitle = $pageTitle ?? getSetting('site_name', 'Sai Manga Digital') . ' | 3D Signage & Large-Format Printing';
$cartCount = getCartCount();
$wishlistCount = getWishlistCount();
$isCustomer = isCustomerLoggedIn();
$customer = getCustomerUser();

$phone = getSetting('phone', '+91 8047663573');
$mobile = getSetting('mobile', '+91 98490 12345');
$whatsapp = getSetting('whatsapp', '918047663573');
$address = getSetting('address', 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, S.D. Road, Secunderabad - 500003');
$instagram = getSetting('instagram', 'https://www.instagram.com/saimangadigital');
$mapsUrl = getSetting('google_maps_url', 'https://maps.app.goo.gl/cNSaRii6R44K9t4c8');
$rating = getSetting('google_rating', '4.8');
$reviewsCount = getSetting('google_reviews_count', '68');
$flash = getFlash();
$currentScript = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle) ?></title>
  <meta name="description" content="Sai Manga Digital - Hyderabad & Secunderabad's premier architectural 3D LED letters, neon art, rollup standees, and large format printing enterprise since 1994.">

  <!-- Favicons -->
  <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/favicon.png">
  <link rel="shortcut icon" href="<?= BASE_URL ?>/assets/images/favicon.ico">
  <link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>/assets/images/logo.svg">

  <!-- Google Fonts: Outfit & Plus Jakarta Sans -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- Font Awesome 6 Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

  <!-- Next-Gen Minimalist 3D Studio Stylesheet -->
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<?php if ($flash): ?>
  <div id="phpFlashMessage" data-message="<?= htmlspecialchars($flash['message']) ?>" data-type="<?= htmlspecialchars($flash['type']) ?>" style="display:none;"></div>
<?php endif; ?>

<!-- Top Minimalist Info Strip -->
<div class="top-minimal-bar">
  <div class="container">
    <div style="display: flex; align-items: center; gap: 14px; flex-wrap: wrap; justify-content: center;">
      <span class="top-bar-desktop-only" style="display: inline-flex; align-items: center; gap: 6px;">
        <span style="width: 7px; height: 7px; border-radius: 50%; background-color: #10B981; display: inline-block;"></span>
        Workshop Active • Mon – Sat: 9:30 AM – 9:00 PM
      </span>
      <span class="top-bar-desktop-only" style="opacity: 0.4;">|</span>
      <a href="<?= htmlspecialchars($mapsUrl) ?>" target="_blank" style="font-weight: 600; color: #111111; display: inline-flex; align-items: center; gap: 4px;">
        <i class="fab fa-google" style="color: #4285F4;"></i> <?= htmlspecialchars($rating) ?> ★ Google Verified (<?= htmlspecialchars($reviewsCount) ?>+ Reviews)
      </a>
    </div>

    <div style="display: flex; align-items: center; gap: 16px; flex-wrap: wrap; justify-content: center;">
      <a href="tel:<?= preg_replace('/[^0-9+]/', '', $phone) ?>" style="font-weight: 600;">
        <i class="fas fa-phone-alt" style="font-size: 0.75rem; margin-right: 4px;"></i> <?= htmlspecialchars($phone) ?>
      </a>
      <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsapp) ?>?text=Hello%20Sai%20Manga%20Digital,%20I%20have%20an%20enquiry" target="_blank" style="font-weight: 600; color: #059669;">
        <i class="fab fa-whatsapp" style="margin-right: 4px;"></i> WhatsApp Desk
      </a>
      <a href="<?= htmlspecialchars($instagram) ?>" target="_blank" class="top-bar-desktop-only" style="color: #E1306C; font-weight: 700;">
        <i class="fab fa-instagram" style="margin-right: 4px;"></i> @saimangadigital
      </a>
      <a href="<?= BASE_URL ?>/track-order.php" class="top-bar-desktop-only">
        <i class="fas fa-truck" style="font-size: 0.75rem; margin-right: 4px;"></i> Track Order
      </a>
      <?php if ($isCustomer): ?>
        <a href="<?= BASE_URL ?>/account.php" style="color: var(--brand-blue); font-weight: 700;">
          <i class="fas fa-user-circle"></i> <?= htmlspecialchars(explode(' ', $customer['name'])[0]) ?>
        </a>
        <a href="<?= BASE_URL ?>/logout.php" class="top-bar-desktop-only" style="opacity: 0.6; font-size: 0.75rem;">Sign Out</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/login.php" class="top-bar-desktop-only" style="font-weight: 700; color: #111111;">
          <i class="fas fa-user" style="font-size: 0.75rem; margin-right: 4px;"></i> Login / Register
        </a>
      <?php endif; ?>
      <a href="<?= BASE_URL ?>/admin/index.php" class="top-bar-desktop-only" style="opacity: 0.5;">
        <i class="fas fa-lock" style="font-size: 0.7rem;"></i>
      </a>
    </div>
  </div>
</div>

<!-- Master Minimalist Header -->
<header class="site-header">
  <div class="container">
    <nav class="site-navbar">
      <!-- Left: Logo -->
      <a href="<?= BASE_URL ?>/index.php" class="navbar-brand" title="Sai Manga Digital - Since 1994">
        <img src="<?= BASE_URL ?>/assets/images/logo.svg" alt="Sai Manga Digital Logo">
      </a>

      <!-- Center: Clean Navigation Links -->
      <ul class="navbar-nav">
        <li>
          <a href="<?= BASE_URL ?>/index.php" class="nav-link <?= $currentScript === 'index.php' ? 'active' : '' ?>">Home</a>
        </li>
        <li>
          <a href="<?= BASE_URL ?>/shop.php" class="nav-link <?= $currentScript === 'shop.php' ? 'active' : '' ?>">Shop</a>
        </li>
        <li>
          <a href="<?= BASE_URL ?>/calculator.php" class="nav-link <?= $currentScript === 'calculator.php' ? 'active' : '' ?>">Estimator</a>
        </li>
        <li>
          <a href="<?= BASE_URL ?>/portfolio.php" class="nav-link <?= $currentScript === 'portfolio.php' ? 'active' : '' ?>">Gallery</a>
        </li>
        <li>
          <a href="<?= BASE_URL ?>/faq.php" class="nav-link <?= $currentScript === 'faq.php' ? 'active' : '' ?>">FAQ</a>
        </li>
        <li>
          <a href="<?= BASE_URL ?>/about.php" class="nav-link <?= $currentScript === 'about.php' ? 'active' : '' ?>">About</a>
        </li>
        <li>
          <a href="<?= BASE_URL ?>/contact.php" class="nav-link <?= $currentScript === 'contact.php' ? 'active' : '' ?>">Contact</a>
        </li>
      </ul>

      <!-- Right: Search, Wishlist, Cart, Account, CTA & Mobile Menu -->
      <div class="nav-actions">
        <!-- Search Trigger Icon -->
        <button type="button" class="nav-icon-btn" id="searchToggleBtn" aria-label="Search Catalog" title="Search">
          <i class="fas fa-search"></i>
        </button>

        <!-- Wishlist Icon with Dynamic Badge -->
        <a href="<?= BASE_URL ?>/wishlist.php" class="nav-icon-btn" title="View Wishlist">
          <i class="far fa-heart"></i>
          <?php if ($wishlistCount > 0): ?>
            <span class="cart-pill-badge" style="background: var(--brand-blue);"><?= $wishlistCount ?></span>
          <?php endif; ?>
        </a>

        <!-- Shopping Cart Icon with Badge -->
        <a href="<?= BASE_URL ?>/cart.php" class="nav-icon-btn" title="View Cart">
          <i class="fas fa-shopping-bag"></i>
          <?php if ($cartCount > 0): ?>
            <span class="cart-pill-badge" id="cartCountBadge"><?= $cartCount ?></span>
          <?php endif; ?>
        </a>

        <!-- Account / Sign In Icon -->
        <a href="<?= $isCustomer ? BASE_URL . '/account.php' : BASE_URL . '/login.php' ?>" class="nav-icon-btn" title="<?= $isCustomer ? 'My Account (' . htmlspecialchars($customer['name']) . ')' : 'Customer Sign In' ?>">
          <i class="fas fa-user<?= $isCustomer ? '-check' : '' ?>"></i>
        </a>

        <!-- Header CTA Button -->
        <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-primary pill-btn-sm" style="display: none; @media(min-width: 992px){ display: inline-flex; }">
          Shop Now
        </a>

        <!-- Mobile Drawer Toggle -->
        <button type="button" class="mobile-toggle" id="mobileMenuToggleBtn" aria-label="Toggle Menu">
          <i class="fas fa-bars"></i>
        </button>
      </div>
    </nav>
  </div>

  <!-- Expandable Live Search Modal Bar -->
  <div class="search-modal-bar" id="searchModalBar">
    <div class="container">
      <form action="<?= BASE_URL ?>/shop.php" method="GET" class="search-pill-wrapper">
        <input type="text" name="search" class="search-pill-input" placeholder="Search 3D LED letters, standees, flex printing..." autofocus>
        <button type="submit" class="search-pill-submit" aria-label="Submit Search">
          <i class="fas fa-arrow-right"></i>
        </button>
      </form>
    </div>
  </div>
</header>

<!-- Mobile Navigation Drawer Overlay -->
<div id="mobileDrawerOverlay" style="display: none; position: fixed; inset: 0; background: rgba(0, 0, 0, 0.6); backdrop-filter: blur(4px); z-index: 998; touch-action: none;"></div>
<div id="mobileNavDrawer" style="position: fixed; top: 0; right: -350px; width: min(300px, 86vw); height: 100%; background: #FFFFFF; z-index: 999; padding: 24px 20px; box-shadow: -10px 0 30px rgba(0,0,0,0.15); transition: right 0.3s cubic-bezier(0.16, 1, 0.3, 1); display: flex; flex-direction: column; justify-content: space-between; overflow-y: auto; -webkit-overflow-scrolling: touch;">
  <div>
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 16px; border-bottom: 1px solid #ECEFF2;">
      <img src="<?= BASE_URL ?>/assets/images/logo.svg" alt="Sai Manga Digital" style="height: 34px; width: auto;">
      <button type="button" id="closeMobileDrawer" style="background: none; border: none; color: #111111; font-size: 1.3rem; cursor: pointer; padding: 6px;">
        <i class="fas fa-times"></i>
      </button>
    </div>

    <!-- Mobile Search -->
    <form action="<?= BASE_URL ?>/shop.php" method="GET" style="margin-bottom: 20px;">
      <div style="position: relative;">
        <input type="text" name="search" placeholder="Search products..." style="width: 100%; height: 42px; border-radius: 999px; background: #F7F8FA; border: 1.5px solid #D0D5DD; color: #111111; padding: 0 42px 0 16px; font-size: 0.9rem;">
        <button type="submit" style="position: absolute; right: 5px; top: 5px; width: 32px; height: 32px; border-radius: 50%; background: var(--brand-blue); border: none; color: #FFFFFF; cursor: pointer;">
          <i class="fas fa-search" style="font-size: 0.75rem;"></i>
        </button>
      </div>
    </form>

    <ul style="list-style: none; display: flex; flex-direction: column; gap: 4px;">
      <li><a href="<?= BASE_URL ?>/index.php" style="color: #111111; font-weight: 700; padding: 8px 12px; border-radius: 8px; display: block;">Home</a></li>
      <li><a href="<?= BASE_URL ?>/shop.php" style="color: #333333; font-weight: 600; padding: 8px 12px; border-radius: 8px; display: block;">Shop Catalog</a></li>
      <li><a href="<?= BASE_URL ?>/calculator.php" style="color: var(--brand-blue); font-weight: 700; padding: 8px 12px; border-radius: 8px; display: flex; align-items: center; gap: 8px; background: #E8F1FC;"><i class="fas fa-calculator"></i> Sqrft Price Estimator</a></li>
      <li><a href="<?= BASE_URL ?>/portfolio.php" style="color: #333333; font-weight: 600; padding: 8px 12px; border-radius: 8px; display: block;">Installation Gallery</a></li>
      <li><a href="<?= BASE_URL ?>/wishlist.php" style="color: #333333; font-weight: 600; padding: 8px 12px; border-radius: 8px; display: flex; align-items: center; justify-content: space-between;"><span>My Wishlist</span> <?php if ($wishlistCount > 0): ?><span style="background: var(--brand-blue); color: #fff; font-size: 0.7rem; font-weight: 800; padding: 2px 8px; border-radius: 999px;"><?= $wishlistCount ?></span><?php endif; ?></a></li>
      <li><a href="<?= BASE_URL ?>/faq.php" style="color: #333333; font-weight: 600; padding: 8px 12px; border-radius: 8px; display: block;">Frequently Asked Questions</a></li>
      <li><a href="<?= BASE_URL ?>/file-guidelines.php" style="color: #333333; font-weight: 600; padding: 8px 12px; border-radius: 8px; display: block;">Artwork Guidelines</a></li>
      <li><a href="<?= BASE_URL ?>/about.php" style="color: #333333; font-weight: 600; padding: 8px 12px; border-radius: 8px; display: block;">About Us</a></li>
      <li><a href="<?= BASE_URL ?>/contact.php" style="color: #333333; font-weight: 600; padding: 8px 12px; border-radius: 8px; display: block;">Contact &amp; Maps</a></li>
      <li><a href="<?= BASE_URL ?>/track-order.php" style="color: #555555; font-weight: 600; padding: 8px 12px; border-radius: 8px; display: block;"><i class="fas fa-truck me-2"></i> Track Order</a></li>
      <?php if ($isCustomer): ?>
        <li><a href="<?= BASE_URL ?>/account.php" style="color: #10B981; font-weight: 700; padding: 8px 12px; border-radius: 8px; display: block;"><i class="fas fa-user-circle me-2"></i> My Account (<?= htmlspecialchars($customer['name']) ?>)</a></li>
        <li><a href="<?= BASE_URL ?>/logout.php" style="color: var(--brand-red); font-weight: 600; padding: 8px 12px; border-radius: 8px; display: block;"><i class="fas fa-sign-out-alt me-2"></i> Sign Out</a></li>
      <?php else: ?>
        <li><a href="<?= BASE_URL ?>/login.php" style="color: var(--brand-blue); font-weight: 700; padding: 8px 12px; border-radius: 8px; display: block;"><i class="fas fa-user me-2"></i> Sign In / Register</a></li>
      <?php endif; ?>
    </ul>
  </div>

  <div style="border-top: 1px solid #ECEFF2; padding-top: 16px; margin-top: 16px;">
    <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsapp) ?>?text=Hi%20Sai%20Manga%20Digital" target="_blank" class="pill-btn pill-btn-primary" style="width: 100%; margin-bottom: 8px; justify-content: center;">
      <i class="fab fa-whatsapp me-2"></i> WhatsApp Order Desk
    </a>
    <a href="<?= htmlspecialchars($mapsUrl) ?>" target="_blank" class="pill-btn pill-btn-outline" style="width: 100%; font-size: 0.78rem; justify-content: center;">
      <i class="fab fa-google"></i> Google Maps Directions
    </a>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Search toggle
    const searchBtn = document.getElementById('searchToggleBtn');
    const searchModal = document.getElementById('searchModalBar');
    if (searchBtn && searchModal) {
        searchBtn.addEventListener('click', () => {
            searchModal.classList.toggle('active');
            if (searchModal.classList.contains('active')) {
                const inp = searchModal.querySelector('input');
                if (inp) inp.focus();
            }
        });
    }

    // Mobile drawer toggle
    const toggleBtn = document.getElementById('mobileMenuToggleBtn');
    const closeBtn = document.getElementById('closeMobileDrawer');
    const drawer = document.getElementById('mobileNavDrawer');
    const overlay = document.getElementById('mobileDrawerOverlay');

    function openMenu() {
        if (drawer && overlay) {
            overlay.style.display = 'block';
            document.body.style.overflow = 'hidden';
            setTimeout(() => { drawer.style.right = '0'; }, 10);
        }
    }

    function closeMenu() {
        if (drawer && overlay) {
            drawer.style.right = '-350px';
            document.body.style.overflow = '';
            setTimeout(() => { overlay.style.display = 'none'; }, 300);
        }
    }

    if (toggleBtn) toggleBtn.addEventListener('click', openMenu);
    if (closeBtn) closeBtn.addEventListener('click', closeMenu);
    if (overlay) overlay.addEventListener('click', closeMenu);
});
</script>
