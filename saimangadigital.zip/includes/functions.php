<?php
/**
 * Sai Manga Digital - Global Helper Functions
 */

/**
 * Fetch all store settings from database
 */
function getSettings(): array {
    static $settings = null;
    if ($settings !== null) {
        return $settings;
    }

    try {
        $pdo = Database::getConnection();
        $stmt = $pdo->query("SELECT key_name, value FROM settings");
        $results = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
        $settings = $results ?: [];
    } catch (Exception $e) {
        $settings = [];
    }

    return $settings;
}

/**
 * Get individual setting with fallback
 */
function getSetting(string $key, string $default = ''): string {
    $settings = getSettings();
    return $settings[$key] ?? $default;
}

/**
 * Format currency price
 */
function formatPrice(float|int|string $amount): string {
    $num = (float)$amount;
    $symbol = getSetting('currency_symbol', '₹');
    return $symbol . ' ' . number_format($num, 2);
}

/**
 * Sanitize user input
 */
function sanitize(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Get Cart from session
 */
function getCart(): array {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    return $_SESSION['cart'];
}

/**
 * Get count of items in cart
 */
function getCartCount(): int {
    $cart = getCart();
    $count = 0;
    foreach ($cart as $item) {
        $count += (int)($item['quantity'] ?? 1);
    }
    return $count;
}

/**
 * Compute Cart Totals (Subtotal, Tax, Shipping, Grand Total)
 */
function getCartTotals(): array {
    $cart = getCart();
    $subtotal = 0.00;

    foreach ($cart as $item) {
        $subtotal += (float)($item['item_total'] ?? 0.00);
    }

    $freeShippingMin = (float)getSetting('free_shipping_threshold', '2999');
    $shippingFeeSetting = (float)getSetting('shipping_flat_fee', '150');
    $shippingFee = ($subtotal >= $freeShippingMin || $subtotal == 0) ? 0.00 : $shippingFeeSetting;

    $taxPercent = (float)getSetting('tax_rate_percent', '18');
    // GST 18% included or added (in standard Indian e-commerce, tax is calculated on subtotal)
    $tax = ($subtotal * $taxPercent) / 100;
    $grandTotal = $subtotal + $shippingFee + $tax;

    return [
        'subtotal' => $subtotal,
        'tax_percent' => $taxPercent,
        'tax' => $tax,
        'shipping' => $shippingFee,
        'free_shipping_threshold' => $freeShippingMin,
        'grand_total' => $grandTotal
    ];
}

/**
 * Add an item to the shopping cart
 */
function addToCart(array $data): string {
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Generate unique key based on product and customization parameters
    $cartKey = md5(
        ($data['product_id'] ?? 0) .
        ($data['width'] ?? '') .
        ($data['height'] ?? '') .
        ($data['material'] ?? '') .
        ($data['finish'] ?? '') .
        ($data['custom_notes'] ?? '')
    );

    $qty = max(1, (int)($data['quantity'] ?? 1));
    $unitPrice = (float)($data['unit_price'] ?? 0.00);
    $totalSqft = (float)($data['total_sqft'] ?? 0.00);
    $pricingType = $data['pricing_type'] ?? 'fixed';

    if ($pricingType === 'per_sqft' && $totalSqft > 0) {
        $itemTotal = $unitPrice * $totalSqft * $qty;
    } else {
        $itemTotal = $unitPrice * $qty;
    }

    if (isset($_SESSION['cart'][$cartKey])) {
        $_SESSION['cart'][$cartKey]['quantity'] += $qty;
        $_SESSION['cart'][$cartKey]['item_total'] = ($pricingType === 'per_sqft' && $totalSqft > 0)
            ? $unitPrice * $totalSqft * $_SESSION['cart'][$cartKey]['quantity']
            : $unitPrice * $_SESSION['cart'][$cartKey]['quantity'];
    } else {
        $_SESSION['cart'][$cartKey] = [
            'cart_key' => $cartKey,
            'product_id' => (int)($data['product_id'] ?? 0),
            'name' => $data['name'] ?? 'Custom Product',
            'image' => $data['image'] ?? '',
            'pricing_type' => $pricingType,
            'unit_price' => $unitPrice,
            'quantity' => $qty,
            'width' => (float)($data['width'] ?? 0.00),
            'height' => (float)($data['height'] ?? 0.00),
            'total_sqft' => $totalSqft,
            'material' => $data['material'] ?? 'Standard',
            'finish' => $data['finish'] ?? 'Standard',
            'custom_notes' => $data['custom_notes'] ?? '',
            'artwork_file' => $data['artwork_file'] ?? '',
            'item_total' => $itemTotal
        ];
    }

    return $cartKey;
}

/**
 * Remove an item from the cart
 */
function removeFromCart(string $cartKey): bool {
    if (isset($_SESSION['cart'][$cartKey])) {
        unset($_SESSION['cart'][$cartKey]);
        return true;
    }
    return false;
}

/**
 * Update quantity in cart
 */
function updateCartQuantity(string $cartKey, int $qty): bool {
    if (isset($_SESSION['cart'][$cartKey])) {
        if ($qty <= 0) {
            unset($_SESSION['cart'][$cartKey]);
            return true;
        }

        $item = &$_SESSION['cart'][$cartKey];
        $item['quantity'] = $qty;
        $unitPrice = (float)$item['unit_price'];
        $totalSqft = (float)($item['total_sqft'] ?? 0.00);

        if ($item['pricing_type'] === 'per_sqft' && $totalSqft > 0) {
            $item['item_total'] = $unitPrice * $totalSqft * $qty;
        } else {
            $item['item_total'] = $unitPrice * $qty;
        }

        return true;
    }
    return false;
}

/**
 * Clear the cart
 */
function clearCart(): void {
    $_SESSION['cart'] = [];
}

/**
 * Generate Unique Order Number
 */
function generateOrderNumber(): string {
    return 'SMD-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -4));
}

/**
 * Generate Unique Quote Number
 */
function generateQuoteNumber(): string {
    return 'SMD-Q-' . date('ym') . rand(1000, 9999);
}

/**
 * Check if admin is authenticated
 */
function isAdminLoggedIn(): bool {
    return !empty($_SESSION['admin_id']);
}

/**
 * Require admin authentication
 */
function requireAdminAuth(): void {
    if (!isAdminLoggedIn()) {
        header('Location: ' . BASE_URL . '/admin/login.php');
        exit;
    }
}

/**
 * Session Flash Message Helper
 */
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type, // 'success', 'danger', 'info', 'warning'
        'message' => $message
    ];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Order Status Color Badge
 */
function getOrderStatusBadge(string $status): string {
    $badges = [
        'pending' => '<span class="badge bg-warning text-dark"><i class="fas fa-clock me-1"></i> Pending</span>',
        'in_design' => '<span class="badge bg-info text-white"><i class="fas fa-palette me-1"></i> In Design</span>',
        'printing' => '<span class="badge bg-primary text-white"><i class="fas fa-print me-1"></i> Printing</span>',
        'ready' => '<span class="badge bg-purple text-white" style="background-color: #8b5cf6;"><i class="fas fa-check-circle me-1"></i> Ready for Dispatch</span>',
        'dispatched' => '<span class="badge bg-secondary text-white"><i class="fas fa-shipping-fast me-1"></i> Dispatched</span>',
        'delivered' => '<span class="badge bg-success text-white"><i class="fas fa-box-open me-1"></i> Delivered</span>',
        'cancelled' => '<span class="badge bg-danger text-white"><i class="fas fa-times me-1"></i> Cancelled</span>',
    ];

    return $badges[$status] ?? '<span class="badge bg-secondary">' . htmlspecialchars(ucfirst($status)) . '</span>';
}

/**
 * Payment Status Color Badge
 */
function getPaymentStatusBadge(string $status): string {
    $badges = [
        'paid' => '<span class="badge bg-success text-white"><i class="fas fa-check-circle me-1"></i> Paid</span>',
        'pending' => '<span class="badge bg-warning text-dark"><i class="fas fa-hourglass-half me-1"></i> Pending</span>',
        'failed' => '<span class="badge bg-danger text-white"><i class="fas fa-exclamation-triangle me-1"></i> Failed</span>',
    ];

    return $badges[$status] ?? '<span class="badge bg-secondary">' . htmlspecialchars(ucfirst($status)) . '</span>';
}

/**
 * Time ago formatting
 */
function timeAgo(string $datetime): string {
    $timestamp = strtotime($datetime);
    if (!$timestamp) return $datetime;

    $diff = time() - $timestamp;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return floor($diff / 60) . ' mins ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hours ago';
    if ($diff < 604800) return floor($diff / 86400) . ' days ago';
    return date('d M Y', $timestamp);
}

/**
 * Customer Authentication Helpers
 */
function isCustomerLoggedIn(): bool {
    return !empty($_SESSION['customer_id']);
}

function getCustomerId(): ?int {
    return $_SESSION['customer_id'] ?? null;
}

function getCustomerUser(): ?array {
    if (!isCustomerLoggedIn()) {
        return null;
    }
    static $customer = null;
    if ($customer !== null) {
        return $customer;
    }
    try {
        $pdo = Database::getConnection();
        $stmt = $pdo->prepare("SELECT id, name, email, phone, company, address, city, state, pincode, created_at FROM customers WHERE id = ?");
        $stmt->execute([$_SESSION['customer_id']]);
        $customer = $stmt->fetch() ?: null;
    } catch (Exception $e) {
        $customer = null;
    }
    return $customer;
}

function requireCustomerAuth(string $redirectUrl = ''): void {
    if (!isCustomerLoggedIn()) {
        $target = $redirectUrl ?: ($_SERVER['REQUEST_URI'] ?? '/account.php');
        header('Location: ' . BASE_URL . '/login.php?redirect=' . urlencode($target));
        exit;
    }
}

/**
 * Wishlist Helpers
 */
function getWishlist(): array {
    if (!isset($_SESSION['wishlist']) || !is_array($_SESSION['wishlist'])) {
        $_SESSION['wishlist'] = [];
    }
    return $_SESSION['wishlist'];
}

function getWishlistCount(): int {
    return count(getWishlist());
}

function isInWishlist(int $productId): bool {
    $wishlist = getWishlist();
    return in_array($productId, $wishlist, true);
}

function addToWishlist(int $productId): bool {
    if (!isset($_SESSION['wishlist'])) {
        $_SESSION['wishlist'] = [];
    }
    if (!in_array($productId, $_SESSION['wishlist'], true)) {
        $_SESSION['wishlist'][] = $productId;
        return true;
    }
    return false;
}

function removeFromWishlist(int $productId): bool {
    if (isset($_SESSION['wishlist'])) {
        $key = array_search($productId, $_SESSION['wishlist'], true);
        if ($key !== false) {
            unset($_SESSION['wishlist'][$key]);
            $_SESSION['wishlist'] = array_values($_SESSION['wishlist']);
            return true;
        }
    }
    return false;
}


