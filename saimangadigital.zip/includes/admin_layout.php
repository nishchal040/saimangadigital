<?php
if (!defined('APP_ROOT')) {
    require_once dirname(__DIR__) . '/config/init.php';
}
requireAdminAuth();

$activePage = $activePage ?? 'dashboard';
$adminName = $_SESSION['admin_name'] ?? 'Admin User';
$adminRole = $_SESSION['admin_role'] ?? 'Administrator';

// Get counts for sidebar badges
$pendingOrdersCount = (int)$db->query("SELECT COUNT(*) FROM orders WHERE order_status IN ('pending', 'in_design', 'printing')")->fetchColumn();
$newQuotesCount = (int)$db->query("SELECT COUNT(*) FROM quotes WHERE status = 'new'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle ?? 'Admin Dashboard') ?> | Sai Manga Digital Backoffice</title>
  
  <link rel="icon" type="image/png" href="<?= BASE_URL ?>/assets/images/favicon.png">
  <link rel="shortcut icon" href="<?= BASE_URL ?>/assets/images/favicon.ico">
  <link rel="icon" type="image/svg+xml" href="<?= BASE_URL ?>/assets/images/logo.svg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Plus+Jakarta+Sans:wght@600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
  
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
  <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/admin.css">
</head>
<body class="admin-body">

<!-- Admin Sidebar -->
<aside class="admin-sidebar">
  <div class="admin-sidebar-brand">
    <a href="<?= BASE_URL ?>/admin/index.php" style="display: flex; align-items: center; gap: 10px;">
      <img src="<?= BASE_URL ?>/assets/images/logo-light.svg" alt="Sai Manga Digital" style="height: 42px; width: auto; max-width: 200px; object-fit: contain;">
    </a>
  </div>

  <ul class="admin-sidebar-menu">
    <li class="admin-menu-heading">Main Navigation</li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/admin/index.php" class="admin-nav-link <?= $activePage === 'dashboard' ? 'active' : '' ?>">
        <i class="fas fa-chart-line"></i>
        <span>Dashboard</span>
      </a>
    </li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/admin/orders.php" class="admin-nav-link <?= $activePage === 'orders' ? 'active' : '' ?>">
        <i class="fas fa-shopping-bag"></i>
        <span>Orders</span>
        <?php if ($pendingOrdersCount > 0): ?>
          <span class="admin-nav-badge"><?= $pendingOrdersCount ?></span>
        <?php endif; ?>
      </a>
    </li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/admin/quotes.php" class="admin-nav-link <?= $activePage === 'quotes' ? 'active' : '' ?>">
        <i class="fas fa-file-invoice-dollar"></i>
        <span>Custom Quotes</span>
        <?php if ($newQuotesCount > 0): ?>
          <span class="admin-nav-badge"><?= $newQuotesCount ?></span>
        <?php endif; ?>
      </a>
    </li>

    <li class="admin-menu-heading">Store Catalog</li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/admin/products.php" class="admin-nav-link <?= $activePage === 'products' ? 'active' : '' ?>">
        <i class="fas fa-tags"></i>
        <span>Products</span>
      </a>
    </li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/admin/product-form.php" class="admin-nav-link <?= $activePage === 'product_add' ? 'active' : '' ?>">
        <i class="fas fa-plus-circle"></i>
        <span>Add New Product</span>
      </a>
    </li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/admin/categories.php" class="admin-nav-link <?= $activePage === 'categories' ? 'active' : '' ?>">
        <i class="fas fa-th-large"></i>
        <span>Categories</span>
      </a>
    </li>

    <li class="admin-menu-heading">System &amp; Settings</li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/admin/settings.php" class="admin-nav-link <?= $activePage === 'settings' ? 'active' : '' ?>">
        <i class="fas fa-sliders-h"></i>
        <span>Store Settings</span>
      </a>
    </li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/index.php" target="_blank" class="admin-nav-link">
        <i class="fas fa-external-link-alt"></i>
        <span>View Live Website</span>
      </a>
    </li>
    <li class="admin-nav-item">
      <a href="<?= BASE_URL ?>/admin/logout.php" class="admin-nav-link" style="color: #f87171;">
        <i class="fas fa-sign-out-alt"></i>
        <span>Logout</span>
      </a>
    </li>
  </ul>

  <!-- Admin User Profile Footer -->
  <div class="admin-user-profile">
    <div class="admin-user-avatar">
      <?= strtoupper(substr($adminName, 0, 1)) ?>
    </div>
    <div class="admin-user-meta">
      <div class="admin-user-name"><?= htmlspecialchars($adminName) ?></div>
      <div class="admin-user-role"><?= htmlspecialchars($adminRole) ?></div>
    </div>
  </div>
</aside>

<!-- Admin Main Content Wrapper -->
<div class="admin-main">
  <!-- Topbar -->
  <header class="admin-topbar">
    <div class="admin-topbar-left">
      <h1 class="admin-page-title"><?= htmlspecialchars($pageTitle ?? 'Dashboard') ?></h1>
    </div>
    <div class="admin-topbar-actions">
      <a href="<?= BASE_URL ?>/index.php" target="_blank" class="btn btn-outline btn-sm">
        <i class="fas fa-store me-1"></i> View Store
      </a>
      <a href="<?= BASE_URL ?>/admin/product-form.php" class="btn btn-primary btn-sm">
        <i class="fas fa-plus me-1"></i> Add Product
      </a>
      <a href="<?= BASE_URL ?>/admin/logout.php" class="btn btn-secondary btn-sm" title="Logout">
        <i class="fas fa-sign-out-alt"></i>
      </a>
    </div>
  </header>

  <!-- Page Content Container -->
  <main class="admin-content">

