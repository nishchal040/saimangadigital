/**
 * Sai Manga Digital - Public Storefront Interactivity
 */

document.addEventListener('DOMContentLoaded', () => {
    initCalculator();
    initMobileNav();
    initToasts();
    initQuantityControls();
});

/**
 * Live Price & Dimension Calculator
 */
function initCalculator() {
    const calcForm = document.getElementById('priceCalculatorForm');
    if (!calcForm) return;

    const widthInput = document.getElementById('calcWidth');
    const heightInput = document.getElementById('calcHeight');
    const materialSelect = document.getElementById('calcMaterial');
    const qtyInput = document.getElementById('calcQty');
    const resultDisplay = document.getElementById('calcTotalResult');
    const sqftDisplay = document.getElementById('calcTotalSqft');
    const rateDisplay = document.getElementById('calcRatePerSqft');

    function calculate() {
        const width = parseFloat(widthInput?.value) || 0;
        const height = parseFloat(heightInput?.value) || 0;
        const qty = parseInt(qtyInput?.value) || 1;
        
        const selectedOpt = materialSelect?.options[materialSelect.selectedIndex];
        const baseRate = parseFloat(selectedOpt?.dataset?.rate || 0);

        const sqft = (width * height);
        const totalSqft = (sqft * qty);
        const grandTotal = (totalSqft * baseRate);

        if (sqftDisplay) {
            sqftDisplay.innerText = sqft.toFixed(2) + ' sq.ft' + (qty > 1 ? ` (${totalSqft.toFixed(2)} sq.ft total)` : '');
        }

        if (rateDisplay) {
            rateDisplay.innerText = '₹' + baseRate.toFixed(2) + ' / sq.ft';
        }

        if (resultDisplay) {
            resultDisplay.innerText = '₹ ' + grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        }
    }

    [widthInput, heightInput, materialSelect, qtyInput].forEach(el => {
        if (el) {
            el.addEventListener('input', calculate);
            el.addEventListener('change', calculate);
        }
    });

    // Run initial calculation
    calculate();
}

/**
 * Mobile Navigation Toggle
 */
function initMobileNav() {
    const toggleBtn = document.getElementById('mobileMenuToggle');
    const mobileMenu = document.getElementById('mobileMenuDrawer');
    const closeBtn = document.getElementById('mobileMenuClose');

    if (toggleBtn && mobileMenu) {
        toggleBtn.addEventListener('click', () => {
            mobileMenu.classList.add('open');
            document.body.style.overflow = 'hidden';
        });
    }

    if (closeBtn && mobileMenu) {
        closeBtn.addEventListener('click', () => {
            mobileMenu.classList.remove('open');
            document.body.style.overflow = '';
        });
    }
}

/**
 * Quantity Plus / Minus buttons
 */
function initQuantityControls() {
    document.querySelectorAll('.qty-control-wrapper').forEach(wrapper => {
        const minus = wrapper.querySelector('.qty-minus');
        const plus = wrapper.querySelector('.qty-plus');
        const input = wrapper.querySelector('.qty-input');

        if (minus && plus && input) {
            minus.addEventListener('click', () => {
                let val = parseInt(input.value) || 1;
                if (val > 1) {
                    input.value = val - 1;
                    input.dispatchEvent(new Event('change'));
                }
            });

            plus.addEventListener('click', () => {
                let val = parseInt(input.value) || 1;
                input.value = val + 1;
                input.dispatchEvent(new Event('change'));
            });
        }
    });
}

/**
 * Toast Notification Trigger
 */
function showToast(message, type = 'success') {
    let container = document.querySelector('.toast-container');
    if (!container) {
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
    toast.innerHTML = `
        <i class="fas ${icon} text-${type}" style="font-size: 1.25rem;"></i>
        <div style="flex: 1;">
            <p style="margin: 0; font-weight: 600; font-size: 0.9rem;">${message}</p>
        </div>
        <button type="button" style="background: none; border: none; cursor: pointer; color: #94a3b8;" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

function initToasts() {
    // If flash message exists in DOM, display it
    const flashEl = document.getElementById('phpFlashMessage');
    if (flashEl) {
        const msg = flashEl.dataset.message;
        const type = flashEl.dataset.type || 'success';
        if (msg) showToast(msg, type);
    }
}

