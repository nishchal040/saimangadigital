/**
 * Sai Manga Digital - Admin Dashboard Interactivity
 */

document.addEventListener('DOMContentLoaded', () => {
    // Admin table filter / search
    const searchInput = document.getElementById('adminTableSearch');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('.admin-table tbody tr');
            rows.forEach(row => {
                const text = row.innerText.toLowerCase();
                row.style.display = text.includes(query) ? '' : 'none';
            });
        });
    }

    // Status change auto-submit
    const statusSelects = document.querySelectorAll('.auto-submit-status');
    statusSelects.forEach(sel => {
        sel.addEventListener('change', () => {
            sel.closest('form').submit();
        });
    });
});

