<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Shopping Cart | Sai Manga Digital';

// Handle Cart Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'update') {
            $cartKey = $_POST['cart_key'] ?? '';
            $qty = (int)($_POST['quantity'] ?? 1);
            updateCartQuantity($cartKey, $qty);
            setFlash('info', 'Cart updated successfully.');
            header('Location: ' . BASE_URL . '/cart.php');
            exit;
        } elseif ($_POST['action'] === 'remove') {
            $cartKey = $_POST['cart_key'] ?? '';
            removeFromCart($cartKey);
            setFlash('warning', 'Item removed from your cart.');
            header('Location: ' . BASE_URL . '/cart.php');
            exit;
        } elseif ($_POST['action'] === 'clear') {
            clearCart();
            setFlash('info', 'Your cart has been cleared.');
            header('Location: ' . BASE_URL . '/cart.php');
            exit;
        }
    }
}

$cart = getCart();
$totals = getCartTotals();

include __DIR__ . '/includes/header.php';
?>

<!-- Minimalist Clean Header Banner -->
<div class="page-hero-banner">
  <div class="container">
    <h1 class="page-hero-title all-caps-title">
      Your Shopping Cart
    </h1>
    <p class="page-hero-desc">
      Review your custom signage specifications and print orders before checkout.
    </p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container">
    <?php if (empty($cart)): ?>
      <div style="background: var(--card-bg); border-radius: var(--radius-card); padding: 70px 20px; text-align: center; max-width: 600px; margin: 0 auto;">
        <i class="fas fa-shopping-bag" style="font-size: 3.5rem; color: var(--text-light); margin-bottom: 20px;"></i>
        <h2 style="font-size: 1.5rem; font-weight: 800; color: #111111; margin-bottom: 8px;">Your Cart is Currently Empty</h2>
        <p style="color: var(--text-muted); margin-bottom: 24px; font-size: 0.95rem;">
          Explore our range of 3D Acrylic letters, Roll-Up standees, and Star Flex printing services to add items.
        </p>
        <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-primary pill-btn-lg">
          Browse Our Catalog
        </a>
      </div>
    <?php else: ?>
      <div class="resp-grid-cart">
        
        <!-- Cart Items List -->
        <div class="resp-card">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; padding-bottom: 14px; border-bottom: 1px solid var(--border-subtle);">
            <strong style="font-size: 1.15rem; color: #111111; font-family: 'Outfit', sans-serif;">Cart Items (<?= count($cart) ?>)</strong>
            <form action="" method="POST" onsubmit="return confirm('Clear all items from your cart?');">
              <input type="hidden" name="action" value="clear">
              <button type="submit" style="background: none; border: none; color: var(--brand-red); font-size: 0.85rem; font-weight: 700; cursor: pointer;">
                <i class="fas fa-trash-alt me-1"></i> Clear Cart
              </button>
            </form>
          </div>

          <div style="display: flex; flex-direction: column; gap: 24px;">
            <?php foreach ($cart as $key => $item): ?>
            <div class="cart-item-card">
              <!-- Item Image -->
              <div class="cart-item-thumb">
                <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
              </div>

              <!-- Item Details -->
              <div style="flex: 1; min-width: 0;">
                <h3 style="font-size: 1.05rem; font-weight: 700; color: #111111; margin-bottom: 6px;">
                  <?= htmlspecialchars($item['name']) ?>
                </h3>

                <div style="font-size: 0.82rem; color: var(--text-muted); display: flex; flex-direction: column; gap: 4px; margin-bottom: 12px;">
                  <?php if ($item['pricing_type'] === 'per_sqft' && $item['width'] > 0 && $item['height'] > 0): ?>
                    <div><strong style="color: #111111;">Size:</strong> <?= $item['width'] ?> ft &times; <?= $item['height'] ?> ft (<?= number_format($item['total_sqft'], 2) ?> sq.ft)</div>
                  <?php endif; ?>
                  <?php if (!empty($item['material']) && $item['material'] !== 'Standard'): ?>
                    <div><strong style="color: #111111;">Material:</strong> <?= htmlspecialchars($item['material']) ?></div>
                  <?php endif; ?>
                  <?php if (!empty($item['finish']) && $item['finish'] !== 'Standard'): ?>
                    <div><strong style="color: #111111;">Finishing:</strong> <?= htmlspecialchars($item['finish']) ?></div>
                  <?php endif; ?>
                  <?php if (!empty($item['artwork_file'])): ?>
                    <div><span style="display: inline-block; background: #DCFCE7; color: #15803D; padding: 2px 8px; border-radius: 999px; font-size: 0.72rem; font-weight: 700;"><i class="fas fa-paperclip"></i> Artwork Attached</span></div>
                  <?php endif; ?>
                </div>

                <!-- Quantity & Price Row -->
                <div class="cart-item-footer">
                  <form action="" method="POST" style="display: flex; align-items: center; gap: 8px;">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="cart_key" value="<?= htmlspecialchars($key) ?>">
                    <label style="font-size: 0.8rem; font-weight: 700; color: var(--text-muted);">Qty:</label>
                    <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" onchange="this.form.submit()" class="sim-input-box" style="width: 70px; height: 34px; padding: 0 10px; font-size: 0.85rem;">
                  </form>

                  <div style="text-align: right;">
                    <div style="font-size: 1.15rem; font-weight: 900; color: #111111; font-family: 'Outfit', sans-serif;">
                      <?= formatPrice($item['line_total']) ?>
                    </div>
                    <form action="" method="POST" style="margin-top: 4px;">
                      <input type="hidden" name="action" value="remove">
                      <input type="hidden" name="cart_key" value="<?= htmlspecialchars($key) ?>">
                      <button type="submit" style="background: none; border: none; color: var(--text-light); font-size: 0.78rem; cursor: pointer; text-decoration: underline;">
                        Remove Item
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>

          <div style="margin-top: 24px;">
            <a href="<?= BASE_URL ?>/shop.php" class="pill-btn pill-btn-outline pill-btn-sm">
              &larr; Continue Shopping
            </a>
          </div>
        </div>

        <!-- Order Summary Card -->
        <div class="resp-card" style="position: sticky; top: 100px;">
          <h3 style="font-size: 1.3rem; font-weight: 800; color: #111111; margin-bottom: 20px;">
            Order Summary
          </h3>

          <div style="display: flex; flex-direction: column; gap: 12px; font-size: 0.92rem; margin-bottom: 24px;">
            <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
              <span>Items Subtotal</span>
              <strong style="color: #111111;"><?= formatPrice($totals['subtotal']) ?></strong>
            </div>

            <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
              <span>GST / Taxes</span>
              <strong style="color: #111111;"><?= $totals['tax'] > 0 ? formatPrice($totals['tax']) : 'Calculated at checkout' ?></strong>
            </div>

            <div style="display: flex; justify-content: space-between; color: var(--text-muted);">
              <span>Studio Pickup / Delivery</span>
              <strong style="color: #10B981;">Free In-Store Pickup</strong>
            </div>

            <div style="display: flex; justify-content: space-between; align-items: baseline; padding-top: 16px; border-top: 2px dashed #D0D5DD;">
              <strong style="font-size: 1.05rem; color: #111111;">Grand Total</strong>
              <strong style="font-size: 1.8rem; font-weight: 900; color: #111111; font-family: 'Outfit', sans-serif;">
                <?= formatPrice($totals['grand_total']) ?>
              </strong>
            </div>
          </div>

          <a href="<?= BASE_URL ?>/checkout.php" class="pill-btn pill-btn-primary pill-btn-lg" style="width: 100%;">
            Proceed to Checkout &rarr;
          </a>

          <div style="background: #FFFFFF; border-radius: 12px; padding: 14px; margin-top: 20px; font-size: 0.8rem; color: var(--text-muted); line-height: 1.5; text-align: center;">
            <i class="fas fa-store me-1 text-primary"></i> <strong>Flagship Location:</strong> Madhuban Plaza, S.D. Road Secunderabad.
          </div>
        </div>

      </div>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
