<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Return & Refund Policy | Sai Manga Digital';
$phone = getSetting('phone', '+91 8047663573');
$email = getSetting('email', 'sales@saimangadigital.com');

include __DIR__ . '/includes/header.php';
?>

<div class="page-hero-banner">
  <div class="container">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: #FFFFFF; padding: 6px 18px; border-radius: var(--radius-pill); font-size: 0.82rem; font-weight: 700; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <i class="fas fa-shield-alt text-success"></i> Customer Assurance &amp; Quality Guarantee
    </div>
    <h1 class="page-hero-title all-caps-title">Cancellation &amp; Refund Policy</h1>
    <p class="page-hero-desc">Clear, transparent policies regarding custom manufactured signage and large format printing.</p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container" style="max-width: 900px;">
    <div class="resp-card" style="font-size: 0.95rem; color: var(--text-muted); line-height: 1.8;">
      
      <p style="font-size: 0.85rem; color: var(--text-light); margin-bottom: 24px;">
        Last updated: <?= date('F d, Y') ?> &bull; Governing custom printed and architectural products.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin-bottom: 12px;">1. Custom Fabricated Products Policy</h3>
      <p>
        Because all our signboards, 3D channel letters, neon art, roll-up standees, and large-format flex banners are custom manufactured to each client's specific dimensions, artwork, and branding, they <strong>cannot be returned or resold</strong> once fabrication has commenced.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 12px;">2. Free Replacement Guarantee for Transit Damage or Manufacturing Defects</h3>
      <p>
        At Sai Manga Digital, we take immense pride in our 30-year legacy of master craftsmanship. We provide a <strong>100% Free Repair or Replacement Guarantee</strong> under the following conditions:
      </p>
      <ul style="margin-left: 24px; margin-bottom: 20px;">
        <li>The product was visibly damaged or cracked during transit.</li>
        <li>There is an objective manufacturing defect (e.g., non-functioning LED modules, incorrect dimensions differing from the approved proof, or material peeling).</li>
        <li>The client notifies our customer support within <strong>48 hours of delivery</strong> with clear photographs or unboxing video sent to our WhatsApp desk.</li>
      </ul>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 12px;">3. Order Cancellation Prior to Production</h3>
      <p>
        If you need to cancel an order, please contact us immediately:
      </p>
      <ul style="margin-left: 24px; margin-bottom: 20px;">
        <li><strong>Before Proof Approval / Laser Cutting:</strong> You are entitled to a <strong>100% full refund</strong> if cancellation is requested before digital proofing or material cutting starts.</li>
        <li><strong>After Production Starts:</strong> If acrylic cutting, CNC bending, or high-speed printing has already taken place, material and labor costs incurred up to that stage will be deducted, and any remaining balance refunded.</li>
      </ul>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 12px;">4. LED Electrical Component Warranty</h3>
      <p>
        All Korean Samsung LED modules, power drivers, and neon power adaptors supplied by Sai Manga Digital carry a <strong>12-month manufacturer replacement warranty</strong> against failure under normal operating voltages.
      </p>

      <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin: 28px 0 12px;">5. Refund Processing Timelines</h3>
      <p>
        Approved refunds are processed within <strong>3 to 5 business days</strong> directly to your original payment method (Bank Account, UPI, or Credit/Debit Card). For assistance, email us at <a href="mailto:<?= htmlspecialchars($email) ?>" style="color: var(--brand-blue); font-weight: 700;"><?= htmlspecialchars($email) ?></a> or call <a href="tel:<?= preg_replace('/[^0-9+]/', '', $phone) ?>" style="color: #111111; font-weight: 700;"><?= htmlspecialchars($phone) ?></a>.
      </p>

    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>

