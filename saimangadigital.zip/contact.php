<?php
require_once __DIR__ . '/config/init.php';

$pageTitle = 'Contact & Factory Quotations | Sai Manga Digital Secunderabad';
$quoteSuccess = '';
$quoteError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_quote'])) {
    $name = sanitize($_POST['customer_name'] ?? '');
    $phone = sanitize($_POST['customer_phone'] ?? '');
    $email = sanitize($_POST['customer_email'] ?? '');
    $company = sanitize($_POST['company_name'] ?? '');
    $service = sanitize($_POST['service_needed'] ?? 'Sign Board');
    $dimensions = sanitize($_POST['dimensions'] ?? '');
    $quantity = max(1, (int)($_POST['quantity'] ?? 1));
    $message = sanitize($_POST['message'] ?? '');

    if (empty($name) || empty($phone) || empty($email) || empty($message)) {
        $quoteError = 'Please fill in your name, contact phone, email, and project details.';
    } else {
        $quoteNumber = generateQuoteNumber();
        $artworkFileName = '';

        if (isset($_FILES['artwork_file']) && $_FILES['artwork_file']['error'] === UPLOAD_ERR_OK) {
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'pdf', 'cdr', 'ai', 'psd', 'zip'];
            $origName = $_FILES['artwork_file']['name'];
            $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
            if (in_array($ext, $allowedExtensions)) {
                $newName = 'quote_' . time() . '_' . rand(100, 999) . '.' . $ext;
                $uploadTarget = APP_ROOT . '/uploads/artwork/' . $newName;
                if (!is_dir(dirname($uploadTarget))) {
                    mkdir(dirname($uploadTarget), 0777, true);
                }
                if (move_uploaded_file($_FILES['artwork_file']['tmp_name'], $uploadTarget)) {
                    $artworkFileName = $newName;
                }
            }
        }

        try {
            $stmt = $db->prepare("
                INSERT INTO quotes (
                    quote_number, customer_name, customer_phone, customer_email,
                    company_name, service_needed, dimensions, quantity, message,
                    artwork_file, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')
            ");
            $stmt->execute([
                $quoteNumber, $name, $phone, $email,
                $company, $service, $dimensions, $quantity, $message,
                $artworkFileName
            ]);

            $quoteSuccess = "Your quotation request (#{$quoteNumber}) has been submitted successfully! Our engineering team will review your specs and call you within 2 business hours.";
        } catch (Exception $e) {
            $quoteError = 'Failed to submit quote request: ' . $e->getMessage();
        }
    }
}

$phone = getSetting('phone', '+91 8047663573');
$mobile = getSetting('mobile', '+91 98490 12345');
$whatsapp = getSetting('whatsapp', '918047663573');
$email = getSetting('email', 'sales@saimangadigital.com');
$address = getSetting('address', 'Door No. 1-2-265, Ground Floor, North Block, Madhuban Plaza, Opp. Minerva Complex, Beside Manyavar Showroom, S.D. Road, Secunderabad, Telangana - 500003');
$instagram = getSetting('instagram', 'https://www.instagram.com/saimangadigital');
$mapsUrl = getSetting('google_maps_url', 'https://maps.app.goo.gl/cNSaRii6R44K9t4c8');
$proprietor = getSetting('proprietor', 'Marri Prasad Naidu');
$hours = getSetting('business_hours', 'Monday - Saturday: 9:30 AM to 9:00 PM (Sunday Closed)');
$rating = getSetting('google_rating', '4.8');
$reviewsCount = getSetting('google_reviews_count', '68');

include __DIR__ . '/includes/header.php';
?>

<!-- Minimalist Clean Header Banner -->
<div class="page-hero-banner">
  <div class="container">
    <div style="display: inline-flex; align-items: center; gap: 8px; background: #FFFFFF; padding: 6px 18px; border-radius: var(--radius-pill); font-size: 0.82rem; font-weight: 700; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
      <i class="fab fa-google" style="color: #4285F4;"></i> <?= htmlspecialchars($rating) ?> ★ Google Verified Secunderabad Facility
    </div>
    <h1 class="page-hero-title all-caps-title">
      Contact &amp; Factory Studio
    </h1>
    <p class="page-hero-desc">
      Visit our Madhuban Plaza workshop on S.D. Road, consult with proprietor <strong><?= htmlspecialchars($proprietor) ?></strong>, or submit your architectural specifications for an instant quotation.
    </p>
  </div>
</div>

<div style="padding: 40px 0 80px; background-color: #FFFFFF;">
  <div class="container">
    <div class="resp-grid-side-main">
      
      <!-- Contact Info Card in Soft Grey -->
      <div>
        <div class="resp-card" style="margin-bottom: 30px;">
          <h3 style="font-size: 1.25rem; font-weight: 800; color: #111111; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 1px solid var(--border-subtle);">
            Studio &amp; Workshop Facility
          </h3>

          <div style="display: flex; flex-direction: column; gap: 24px;">
            <div style="display: flex; gap: 16px;">
              <div style="width: 44px; height: 44px; border-radius: 50%; background: #FFFFFF; color: var(--brand-red); display: flex; align-items: center; justify-content: center; font-size: 1.15rem; flex-shrink: 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
                <i class="fas fa-map-marker-alt"></i>
              </div>
              <div>
                <strong style="color: #111111; font-size: 0.95rem; display: block; margin-bottom: 4px;">Store &amp; Workshop Address</strong>
                <p style="color: var(--text-muted); font-size: 0.9rem; line-height: 1.6; margin: 0;">
                  <?= nl2br(htmlspecialchars($address)) ?>
                </p>
                <div style="margin-top: 6px; font-size: 0.82rem; color: var(--brand-blue); font-weight: 700;">
                  <i class="fas fa-directions me-1"></i> Beside Manyavar Showroom, Opposite Minerva Complex
                </div>
              </div>
            </div>

            <div style="display: flex; gap: 16px;">
              <div style="width: 44px; height: 44px; border-radius: 50%; background: #FFFFFF; color: #D97706; display: flex; align-items: center; justify-content: center; font-size: 1.15rem; flex-shrink: 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
                <i class="fas fa-clock"></i>
              </div>
              <div>
                <strong style="color: #111111; font-size: 0.95rem; display: block; margin-bottom: 4px;">Operating Hours</strong>
                <p style="color: var(--text-muted); font-size: 0.9rem; margin: 0;">
                  <?= htmlspecialchars($hours) ?>
                </p>
                <div style="font-size: 0.8rem; color: #10B981; font-weight: 700; margin-top: 4px;">
                  &bull; Open for Walk-ins &amp; Material Inspection
                </div>
              </div>
            </div>

            <div style="display: flex; gap: 16px;">
              <div style="width: 44px; height: 44px; border-radius: 50%; background: #FFFFFF; color: #10B981; display: flex; align-items: center; justify-content: center; font-size: 1.15rem; flex-shrink: 0; box-shadow: 0 2px 8px rgba(0,0,0,0.06);">
                <i class="fas fa-phone-alt"></i>
              </div>
              <div>
                <strong style="color: #111111; font-size: 0.95rem; display: block; margin-bottom: 4px;">Phone &amp; Direct Support</strong>
                <p style="color: var(--text-muted); font-size: 0.9rem; margin: 0;">
                  <a href="tel:<?= preg_replace('/[^0-9+]/', '', $phone) ?>" style="color: #111111; font-weight: 700;"><?= htmlspecialchars($phone) ?></a> (Sales Desk)<br>
                  <a href="tel:<?= preg_replace('/[^0-9+]/', '', $mobile) ?>" style="color: #111111; font-weight: 700;"><?= htmlspecialchars($mobile) ?></a> (Direct WhatsApp)
                </p>
                <div style="font-size: 0.8rem; color: var(--text-muted); margin-top: 4px;">Proprietor: <strong><?= htmlspecialchars($proprietor) ?></strong></div>
              </div>
            </div>
          </div>

          <div style="margin-top: 28px; padding-top: 20px; border-top: 1px solid var(--border-subtle); display: flex; flex-direction: column; gap: 12px;">
            <a href="https://wa.me/<?= preg_replace('/[^0-9]/', '', $whatsapp) ?>?text=Hi%20Sai%20Manga%20Digital,%20I%20want%20to%20discuss%20a%20project" target="_blank" class="pill-btn pill-btn-primary" style="width: 100%;">
              <i class="fab fa-whatsapp me-2"></i> WhatsApp Order Desk
            </a>
            <a href="<?= htmlspecialchars($mapsUrl) ?>" target="_blank" class="pill-btn pill-btn-outline" style="width: 100%;">
              <i class="fab fa-google me-1"></i> Google Maps Directions
            </a>
          </div>
        </div>

        <!-- Google Maps Embed Card in Soft Grey -->
        <div style="background: var(--card-bg); border-radius: var(--radius-card); overflow: hidden; padding: 14px;">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.6666878950663!2d78.497526!3d17.441865!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb9a2444634289%3A0xbcf0130f1d5303df!2sMadhuban%20Plaza%2C%20Sarojini%20Devi%20Rd%2C%20Secunderabad%2C%20Telangana%20500003!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin" 
            width="100%" 
            height="260" 
            style="border:0; display: block; border-radius: 14px;" 
            allowfullscreen="" 
            loading="lazy">
          </iframe>
          <div style="padding: 14px 10px 4px; font-size: 0.82rem; color: var(--text-muted); display: flex; justify-content: space-between; align-items: center;">
            <span><i class="fas fa-star text-warning"></i> <strong>4.8 / 5.0</strong> (68 Google Reviews)</span>
            <a href="<?= htmlspecialchars($mapsUrl) ?>" target="_blank" class="pill-btn pill-btn-primary pill-btn-sm" style="padding: 4px 14px; font-size: 0.72rem;">
              Directions
            </a>
          </div>
        </div>
      </div>

      <!-- Quote Request Form -->
      <div id="quoteForm" class="resp-card">
        <h3 style="font-size: 1.3rem; font-weight: 800; color: #111111; margin-bottom: 8px;">
          Request a Custom Fabrication Quote
        </h3>
        <p style="font-size: 0.9rem; color: var(--text-muted); margin-bottom: 24px;">
          Have specific architectural dimensions, multi-outlet branding requirements, or need a site survey? Send us your brief below.
        </p>

        <?php if (!empty($quoteSuccess)): ?>
          <div style="background: #DCFCE7; border-left: 4px solid #10B981; padding: 18px 24px; border-radius: 10px; margin-bottom: 24px; color: #15803D; font-weight: 600;">
            <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($quoteSuccess) ?>
          </div>
        <?php endif; ?>

        <?php if (!empty($quoteError)): ?>
          <div style="background: #FEE2E2; border-left: 4px solid #EF4444; padding: 18px 24px; border-radius: 10px; margin-bottom: 24px; color: #B91C1C; font-weight: 600;">
            <i class="fas fa-exclamation-triangle me-2"></i> <?= htmlspecialchars($quoteError) ?>
          </div>
        <?php endif; ?>

        <form action="" method="POST" enctype="multipart/form-data">
          <div class="form-grid-2" style="margin-bottom: 16px;">
            <div>
              <label class="clean-label">Your Name *</label>
              <input type="text" name="customer_name" class="clean-input" placeholder="e.g. Anand Varma" required>
            </div>
            <div>
              <label class="clean-label">Contact Number *</label>
              <input type="tel" name="customer_phone" class="clean-input" value="<?= htmlspecialchars($_GET['phone_quote'] ?? '') ?>" placeholder="e.g. 98490 12345" required>
            </div>
          </div>

          <div class="form-grid-2" style="margin-bottom: 16px;">
            <div>
              <label class="clean-label">Email Address *</label>
              <input type="email" name="customer_email" class="clean-input" placeholder="e.g. anand@company.com" required>
            </div>
            <div>
              <label class="clean-label">Company / Brand Name</label>
              <input type="text" name="company_name" class="clean-input" placeholder="e.g. Cafe Royale">
            </div>
          </div>

          <div class="form-grid-2" style="margin-bottom: 16px;">
            <div>
              <label class="clean-label">Signage / Service Required</label>
              <select name="service_needed" class="clean-select">
                <option value="3D Acrylic LED Sign Board">3D Acrylic LED Sign Board</option>
                <option value="Custom Neon Flex Sign">Custom Neon Flex Sign</option>
                <option value="Roll-Up Standees (Bulk)">Roll-Up Standees (Bulk)</option>
                <option value="Large Format Flex Banner">Large Format Flex Banner</option>
                <option value="Running LED Display Board">Running LED Display Board</option>
                <option value="Frosted Glass Vinyl / Wall Branding">Frosted Glass Vinyl / Wall Branding</option>
                <option value="Canopy Tent / Event Kiosk">Canopy Tent / Event Kiosk</option>
                <option value="Other Custom Requirement">Other Custom Requirement</option>
              </select>
            </div>
            <div>
              <label class="clean-label">Dimensions / Size</label>
              <input type="text" name="dimensions" class="clean-input" placeholder="e.g. 15 ft x 4 ft">
            </div>
          </div>

          <div style="margin-bottom: 16px;">
            <label class="clean-label">Quantity</label>
            <input type="number" name="quantity" class="clean-input" value="1" min="1" style="width: 120px;">
          </div>

          <div style="margin-bottom: 16px;">
            <label class="clean-label">Project Details &amp; Location *</label>
            <textarea name="message" rows="4" class="clean-textarea" placeholder="Please mention site location in Hyderabad/Secunderabad, mounting requirements, and deadline." required></textarea>
          </div>

          <div style="background: #FFFFFF; border: 1.5px dashed #D0D5DD; border-radius: 12px; padding: 18px; margin-bottom: 24px;">
            <label class="clean-label" style="display: flex; align-items: center; gap: 8px;">
              <i class="fas fa-paperclip text-primary"></i> Attach Logo or Drawing (Optional)
            </label>
            <input type="file" name="artwork_file" style="margin-top: 6px; font-size: 0.88rem;">
            <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 4px;">Supported: JPG, PNG, PDF, CDR, AI (Max 50MB)</div>
          </div>

          <button type="submit" name="submit_quote" class="pill-btn pill-btn-primary pill-btn-lg" style="width: 100%;">
            Submit Quotation Request
          </button>
        </form>
      </div>

    </div>
  </div>
</div>

<?php include __DIR__ . '/includes/footer.php'; ?>
